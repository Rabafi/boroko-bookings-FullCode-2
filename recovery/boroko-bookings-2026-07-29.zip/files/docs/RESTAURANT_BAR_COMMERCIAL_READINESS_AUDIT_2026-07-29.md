# Restaurant & Bar Commercial Readiness Audit

**Audit date:** 29 July 2026  
**Application version:** 1.3.15  
**Decision:** **NO-GO for commercial sale or unsupervised production use**

## Executive verdict

The Restaurant and Bar screens already cover a broad operator workflow: touch/desktop terminals, outlet selection, menus, bar-pack depletion, tables, tabs, room folios, split tenders, receipts, returns, voids, cash-up, kitchen/bar tickets, shifts, displays, modifiers, promotions, floor areas, and audit views.

The problem is not feature count. The current implementation does not preserve financial truth under hostile input, concurrent terminals, transient connectivity, or repeated returns. The largest defects are in the database contracts and cross-terminal architecture, so UI polish alone cannot make this sellable.

Both modes use the same `POS.jsx` client, `src/main/domains/pos.js` Electron service, and Supabase functions. Restaurant and Bar therefore share the same launch blockers.

## Offline-first contract used for this audit

The Electron Restaurant/Bar app is intentionally designed to remain operational without internet access. A correct offline mutation should:

1. validate against the latest trusted local data;
2. persist the local result and any stock reservation immediately;
3. store an **operation**, normally an RPC name and payload, in the durable sync queue;
4. use deterministic operation/idempotency IDs and dependencies;
5. replay the same RPC only after an authenticated session is restored;
6. merge the authoritative result without losing pending local work; and
7. expose any rejected/conflicted replay for operator review.

Local-first storage is therefore **not a defect**. It is required behavior. Findings below only criticize a local workflow when it is not durably queued, cannot be safely validated on replay, or never converges with another authorized terminal after reconnect.

The Manager PWA is a separate direct-Supabase client and does not share the Electron sync queue. It is not treated as the offline Restaurant/Bar terminal in this report.

## Scope reviewed

The audit traced the complete Restaurant/Bar path across:

- all six POS pages: Terminal, Menu Items, History, Cash-Up, Tickets, and Setup;
- all eight Setup sections: Shift, Tables, Displays, Hardware, Modifiers, Promos, Floor, and Audit;
- customer, kitchen, and bar display windows;
- receipt rendering and printing;
- inventory linkage, bar pack templates, stock movements, and stock adjustment;
- Electron renderer, preload bridge, IPC authorization, `src/main/domains/pos.js`, offline queue replay, local caches, and Supabase RPCs;
- Manager PWA routing, access rules, Inventory view, and POS reporting;
- current POS/inventory migrations, role/capability definitions, automated tests, build scripts, and release scripts.

This was a targeted line-level trace of Restaurant/Bar and its financial dependencies. Unrelated hotel modules were not re-audited.

## What is already sound

- Order creation, inventory depletion, and room-folio charging are grouped in one Postgres RPC transaction.
- The stock decrement uses an atomic guarded update.
- Order creation has a unique idempotency key.
- Full voids use a server RPC, lock the order, restore stock, remove a linked folio charge, and record an override.
- Outlet-scoped cashier/supervisor sessions exist.
- Offline POS sales are persisted with line items and pending-sync metadata before returning success to the operator.
- Offline sales reserve stock locally, queue `create_pos_order`, and carry deterministic queue/idempotency IDs.
- Queue replay is deferred until a real authenticated session is restored, supports operation dependencies, deduplicates queue IDs, and retains failed items for review.
- Explicitly offline cash-ups, table saves, and tab status changes already queue RPC operations.
- The test suite includes offline POS crash recovery, duplicate replay, reconnect retry, multiline replay, stock depletion, and cross-process sync scenarios, although several depend on a live backend.
- The desktop production build and the advertised critical source/regression tests pass.
- Restaurant and Bar outlet filtering, barcode entry, bar pack depletion, cached offline orders, and receipt rendering are already present.

These are useful foundations, but later logic currently bypasses or weakens several of them.

## P0 launch blockers

### POS-001 — The server trusts cashier-authored prices and financial totals

**Severity:** P0 / financial integrity

Every online order is correctly sent with a `create_idempotency_key` for retry safety (`src/main/domains/pos.js:584`, `src/main/domains/pos.js:763`). The defect is that the current SQL treats the mere presence of that key as proof that the order originated offline (`supabase/migrations/20260604120000_pos_inventory_launch_readiness.sql:550`). As a result, a normal first-attempt online sale uses the caller's `unit_price` instead of the menu price stored in the database (`:650-655`, `:773-778`).

The RPC also accepts caller-supplied:

- custom lines with no menu item (`:669-680`);
- zero or negative quantities because no positive-quantity invariant exists (`:623-684`);
- `gross_total`, `discount_total`, tax, tip, tender breakdown, cashier identity, waiter identity, and client timestamp (`:530-550`, `:688-743`);
- a menu item from the same lodge without proving that it belongs to the selected outlet (`:641-643`).

The server does not prove that split tenders equal the order total, that discounts were authorized, that the tax is correct, or that the current session is the recorded cashier. An authenticated POS user can therefore construct a zero-priced, under-priced, negatively priced, misattributed, or cross-outlet sale by calling the RPC directly.

**Required fix:** Replace the RPC contract without reducing offline capability. Online first execution must use server pricing. Offline sales should carry the signed/versioned price snapshot that was last trusted on that device, or reference immutable server price history effective at the device event time. The RPC must validate that snapshot on replay while also owning discount authorization, tax calculation, tender validation, outlet linkage, and actor identity. A client-controlled replay/origin flag is not proof.

### POS-002 — Returns can exceed the original sale and bypass approval

**Severity:** P0 / cash and inventory loss

The partial-return flow caps a requested quantity only against the original sold quantity (`src/main/domains/pos.js:1042-1056`). It never subtracts quantities already returned. The same line can be returned repeatedly.

The return is then submitted as a normal order with negative quantity (`:1064-1084`). There is no dedicated database return transaction, no server link between returned lines and original lines, no cumulative return ceiling, and no server proof of supervisor approval. Because `create_pos_order` itself accepts negative quantities, a caller can bypass the PIN modal entirely.

The refund total is based only on original unit prices. Original discounts, tax, tip, split tenders, and prior returns are not allocated or reconciled.

**Required fix:** Add a dedicated idempotent `return_pos_order_items` RPC. Lock original lines, calculate remaining returnable quantity, allocate discount/tax, validate refund tender, restore stock once, reverse folio charges correctly, and record approver/reason in the same transaction.

### POS-003 — Cash-up is caller-authored, unsealed, and can be lost

**Severity:** P0 / reconciliation

`upsert_pos_cashup` inserts the caller's expected totals, order counts, variances, returns, and net sales without recomputing them from `pos_orders` (`supabase/migrations/20260604120000_pos_inventory_launch_readiness.sql:1125-1172`). It does not seal a server shift or prevent later orders from falling into an already closed period.

If the app believes it is online but the cash-up RPC fails, the catch path saves a local pending cash-up without adding it to the sync queue (`src/main/domains/pos.js:1261-1278`). Only the explicitly offline branch queues the RPC, so a transient server error can permanently strand the close.

**Required fix:** Server-owned shifts and an atomic close RPC that derives expected totals, records counted tenders, calculates variance, seals a bounded period, and is idempotent. Queue on every retriable failure.

### POS-004 — Offline tickets and shifts work locally but do not enter the sync contract

**Severity:** P1 for a single-terminal venue; P0 for a multi-terminal venue

The local-first portion works: a disconnected cashier can create a sale, the same computer creates prep tickets, and its kitchen/bar display and shift UI continue operating. The gap is convergence. Database tables for `pos_prep_tickets` and `pos_shifts` exist (`supabase/migrations/20260604120000_pos_inventory_launch_readiness.sql:97-141`), but these operations are never queued or written to them.

- Prep tickets are generated only after the order RPC and written to local JSON (`src/main/domains/pos.js:1683-1734`).
- Ticket status changes are local only.
- Shifts open and close in local JSON only (`:1737-1788`).
- Customer-display state is local to the POS computer (`:1909-1916`), which is acceptable for a second monitor attached to that device.

A kitchen screen or bar screen opened from the same Electron installation works offline. A screen on another workstation will not receive that ticket, even after both devices reconnect. Two cashiers do not converge on shared shift state. The UI's reference to a tablet, TV, or second workstation is therefore only accurate when it is acting as a display attached to the same computer.

**Required fix:** Keep writing the local ticket/shift state first. Also queue deterministic ticket and shift operations, create or reconcile the server tickets as part of sale replay, merge remote state without overwriting pending transitions, and let other terminals refresh/subscribe after reconnect. The original terminal must remain fully functional while disconnected.

### POS-005 — Table service is a draft snapshot, not a restaurant check ledger

**Severity:** P0 for restaurant sales

Local table snapshots and the explicitly offline tab queue are valid offline-first foundations. The remaining model is not yet a full restaurant check ledger: an open table stores a JSON snapshot of unsold cart items. Completing an order closes the tab (`src/main/domains/pos.js:724`, `:792`) and the renderer clears the table selection (`src/renderer/src/components/POS.jsx:990-1011`). This cannot safely support multiple rounds/courses followed by one settlement.

Additional defects:

- an online tab/table save failure is retained locally but not queued (`src/main/domains/pos.js:1358-1421`, `:1616-1666`);
- table transfer/merge RPC failures are swallowed;
- merge is two separate RPC calls and is not atomic (`:1517-1523`);
- table deletion removes only the local cache (`:1669-1671`), so a remote table can reappear;
- SQL table/tab mutations require only lodge access, not a POS management capability or outlet assignment (`supabase/migrations/20260604143000_pos_table_sessions.sql:86-248`).

**Required fix:** Add a local-first check/tab ledger with append-only deterministic round operations. Queue those operations for the same server RPCs, then enforce atomic table transfer/merge, explicit settlement, optimistic concurrency/version checks, and real delete/deactivate RPCs on replay. Disconnected table service must continue from the durable local ledger.

### POS-006 — Server receipt numbering was regressed

**Severity:** P0 / auditability and possible fiscal compliance

The baseline has a `receipt_number` column and an atomic receipt sequence. The latest `create_pos_order` replacement neither assigns a receipt number nor returns one (`supabase/migrations/20260604120000_pos_inventory_launch_readiness.sql:688-744`, `:868-874`).

The receipt UI therefore falls back to `POS-` plus the first eight characters of the order UUID (`src/renderer/src/components/shared/POSReceipt.jsx:40-42`). A deterministic provisional number is reasonable for an offline sale, provided it is clearly identified and reconciled later. The current defect is that online sales and successful replays also receive no final server receipt number from the latest RPC.

**Required fix:** Preserve immediate offline receipt printing with a deterministic provisional ID. Restore atomic per-lodge final receipt sequencing in the RPC, return it for first execution and idempotent replay, update the cached order after sync, and provide a clear final-number/reprint workflow. Define immutable void/return receipt rules and obtain jurisdiction-specific tax review before marketing fiscal compliance.

### POS-007 — Permission, PIN, and audit boundaries are not enforceable

**Severity:** P0 / fraud and accountability

- A cashier receives `pos.manage` by default (`src/shared/accessControl.js:157-168`). The table's “Manager” actions are shown without a manager PIN and call IPC that only requires `pos.manage` (`src/renderer/src/components/POS.jsx:2342-2359`, `src/main/index.js:4048-4050`).
- Table setup/delete, hardware settings/tests, closing a shift, and creating a cash-up require only `pos.view` in IPC (`src/main/index.js:4014-4024`, `:4074-4086`, `:4104-4118`).
- Modifier, promotion, floor, display, and audit setup are not separately capability-gated in the page.
- Staff/waiter PIN selection is correctly capable of running offline, but the locally cached bcrypt verification has no attempt limit, delay, or device lockout (`src/main/domains/pos.js:1834-1850`).
- An offline void stores the plaintext supervisor PIN inside the JSON sync queue (`:898-918`).
- The server verifies a void approver's role and PIN, but not that the approver is assigned to the order's outlet; reason and claimed requester/time are also caller-controlled (`supabase/migrations/20260604201454_pos_void_pin_server_verification.sql:10-18`, `:55-67`, `:88-107`).
- `append_pos_audit_log` accepts caller-supplied staff, action, details, and timestamp from any lodge-access session (`supabase/migrations/20260604153000_pos_world_class_features.sql:74-104`).

**Required fix:** Enforce capabilities in database helpers and derive actor/time from the restored server session. Keep offline step-up approval, but rate-limit it locally and queue a device-signed approval event or another server-verifiable proof that does not contain the plaintext PIN. Validate outlet assignment on replay and remove “Manager” actions from cashier permissions.

### POS-008 — The audit trail is best-effort, mutable input

**Severity:** P0 / forensic integrity

Order audit events are appended after the order transaction and failures are swallowed (`src/main/domains/pos.js:228`, `:780-793`). Local audit entries can exist without server entries, and successful financial transactions can exist without audit entries. The audit RPC trusts caller-authored identity, event type, details, and timestamps.

**Required fix:** Persist audit events locally first and queue them with deterministic event IDs. On replay, commit immutable financial audit events inside every sale, return, void, shift-close, cash-up, stock, discount, and override transaction. Final actor identity and accepted event time must be validated against the trusted device/session context.

### INV-001 — Stock adjustment approval is cosmetic and the movement ledger can disagree with stock

**Severity:** P0 / inventory valuation

The Inventory UI requires a Manager PIN and passes it through preload/IPC, but `adjustInventoryStock` accepts only three parameters and discards the PIN (`src/main/domains/inventory.js:372`, `src/main/index.js:4242-4247`).

The SQL clamps stock at zero but logs the original requested delta (`supabase/migrations/20260604120000_pos_inventory_launch_readiness.sql:1036-1057`). If stock is 10 and the caller adjusts by -100, stock becomes 0 while the movement ledger records -100. Offline code has the same clamp-and-queue behavior (`src/main/domains/inventory.js:380-416`).

The default `manager` capability list also omits both `inventory.view` and `inventory.manage`, even though `admin` receives them (`src/shared/accessControl.js:220-265`). A normal manager can be locked out of Inventory unless manually overridden.

**Required fix:** Either remove the PIN promise or validate it server-side. Reject impossible decrements or log the actual applied delta under a locked row. Repair manager capability defaults and add reconciliation tests.

### OFF-001 — Several daily Restaurant/Bar operations still require internet

**Severity:** P0 / advertised offline capability

Core selling, room-folio staging, returns, voids, cash-up, local tickets, shifts, and basic table work continue offline. However, several normal operating tasks—not just login or new-user setup—are explicitly blocked:

- Kitchen item availability cannot be changed while offline because all menu mutations are disabled and `updatePosMenuItem` rejects offline use (`src/renderer/src/components/POS.jsx:820`, `:2725-2749`; `src/main/domains/pos.js:311-332`). A kitchen cannot mark a sold-out dish unavailable during an outage.
- Inventory purchases/stock receipts require internet (`src/main/domains/inventory.js:262-307`). A bar cannot receive new bottles into stock while disconnected.
- Inventory stocktake creation, loading, count saving, and posting require internet (`src/main/domains/inventory.js:578-685`).
- Updates to an existing inventory item require internet unless the item itself was originally created offline and is still pending (`src/main/domains/inventory.js:202-246`).
- Offline table transfer and merge update local state but do not queue the corresponding operations (`src/main/domains/pos.js:1479-1525`). They can disappear or conflict after reconnect.

Menu creation/deletion, bar-pack template setup, user setup, and other infrequent configuration can reasonably remain online-only if that is the explicit product policy. Availability changes, stock receiving, stock counts, and active table moves are normal service operations and should not.

**Required fix:** Implement each as a durable local operation with deterministic IDs, optimistic local state, exact RPC replay, dependencies, and conflict review. Stocktake posting should remain atomic on the server while counts can be captured and edited offline.

### REL-001 — An alternate local release path bypasses the documented gate

**Severity:** P1 / release safety

The documented GitHub `Publish Desktop Release` workflow does run the production guardrails, critical offline suites, dependency audit, Manager PWA checks, booking-site build, and desktop build before publishing. That is the correct release path.

However, `scripts/release.mjs` can build and publish the Electron installer locally without running those gates (`scripts/release.mjs:174-197`). The direct local path can therefore bypass the documented policy.

Current verification:

- PASS: Electron production build.
- PASS: booking-site production build.
- PASS: `npm test`, offline queue, offline POS, inventory offline sync, and import critical scripts.
- LOCAL FAIL: Manager PWA production build because its Rolldown Windows native binding is invalid/missing in the current workstation install. This may be a corrupted optional dependency rather than a source defect; a clean CI build is the deciding result.
- WARN: Manager PWA lint exits successfully with 33 warnings, including multiple missing React hook dependencies.
- FAIL/UNVERIFIED: the POS visual Playwright status test timed out; the app itself launched, but no complete visual sign-off was obtained.

The “critical” POS test is mostly source-pattern assertions (`tests/offline-pos-regression.test.mjs`), not behavior. Several desktop E2E tests load `.env` and the installed lodge profile and create live Supabase orders or stock adjustments. There is no isolated Supabase test tenant, so release testing can pollute real business data.

**Required fix:** Remove or gate the local publish bypass so every release uses the same clean-install checks as GitHub Actions. Add isolated database integration tests, POS behavioral tests, and a complete UI smoke suite. Never run destructive financial E2E against a customer tenant.

## Page-by-page readiness

| Area | Current state | Biggest gap | Verdict |
|---|---|---|---|
| Restaurant terminal | Broad workflow and touch mode | Server accepts client prices/totals; table checks close after each order | Blocked |
| Bar terminal | Barcode and pack depletion present | Same financial RPC flaw; no server proof that item belongs to Bar outlet | Blocked |
| Menu Items | Cached menu supports offline selling | Availability changes are blocked offline; database pricing/outlet authorization is bypassable through replay/custom lines | Blocked |
| History | Orders, voids, partial-return modal | Repeat returns, refund miscalculation, weak source linkage | Blocked |
| Cash-Up | Tender counts, variance, history | Caller-authored expected totals; no sealed shift; failed online save can be lost | Blocked |
| Tickets | Works offline on the originating computer | No queued/server convergence for another terminal after reconnect | Single-terminal ready; multi-terminal blocked |
| Setup / Shift | Works offline with local opening/closing state | Shift mutations are not queued or reconciled; no server-controlled cash period | Single-terminal limited; multi-terminal blocked |
| Setup / Tables | Offline tab/table saves already queue in explicit offline mode | Transfer/merge are not queued offline; draft snapshots, online-failure queue gaps, non-atomic merge, local-only delete, weak SQL authorization | Blocked |
| Setup / Displays | Customer, kitchen, and bar windows work from the POS computer while offline | No cross-device ticket feed; customer second-monitor behavior is acceptable | Local display ready; remote display limited |
| Setup / Hardware | Printer selection and settings UI | Cash drawer, ESC/POS, and terminal APIs are explicitly not connected | Missing integration |
| Setup / Modifiers | Works offline from local configuration | No queued convergence; all groups show for all items; no required/min/max rules | Incomplete |
| Setup / Promos | Works offline from local configuration | No queued convergence; saved category is not applied; discount covers full subtotal | Incomplete |
| Setup / Floor | Offline area labels | No queued convergence or actual table positioning | Incomplete |
| Setup / Audit | Recent event list | Best-effort and caller-spoofable | Blocked |
| Receipt | Print/PDF, business identity, tax/tip/tenders | Final RPC no longer assigns intended server receipt number | Blocked |
| Inventory | Cached stock, offline item creation/adjustment, movement views, and POS depletion | Purchases and stocktakes require internet; PIN ignored; impossible adjustments corrupt movement truth | Blocked |
| Manager PWA | Separate direct-Supabase manager client; not the offline POS terminal | No live POS/orders/cash-up/ticket oversight; current local install build fails | Commercial oversight gap |

## Important P1 product gaps

1. Promotions ignore `applies_to_category`; applying one simply sets a full-order discount (`src/renderer/src/components/POS.jsx:1487-1491`).
2. Modifier groups are displayed globally. Category assignment exists in storage but is not captured in the Setup form, and there are no required/min/max selection rules (`src/renderer/src/components/POS.jsx:3624-3638`, `:3693-3717`).
3. Hardware tests explicitly report that direct drawer kick, ESC/POS bridge, and live payment-terminal APIs are not implemented (`src/main/domains/pos.js:1799-1818`, `:1919-1940`).
4. Many POS loads convert errors into empty arrays/nulls. Operators can see “no orders”, “no tickets”, or “no cash-ups” when the backend actually failed.
5. No shift is required before completing a sale; `shift_id` is optional.
6. No authoritative tender reversal workflow exists for card/mobile-money refunds.
7. No server-side price history exists to validate offline sales made under an older menu price.
8. The Manager PWA has no order monitor, KDS view, live shift/cash-up approval, void/return review, or outlet comparison beyond aggregate reports.
9. Floor setup stores only area names; there is no positioned table map, capacity state, or reservation/check relationship.
10. The receipt needs explicit legal fields and retention rules per target country before it can be marketed as tax compliant.

## Required behavioral tests before a pilot

At minimum, add tests proving:

1. a cashier cannot change a menu price, tax, discount, tip, tender total, cashier identity, outlet, or timestamp;
2. empty, zero-quantity, negative-quantity, and cross-outlet normal sales are rejected;
3. concurrent sales cannot oversell stock;
4. an offline replay is idempotent and validates the historical price book;
5. two returns racing on the same line cannot exceed the remaining quantity;
6. a return correctly allocates original discount/tax and reverses each tender/folio;
7. receipt numbers are sequential, unique, replay-stable, and not reused after void/return;
8. shift close derives totals and rejects late/backdated sales;
9. a transient online cash-up failure is queued and replays once;
10. a kitchen/bar ticket created on terminal A appears and updates on terminal B;
11. table rounds append to one server check and transfer/merge atomically;
12. unauthorized roles and outlet-scoped supervisors cannot perform overrides;
13. audit entries are committed atomically with the financial mutation;
14. inventory adjustments cannot make the movement ledger disagree with stock;
15. menu availability, stock receiving, stocktake counts, and table transfers survive an offline crash and replay once;
16. every sellable app builds from a clean lockfile/install before publish.

## Recommended delivery order

### Phase 1 — Financial containment

- Replace `create_pos_order` with a server-priced, server-attributed sale RPC.
- Add dedicated return/refund RPCs.
- Restore receipt numbering.
- Make stock adjustments ledger-correct.
- Add exploit-focused database integration tests.

### Phase 2 — Cash and operations

- Keep shifts, tickets, and checks usable from durable local state without internet.
- Queue deterministic shift, ticket, cash-up, and check operations.
- Reconcile them through atomic server RPCs after authentication/reconnect.
- Implement atomic table moves/merges and queue every retriable failure.
- Make menu availability, stock receiving, and stocktake counting durable offline operations.

### Phase 3 — Authorization and audit

- Enforce capabilities and outlet assignment in every RPC.
- Implement locally rate-limited offline step-up approval with server-verifiable replay proof.
- Commit immutable audit events inside transactions.
- Correct manager Inventory access.

### Phase 4 — Commercial hardware and manager control

- Implement and certify the chosen printer/drawer and payment-terminal bridges.
- Add the Manager PWA's live POS oversight pages.
- Finish shared modifiers, promotions, and floor configuration.

### Phase 5 — Release qualification

- Repair the Manager PWA clean build.
- Add an isolated Supabase test environment and seeded tenant.
- Put all builds, tests, migrations, and UI smoke checks in the publish gate.
- Run a supervised single-site pilot, reconcile every sale/tender/stock movement, then expand.

## Final recommendation

Do not sell or deploy this version to a paying customer. The UI is far enough along for internal demonstrations, but the transaction authority, returns, cash-up, receipt, cross-terminal, permission, audit, inventory, and release defects make live operation financially unsafe.

Commercial work should begin with Phase 1, not with more UI features. Once all P0 items have behavioral tests and the release gate is green, the product can move to a tightly supervised pilot.
