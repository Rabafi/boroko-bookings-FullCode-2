# Luna Restaurant & Bar Multi-Agent Implementation Plan

**Prepared:** 29 July 2026

**Source audit:** `docs/RESTAURANT_BAR_COMMERCIAL_READINESS_AUDIT_2026-07-29.md`

**Target:** Commercially safe Restaurant and Bar modes in the Electron app, with online Manager PWA oversight

**Execution model:** Luna as integration lead plus at most three concurrent implementation agents

## 1. Mission and release boundary

Luna must convert the current broad POS feature set into a financially authoritative, offline-first commercial system.

The Electron application must continue daily Restaurant/Bar operations without internet. Safety must not be implemented by adding online-only checks. Every critical offline mutation must be:

1. validated against the latest trusted local state;
2. written durably to the local cache/ledger;
3. represented as a deterministic queued RPC operation;
4. replayed only after an authenticated session is restored;
5. idempotent under crash/retry/concurrent replay;
6. reconciled with the server result; and
7. surfaced for operator review if rejected or conflicted.

The Manager PWA remains a separate direct-Supabase client. It may provide online oversight, but it must not become an alternate client-side financial mutation path.

### Commercial no-go boundary

No paid deployment is allowed until Phases 0–7 pass their exit gates. Phase 8 features may be scoped for the first commercial tier, but any deferred hardware or manager feature must be explicitly described as unsupported rather than represented as connected.

## 2. Non-negotiable engineering rules

- All financial and stock mutations end in Supabase RPCs.
- No direct client update of financial totals, tender totals, stock balances, receipt numbers, return totals, or cash-up expectations.
- The server derives actor identity from the restored app session.
- The server validates lodge, outlet, role/capability, resource ownership, and operation version.
- Offline replay calls the same versioned RPC contract as online execution.
- Every critical operation has a stable UUID and a database uniqueness constraint.
- Every RPC that can be retried returns the original successful result on replay.
- Every mutation is atomic and concurrency-safe; rows are locked in a deterministic order.
- Applied migrations are never edited. Add new ordered migrations under `supabase/migrations/`.
- `src/main/database.js` remains a facade. Do not add business logic there.
- Treat `docs/DB_REFACTOR_RULES.md` as a structural safety rule: this plan authorizes targeted feature corrections in domain files, but not opportunistic renaming, repartitioning, or behavior-preserving refactors mixed into a financial change.
- Preserve unrelated and pre-existing worktree changes. Never reset or overwrite them.
- PWA financial mutation rejection remains enforced with `app_reject_pwa_financial_mutation()`.
- Restaurant and Bar must share one financial contract. Outlet type, station routing, and configuration may differ; transaction logic must not be copied into separate Restaurant and Bar implementations.
- UI calculations are provisional display calculations only. The persisted result comes from the RPC.
- A failed online RPC that is retryable must enter the same durable queue as an explicitly offline action.
- A server rejection is not silently converted to success or an empty list.

## 3. Target operation envelope

Freeze this envelope in Phase 0 before implementation agents begin:

```json
{
  "contract_version": 2,
  "operation_id": "uuid",
  "device_id": "stable-device-id",
  "device_event_at": "ISO-8601 timestamp",
  "lodge_id": "uuid",
  "outlet_id": "uuid",
  "payload": {}
}
```

Rules:

- `operation_id` is generated once before local mutation and reused online, offline, after restart, and after dead-letter retry.
- `device_id` must match a registered desktop device or trusted session metadata. It is not accepted merely because the caller supplied it.
- `device_event_at` is retained for ordering/audit but never silently overrides server time.
- `lodge_id` and `outlet_id` are checked against the authenticated session.
- Actor ID/name/role are not authoritative payload fields.
- Each domain RPC stores `operation_id` or writes to a shared operation receipt table with a unique constraint.
- The operation response contains `operation_id`, authoritative entity IDs, totals, receipt/reference numbers, accepted server time, and `idempotent`.

Recommended local queue metadata:

```json
{
  "_queue_id": "pos-sale-<operation_id>",
  "_depends_on": "pos-shift-open-<shift-operation-id>",
  "_state": "pending",
  "_contract_version": 2,
  "_entity_type": "pos_sale",
  "_entity_id": "uuid"
}
```

## 4. Multi-agent operating model

There are four concurrency slots including Luna. Luna may therefore run no more than three sub-agents at once.

### Luna owns

- contract decisions and changes to this plan;
- phase sequencing and agent prompts;
- high-contention integration files:
  - `package.json`
  - `src/main/database.js`
  - `src/main/index.js`
  - `src/preload/index.js`
  - `src/shared/accessControl.js`
  - GitHub workflows;
- migration timestamp reservation;
- final conflict resolution;
- staging/committing;
- full exit-gate execution;
- rollout and rollback decisions.

### Standard agent roles

1. **Database/RPC agent**
   - Owns only the new migration files reserved for the phase.
   - Adds SQL integration tests or fixtures without editing old migrations.
   - Does not modify Electron/PWA code.

2. **Electron/offline agent**
   - Owns the explicitly assigned domain file, such as `pos.js`, `inventory.js`, or `infrastructure.js`.
   - Implements durable local state, queue payloads, replay result reconciliation, and error propagation.
   - Does not invent or change the frozen RPC payload.

3. **Renderer/QA agent**
   - Owns the explicitly assigned renderer components and new tests.
   - Treats local totals as provisional.
   - Does not add direct Supabase financial mutations.

Luna may replace the Renderer/QA agent with a dedicated test agent in high-risk database phases.

### File ownership rules

- Only one active agent may edit a given file.
- `src/main/domains/pos.js` is single-writer per wave.
- `src/renderer/src/components/POS.jsx` is single-writer per wave.
- `src/main/domains/infrastructure.js` is single-writer for the entire queue-foundation phase.
- Agents may create separate migration files concurrently only after Luna reserves their timestamps and dependency order.
- Agents must not edit existing dirty files unless Luna explicitly assigns them.
- In a shared worktree, agents do not commit. Luna stages only reviewed paths after the wave completes.
- If Luna uses separate Git worktrees, each agent may commit only its assigned paths; Luna cherry-picks in dependency order.

### Required agent prompt format

Every sub-agent prompt must include:

```text
Goal:
Contract version/reference:
Allowed files:
Forbidden files:
Required invariants:
Tests to add/run:
Existing dirty changes to preserve:
Expected handoff:
Stop conditions:
```

Stop conditions must include: contract ambiguity, need to edit an unassigned file, observed migration dependency conflict, or a failing pre-existing test unrelated to the assigned work.

### Wave completion protocol

After each parallel wave Luna must:

1. stop spawning new work;
2. inspect `git status` and per-file diffs;
3. reject contract drift;
4. run phase-focused tests;
5. run the critical offline queue/POS gates;
6. update the phase evidence table;
7. commit one coherent integration unit; and
8. start the next wave only after the exit gate is green.

## 5. Dependency graph

```mermaid
flowchart TD
    P0["Phase 0: Baseline, contracts, isolated test backend"]
    P1["Phase 1: Capability, device-operation, audit foundation"]
    P2["Phase 2: Sale v2, pricing, tax, tenders, receipts"]
    P3["Phase 3: Returns, voids, approval proof"]
    P4["Phase 4: Inventory offline parity and ledger"]
    P5["Phase 5: Shifts and authoritative cash-up"]
    P6["Phase 6: Durable KDS and prep tickets"]
    P7["Phase 7: Restaurant check/table ledger"]
    P8["Phase 8: Shared config, Manager oversight, hardware scope"]
    P9["Phase 9: Release qualification and pilot"]

    P0 --> P1 --> P2
    P2 --> P3
    P2 --> P4
    P2 --> P5
    P2 --> P6
    P3 --> P7
    P5 --> P7
    P6 --> P7
    P4 --> P8
    P7 --> P8 --> P9
```

Phases 3 and 4 may run partly in parallel after the Phase 2 contract is stable because they own different domain files and migrations. Phases 5–7 must be integrated sequentially where they touch `pos.js` and `POS.jsx`.

---

## Phase 0 — Baseline, frozen contracts, and isolated test backend

### Objective

Create a reproducible baseline and prevent implementation against live customer data or ambiguous payload contracts.

### Luna tasks

- Capture `git status`, current branch, and the complete existing diff.
- Preserve the current uncommitted changes in:
  - package lockfiles;
  - `src/main/domains/authLogin.js`;
  - `src/main/domains/inventory.js`;
  - `src/main/domains/profiles.js`;
  - existing untracked migrations and documentation.
- Decide whether to commit/shelve existing user work or create a dedicated worktree. Do not reset it.
- Reserve ordered migration timestamps for Phases 1–7.
- Create `docs/pos/POS_CONTRACT_V2.md` containing exact request/response JSON examples and error codes.
- Create `docs/pos/OFFLINE_OPERATION_MATRIX.md` listing every page action and whether it:
  - reads cache;
  - writes cache;
  - queues an RPC;
  - has an idempotency key;
  - has a dependency;
  - refreshes/reconciles after replay;
  - supports crash recovery;
  - supports cross-device convergence.
- Define a clean test tenant or local Supabase stack. Tests must not use an installed customer profile.
- Add explicit environment protection so integration tests refuse known production Supabase URLs/lodge IDs.

### Parallel agents

**Agent A — Contract inventory**

- Read all POS/inventory RPC definitions and queue normalizers.
- Produce payload/response/error-code inventory only.
- Allowed files: new documents under `docs/pos/`.

**Agent B — Test backend**

- Build isolated seed/reset scripts for a dedicated test lodge.
- Add a guard that aborts if the target is not marked `BOROKO_TEST_TENANT=true`.
- Allowed files: new files under `tests/integration/`, `scripts/test/`, Supabase seed files.

**Agent C — Behavioral baseline**

- Map existing POS Playwright tests to real behavior versus source-pattern assertions.
- Add no product changes.
- Allowed files: new test matrix document and non-mutating test helpers.

### Baseline commands

- `npm test`
- `npm run test:offline-queue-critical`
- `npm run test:offline-pos-critical`
- `npm run test:inventory-offline-sync`
- `npm run test:import-critical`
- `npm run build`
- `npm run manager:lint`
- `npm run manager:build`
- `npm run booking:build`

Record failures as baseline facts. Do not hide a local dependency corruption by changing product code.

### Exit gate

- The v2 contract is frozen and reviewed.
- The isolated backend cannot target production accidentally.
- Existing dirty changes are preserved.
- Baseline results are recorded.
- No Phase 1 agent needs to invent a payload field.

---

## Phase 1 — Capability, device-operation, and audit foundation

### Objective

Give later financial RPCs one authoritative way to validate capabilities, device operations, actors, and idempotency.

### Database design

Add an append-only migration providing:

1. `app_registered_devices`
   - `id` or stable `device_id`;
   - `lodge_id`;
   - public verification key or trusted credential metadata;
   - `status`;
   - `registered_by`;
   - `registered_at`, `last_seen_at`, `revoked_at`;
   - unique `(lodge_id, device_id)`.

2. `app_operation_receipts`
   - `operation_id` primary key;
   - `lodge_id`, `device_id`, `operation_type`;
   - `entity_id`;
   - canonical response JSON;
   - accepted server time;
   - request hash;
   - unique operation ID prevents replay duplication.

3. `app_require_capability(p_lodge_id, p_capability, p_outlet_id default null)`
   - rejects PWA mutation when the capability is desktop-only;
   - loads the current, non-suspended user rather than trusting a stale payload role;
   - applies role defaults, capability overrides, feature entitlement, and outlet scope;
   - raises `42501` with a stable machine-readable error.

4. Immutable POS/stock audit helper
   - callable only from security-definer domain RPCs;
   - actor comes from `app_current_session_row()`;
   - device comes from verified session/device context;
   - no direct insert/update/delete grants to clients.

### Desktop design

- Create one stable device ID service instead of separately hashing paths in health code.
- If device signatures are adopted, generate a device keypair once and protect private material with Electron `safeStorage`.
- Registration happens during authenticated online setup.
- Offline actions continue if the trusted device registration and offline entitlement are cached and valid.
- Add a pure helper that creates operation envelopes but does not perform business calculations.
- Extend System Health with:
  - device registration state;
  - supported POS contract version;
  - count of legacy POS queue entries;
  - count of unsigned approval operations;
  - missing required RPCs.

### Multi-agent wave

**Agent A — Database security**

- Owns the Phase 1 migration only.
- Adds SQL tests for capability override, suspension, outlet scope, PWA rejection, device revocation, and idempotent operation receipts.

**Agent B — Desktop operation envelope**

- Owns a new device/operation helper module and assigned health code.
- Must not change `pos.js` yet.

**Agent C — Security tests**

- Adds integration tests for actor spoofing, capability denial, cross-lodge IDs, cross-outlet IDs, and duplicate operation IDs.

Luna integrates exports, IPC, preload, access snapshots, and package scripts.

### Exit gate

- A cashier cannot gain a capability through payload fields.
- A suspended/revoked user or device is rejected on replay.
- Duplicate operation IDs return the original response.
- Audit actor/device/time cannot be caller-authored.
- Offline mode still starts from trusted cached state.

---

## Phase 2 — Sale v2: server pricing, tax, tenders, stock, and receipts

### Objective

Replace the unsafe `create_pos_order` contract while retaining immediate offline sales.

### Rollout strategy

Do not overwrite the old function first.

1. Deploy additive `create_pos_order_v2`.
2. Backfill authoritative price history for current menu items.
3. Ship an Electron client that probes for v2 and uses it for all new sales.
4. Inspect and migrate/drain legacy queued `create_pos_order` operations.
5. Reject or manually review legacy queue entries that cannot be matched to a trusted price snapshot.
6. Disable the insecure v1 execution path after the queue is clear.

The client must never silently fall back from v2 to insecure v1. If v2 is unavailable:

- an offline device may continue creating v2 queue operations from its trusted catalog;
- an online device may queue locally and show “server contract unavailable”;
- replay remains blocked until the v2 health probe passes.

### Schema

Add:

- `pos_menu_price_history`
  - `id`, `lodge_id`, `outlet_id`, `menu_item_id`;
  - unit price;
  - effective-from/effective-to;
  - catalog/version identifier;
  - immutable after creation.
- versioned tax profile or equivalent authoritative tax snapshot;
- `operation_id`, `device_id`, authoritative cashier ID, and final `receipt_number` on POS orders;
- line financial columns:
  - gross subtotal;
  - modifier subtotal;
  - allocated discount;
  - allocated tax;
  - net subtotal;
  - price-history reference.

### `create_pos_order_v2` invariants

- Requires `pos.manage`.
- Rejects PWA financial mutation.
- Validates registered device and operation version.
- Rejects empty orders.
- Normal sale quantities must be positive.
- Known menu items must belong to the lodge and selected outlet.
- Inventory links must belong to the lodge/outlet.
- Unit prices come from referenced immutable price history, never `unit_price`.
- Modifier price deltas come from versioned modifier definitions.
- Discounts are semantic fields, not negative custom lines.
- Promotion/category applicability is evaluated server-side.
- Manual discount requires `pos.discount` and an approval event where configured.
- Tax comes from the referenced authoritative tax profile.
- Tip constraints are explicit and server-validated.
- Tender methods are an allowlisted enum.
- Non-folio tender totals must exactly equal the authoritative total after currency rounding.
- Required external references are validated for non-cash methods.
- Folio sale validates active booking and adds the charge atomically.
- Cashier is the current authenticated actor.
- Waiter must be a valid active lodge user if supplied.
- Inventory rows lock and decrement atomically with no negative stock.
- The receipt sequence is assigned once inside the transaction.
- The immutable audit event is committed in the same transaction.
- Idempotent replay returns the same order ID, total, and receipt number.

### Offline catalog rule

An offline cashier uses the last trusted catalog. The queued line carries the immutable price-history/catalog reference. If the server no longer has that version, replay becomes a reviewable conflict; it must not silently reprice the guest's completed offline sale or trust an arbitrary number.

### Desktop changes

- Keep existing optimistic local sale and stock reservation behavior.
- Replace `buildDiscountLine()` negative line behavior with a semantic discount object.
- Store authoritative catalog/tax references in cached menu data.
- Queue `create_pos_order_v2`.
- Treat all totals as provisional until RPC confirmation.
- On replay success:
  - update receipt number;
  - update authoritative totals and allocations;
  - clear pending state;
  - refresh inventory;
  - retain a reconciliation note if provisional values changed.
- On retryable online failure, queue the operation instead of throwing away the attempt.
- On server rejection, restore provisional stock exactly once and move the operation to review.

### Multi-agent wave

**Agent A — Sale v2 SQL**

- Owns the Phase 2 migration and SQL integration tests.

**Agent B — Electron sale adapter**

- Owns `src/main/domains/pos.js` for this wave plus assigned POS offline helpers.
- Does not edit the renderer.

**Agent C — Renderer and behavioral tests**

- Owns `POS.jsx`, receipt rendering, and new tests.
- Removes negative discount line submission.

Luna owns IPC/preload/facade integration and legacy queue migration wiring.

### Required tests

- Online cashier changes `unit_price` → server persists catalog price.
- Caller changes tax/tip/discount/tenders/cashier/time → rejected or server-derived.
- Cross-outlet menu item → rejected.
- Zero/negative/empty normal sale → rejected.
- Two concurrent last-unit sales → one succeeds.
- Same operation submitted concurrently → one order/receipt.
- Offline sale under old but valid price version → accepted with that historical price.
- Unknown/tampered price version → review conflict.
- Offline crash before/after queue write → exactly one final sale.
- Folio charge and POS order commit/rollback together.
- Final receipt number is stable after replay.

### Exit gate

- No normal code path calls insecure v1 for new sales.
- All tampering tests pass.
- Online and offline v2 sales reconcile identically.
- Receipt numbering is restored.
- Existing offline POS gates remain green.

---

## Phase 3 — Returns, voids, and offline approval proof

### Objective

Prevent excessive refunds and make returns/voids atomic, attributable, and fully usable offline.

### Schema

Add:

- `pos_returns`;
- `pos_return_items`;
- `pos_return_tenders`;
- optional credit-note/return receipt sequence;
- original order/item foreign keys;
- unique operation ID;
- unique/guarded quantities and immutable audit links.

Persist the original sale allocation on each order line so a return can reverse:

- gross amount;
- modifier amount;
- discount allocation;
- tax allocation;
- net amount;
- stock depletion.

### `return_pos_order_items_v2`

- Requires a verified approval with `pos.void` or a dedicated `pos.return` capability.
- Locks original order and selected order items.
- Sums previously committed return quantities.
- Rejects any quantity above the remaining returnable amount.
- Uses original authoritative financial allocations.
- Restores inventory once.
- Creates a negative folio charge/credit atomically for folio sales.
- Records refund tender and external reversal status.
- Supports `pending_external_refund` where a terminal/mobile-money reversal is manual.
- Creates an immutable return receipt/credit reference.
- Is idempotent.

### Void changes

- Require non-empty reason server-side.
- Validate approver outlet assignment server-side.
- Derive requester and accepted time from trusted context.
- Prevent void after a settled/returned state that requires a return instead.
- Preserve the existing row lock, stock restoration, and folio reversal.

### Offline approval proof

Do not queue plaintext PINs.

1. Verify the PIN locally against a trusted cached hash.
2. Apply local attempt delay and persistent lockout counters.
3. Build an approval assertion containing operation, entity, approver, outlet, reason, device, and time.
4. Sign the assertion with the registered device credential.
5. Queue only the assertion/signature, never the PIN.
6. On replay, verify device registration, signature, approver status/capability/outlet, and assertion contents.

If device signing is not accepted as sufficient risk control, the product must clearly mark offline refunds/voids as pending approval and not release external cash until online approval. Luna must make this product decision explicitly; agents must not improvise.

### Multi-agent wave

**Agent A — Return/void SQL**

- Owns the Phase 3 migration.

**Agent B — Desktop return/approval**

- Owns the assigned `pos.js` sections and device-approval helper.

**Agent C — History UI and race tests**

- Owns return/void modal changes and tests.

### Required tests

- Same item returned twice → second return sees only remaining quantity.
- Two concurrent full returns → only one succeeds.
- Return allocation exactly reverses original discount/tax.
- Return of folio sale creates one credit.
- Tampered approver/outlet/reason/assertion → rejected.
- Offline PIN never appears in sync queue or support bundle.
- Offline return survives crash and replays once.
- External refund remains pending until reference/status is recorded.

### Exit gate

- Normal sale RPC rejects all negative quantities.
- All returns use the dedicated RPC.
- Cumulative return quantities cannot exceed sale quantities.
- No plaintext approval secret is persisted.

---

## Phase 4 — Inventory offline parity and ledger correctness

### Objective

Make stock receiving, availability, adjustments, and stocktake counting operational offline while preserving an authoritative movement ledger.

### Required operations

1. `record_inventory_purchase_v2`
   - deterministic purchase and movement IDs;
   - local optimistic stock increase;
   - exact RPC queue/replay;
   - supplier/reference/cost validation;
   - authoritative weighted/latest cost update.

2. `adjust_inventory_stock_v2`
   - locks item;
   - rejects impossible decrement or records the actual applied delta;
   - movement quantity must equal stock change;
   - reason and approval required;
   - no ignored PIN field.

3. Offline menu availability
   - `set_pos_menu_item_availability_v2`;
   - local toggle and queue;
   - version/expected timestamp to detect conflicting manager changes.

4. Offline stocktake
   - create session locally with deterministic ID;
   - cache item snapshot;
   - capture counts and count timestamps offline;
   - queue start/count operations;
   - post locally as `pending_server_confirmation`;
   - server post locks items and evaluates intervening movements;
   - conflicts become `requires_review`, never silent overwrites.

5. Existing inventory item edits
   - queue non-financial metadata changes with expected version;
   - price changes append price history and must order correctly before dependent sales.

### Queue dependencies

- Sale of a newly created offline inventory/menu item depends on its create operation.
- Sale under an offline price change depends on the price-history/menu-update operation.
- Stocktake post depends on session creation and all count saves.
- Delete/deactivate depends on all earlier operations for that entity.

### Multi-agent wave

**Agent A — Inventory SQL**

- Owns Phase 4 migration and database race tests.

**Agent B — Inventory domain**

- Owns `src/main/domains/inventory.js`.
- Must preserve current user changes already in that file.

**Agent C — Inventory UI/offline tests**

- Owns `Inventory.jsx` and new inventory Playwright tests.

Luna owns IPC/preload/facade changes and manager capability defaults.

### Required tests

- Receive stock offline, crash, restart, replay → one purchase/movement.
- Impossible decrement → stock and movement ledger remain equal.
- Offline availability toggle affects POS immediately and replays.
- New offline item then sale → dependency ordering succeeds.
- Stocktake with intervening sale → review conflict, not blind overwrite.
- Stocktake count/post survives crash.
- Manager has correct default Inventory access.

### Exit gate

- Purchase and stocktake counts no longer require internet.
- Stock balance equals opening stock plus authoritative movement sum.
- Price changes and dependent sales replay in deterministic order.

---

## Phase 5 — Server shifts and authoritative cash-up

### Objective

Keep cashiers operational offline while making expected tenders and close periods server-authoritative.

### RPCs

1. `open_pos_shift_v2`
   - deterministic shift ID/operation;
   - one active shift per cashier/outlet/device according to explicit policy;
   - server actor identity;
   - opening float;
   - idempotent.

2. `close_pos_shift_and_cashup_v2`
   - locks shift;
   - defines close boundary;
   - derives orders, returns, voids, and expected tenders from authoritative rows;
   - accepts counted tenders and notes;
   - computes variance;
   - seals the shift;
   - writes audit;
   - idempotent.

### Offline behavior

- Open shift immediately in local state and queue it.
- Every sale depends on the open-shift operation.
- Close shift locally with counted values and mark expected values provisional.
- Queue close behind all known shift sales/returns.
- If another terminal has unknown authoritative activity, replay may adjust expectations and require review.
- A transient online RPC failure must be queued.
- No new sale may attach to a locally closed shift; it requires a new local shift.

### Multi-agent wave

**Agent A — Shift/cash-up SQL**

- Owns Phase 5 migration.

**Agent B — Desktop cash operations**

- Owns assigned shift/cash-up sections in `pos.js`.

**Agent C — Cash-Up UI/tests**

- Owns Cash-Up and Shift UI plus tests.

### Required tests

- Open offline → sales → close offline → replay in dependency order.
- Expected totals cannot be supplied/tampered by client.
- Split tender totals appear in correct buckets.
- Return and void affect the proper shift.
- Retry close → one sealed cash-up.
- Sale after local close cannot enter old shift.
- Concurrent closes → one succeeds/idempotent response.

### Exit gate

- Server cash-up equals independent query of authoritative sales/returns.
- No cash-up can be lost on transient failure.
- Closed shifts are immutable except an audited administrative correction workflow.

---

## Phase 6 — Durable kitchen/bar tickets and cross-terminal convergence

### Objective

Retain immediate same-device offline KDS behavior and add durable replay/cross-terminal state.

### Model

- Ticket IDs are deterministic from order/check round plus station.
- The local ticket is created before sale completion returns to the cashier.
- Sale/check-round RPC creates or reconciles the same server ticket atomically.
- Ticket status is an event operation, not an unversioned overwrite.
- Status transitions are validated:
  - `new → preparing → ready → served`;
  - `cancelled` is terminal and permission-gated.
- Events carry sequence/version and operation IDs.
- Offline status events enter the shared queue and may propagate through the existing local mesh when enabled.
- Server/realtime refresh merges remote tickets without overwriting pending local transitions.

### Routing

- Station is derived from configured item/station mapping, not category-name regex.
- One order/check round may create both Kitchen and Bar tickets.
- Modifier/instruction snapshots are immutable on the ticket.
- Re-fired/changed items create explicit delta tickets rather than silently editing an acknowledged ticket.

### Multi-agent wave

**Agent A — Ticket SQL**

- Owns Phase 6 migration.

**Agent B — Ticket domain/reconciliation**

- Owns ticket sections in `pos.js` and assigned sync reconciliation helper.

**Agent C — KDS UI/two-device tests**

- Owns `POSDisplays.jsx`, Tickets page changes, and tests.

### Required tests

- Offline order creates visible local Kitchen/Bar tickets immediately.
- Replay creates one server ticket per station.
- Terminal B sees Terminal A ticket after reconnect.
- Offline preparing/ready transition survives restart.
- Concurrent status events resolve deterministically.
- Instructions/modifiers remain identical to the submitted round.

### Exit gate

- Same-device KDS remains fully offline.
- Cross-terminal tickets converge after reconnect.
- No duplicate tickets appear after replay.

---

## Phase 7 — Restaurant check and table ledger

### Objective

Replace draft cart snapshots with an offline-first restaurant check supporting multiple rounds and final settlement.

### Domain model

Add:

- `pos_checks`
  - open/settled/voided state;
  - table, customer, waiter, outlet, shift;
  - version and operation IDs.
- `pos_check_items`
  - immutable item/price/modifier snapshots;
  - ordered/voided/returned quantities;
  - round reference.
- `pos_check_rounds`
  - submitted-to-prep event and status.
- `pos_check_events`
  - open, add round, transfer, merge, waiter change, settle, close;
  - deterministic operation ID and sequence.

### Required operations

- `open_pos_check_v2`
- `add_pos_check_round_v2`
- `transfer_pos_check_v2`
- `merge_pos_checks_v2`
- `settle_pos_check_v2`
- `void_pos_check_item_v2`

### Semantics

- Opening a table creates a durable local check and queued operation.
- Adding a round creates immutable check lines and prep tickets but does not count revenue as settled.
- Final settlement calls the authoritative sale/tender logic and assigns receipt number.
- Transfer locks source check/table.
- Merge locks both checks in sorted UUID order to avoid deadlocks.
- One active check per outlet/table is enforced server-side.
- Offline duplicate table opens become explicit conflicts; no silent merge.
- Manager close cannot discard ordered financial lines.
- Completing one round does not clear or close the table check.

### Renderer changes

- Separate “Send to Kitchen/Bar” from “Settle/Pay”.
- Show round/ticket state.
- Display check subtotal, provisional discount/tax, and final settlement.
- Keep table selected after a round.
- Manager transfer/merge/close requires correct capability/approval.
- Expose pending-sync/conflict status per table.

### Multi-agent wave

**Agent A — Check ledger SQL**

- Owns Phase 7 migration and concurrency tests.

**Agent B — Check domain**

- Owns table/check sections in `pos.js`.

**Agent C — Terminal/table UI**

- Owns assigned `POS.jsx` sections and table Playwright tests.

### Required tests

- Open table offline, submit two rounds, restart, settle → one final check/order.
- Round creates correct Kitchen/Bar tickets.
- Completing a round does not recognize settled revenue.
- Atomic transfer and merge under concurrency.
- Two offline devices open same table → reviewable conflict.
- Waiter/cashier/outlet attribution remains correct.
- Settlement replay produces one receipt/tender set.

### Exit gate

- Restaurant tables support multiple rounds and one authoritative settlement.
- Transfer/merge are atomic and queue-safe.
- No table override can silently discard financial activity.

---

## Phase 8 — Shared configuration, Manager oversight, and hardware scope

### Objective

Finish commercial operational features without compromising the financial core.

### Shared configuration

Persist and version through RPCs:

- modifier groups and options;
- required/min/max modifier rules;
- item/category applicability;
- promotions and category/time applicability;
- floor areas, positioned tables, and layout;
- station routing;
- device-specific hardware settings where appropriate.

Configuration should load from cache offline. Authorized edits may either:

- queue offline with version conflict detection; or
- be explicitly classified as online setup-only.

The classification must be documented per action. It must not be accidental.

### Manager PWA

Add online, read-only oversight first:

- live orders/checks;
- open shifts;
- cash-up exceptions;
- returns/void approvals history;
- outlet comparisons;
- KDS aging;
- sync/device health.

Do not expose POS financial mutation RPCs to PWA sessions. Any later remote approval feature requires a separately designed approval RPC and audit policy.

### Hardware

Choose and document the commercial tier:

1. **MVP/manual**
   - system receipt printer;
   - manually opened drawer;
   - external terminal/mobile-money entry with mandatory reference/proof;
   - UI must not claim provider API connectivity.

2. **Integrated**
   - supported ESC/POS bridge;
   - drawer kick after committed eligible cash sale;
   - named payment provider API;
   - idempotent payment intent and webhook reconciliation;
   - terminal cancellation/refund states.

Do not ship placeholder “test succeeded” messages as proof of connected hardware.

### Multi-agent wave

- Agent A: configuration RPCs and versioning.
- Agent B: Electron configuration/offline cache.
- Agent C: Manager PWA read-only pages or hardware adapter, depending commercial scope.

### Exit gate

- Product documentation exactly matches supported hardware.
- Promotions/modifiers are server-validated at settlement.
- Manager pages cannot mutate financial state.
- Shared configuration converges after reconnect.

---

## Phase 9 — Release qualification and supervised pilot

### Objective

Prove the complete system against clean installs, concurrency, outages, and real operator reconciliation.

### Release pipeline

- Keep the documented GitHub publish workflow as the only supported publish path.
- Remove or gate the local `release.mjs` bypass.
- Require:
  - clean `npm ci` for all apps;
  - all critical regression suites;
  - isolated SQL integration tests;
  - behavioral offline POS/inventory tests;
  - desktop production build;
  - Manager PWA lint/build;
  - booking-site build;
  - dependency audit;
  - migration lint/advisors;
  - installer smoke test.
- Add branch protection requiring the full workflow.
- Store test artifacts: traces, screenshots, SQL results, reconciliation manifest.

### Upgrade safety

Before enabling v2:

- export the offline safety manifest;
- count pending/failed legacy POS queue items;
- back up local caches and database;
- deploy additive database migrations first;
- verify RPC health probes;
- migrate/drain legacy queue items;
- deploy desktop;
- disable insecure v1 only after evidence shows no pending legacy operations.

Rollback:

- do not roll back destructive migrations;
- feature-disable v2 UI if required;
- keep queued v2 operations intact;
- restore prior desktop only if it cannot call insecure v1;
- never clear pending financial operations to make health green.

### Pilot protocol

Use one supervised site and reconcile daily:

- receipt sequence;
- order gross/discount/tax/net;
- tenders versus cash/card/mobile-money;
- room folio charges;
- returns/voids;
- cash-up variance;
- inventory opening + purchases − sales + returns/adjustments;
- pending and failed queue items;
- device/check/ticket convergence.

Pilot failure triggers:

- duplicate or missing receipt;
- return above sold quantity;
- stock movement mismatch;
- cash-up mismatch without explained variance;
- unresolved financial queue item;
- table/check loss;
- cross-outlet authorization breach.

Any trigger stops expansion and opens an incident with preserved device ID, lodge ID, queue state, app version, logs, and backup.

### Final exit gate

- Zero unresolved P0 findings.
- All Phase 0–8 tests green from a clean environment.
- No production/customer tenant used for automated destructive testing.
- Seven consecutive supervised operating days reconcile without unexplained financial or stock drift.
- Support, backup, restore rehearsal, signing, and upgrade/rollback procedures are complete.

## 6. Required test suites and package scripts

Luna should add explicit scripts rather than hiding new coverage inside broad commands:

```json
{
  "test:pos-contract-v2": "node tests/pos-contract-v2.test.mjs",
  "test:pos-db-integration": "node tests/integration/pos-db-integration.mjs",
  "test:pos-offline-behavior": "playwright test --config \"Playwright tests/playwright.config.cjs\" --grep \"POS v2 offline\"",
  "test:inventory-offline-behavior": "playwright test --config \"Playwright tests/playwright.config.cjs\" --grep \"inventory offline v2\"",
  "test:pos-concurrency": "node tests/integration/pos-concurrency.mjs"
}
```

Final names may differ, but the release workflow must call them explicitly.

### Mandatory coverage classes

- contract validation;
- SQL tamper resistance;
- concurrency/race behavior;
- duplicate replay;
- crash recovery;
- transient-online-failure queue fallback;
- dependency ordering;
- dead-letter and manual retry;
- cross-device convergence;
- access/capability/outlet denial;
- financial reconciliation;
- stock movement reconciliation;
- clean upgrade with legacy queue entries.

## 7. Phase evidence template

Luna must update this after each phase:

| Field | Evidence |
|---|---|
| Phase | |
| Commit(s) | |
| Migration(s) | |
| RPC contract version | |
| Files changed | |
| Tests added | |
| Tests passed | |
| Offline crash test | |
| Duplicate replay test | |
| Concurrency test | |
| Access-control test | |
| Reconciliation result | |
| Remaining risks | |
| Rollback path | |
| Go/no-go | |

## 8. Luna's first execution prompt

Luna can begin with:

```text
Read AGENTS.md, CLAUDE.md, docs/DB_REFACTOR_RULES.md,
docs/RESTAURANT_BAR_COMMERCIAL_READINESS_AUDIT_2026-07-29.md, and
docs/LUNA_RESTAURANT_BAR_MULTI_AGENT_IMPLEMENTATION_PLAN.md completely.

Execute Phase 0 only. Do not implement financial fixes yet.

Use at most three sub-agents:
1. inventory the current POS/RPC/queue contracts;
2. create an isolated non-production integration-test harness;
3. map existing POS tests to the required behavioral matrix.

Preserve all existing dirty work. Do not edit applied migrations. Do not allow
two agents to edit the same file. Return a frozen v2 contract, baseline test
results, exact migration timestamp reservations, and a Phase 0 go/no-go.
```

## 9. Final implementation principle

The product is not made safe by moving logic online. It is made safe by combining durable local operations with deterministic, authenticated, idempotent, atomic reconciliation.

Every Luna agent should be evaluated against both halves:

- **Can the operator finish the task while disconnected?**
- **Will every authorized device and the database agree on the financial truth after reconnect?**

If either answer is no, the phase is not complete.
