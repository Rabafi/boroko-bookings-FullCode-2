# Luna migration timestamp reservations

Reserved during Phase 0 on 29 July 2026. Existing migrations are immutable. Each phase must
create a new additive migration using its reserved filename prefix; if a phase needs more than one
migration, it must use a later suffix within the same reserved minute and record the dependency here
before writing SQL.

| Phase | Reserved prefix | Scope |
| --- | --- | --- |
| 1 | `20260729090000_` | registered devices, operation receipts, capability/audit helpers |
| 2 | `20260729090100_` | price history, tax snapshots, sale v2 and receipt contract |
| 3 | `20260729090200_` | returns, voids, approval proof |
| 4 | `20260729090300_` | inventory purchase/stocktake ledger and idempotent stock operations |
| 5 | `20260729090400_` | server shifts and authoritative cash-up |
| 6 | `20260729090500_` | durable kitchen/bar tickets and station routing |
| 7 | `20260729090600_` | restaurant checks, tables, transfers, merges |

The existing dirty migrations `20260607170000_authenticate_user_for_device.sql` and
`20260611120000_inventory_items_updated_at.sql` remain untouched and are not part of these
reservations.

