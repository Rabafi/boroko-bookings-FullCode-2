# Phase 6 evidence — Durable KDS tickets

Migration: `20260729090500_phase6_tickets_v2.sql`.

The migration adds configured station routing, deterministic ticket IDs, immutable item/modifier/instruction snapshots, append-only ticket events, transition validation, cancellation permission checks, and idempotent create/status RPCs. Static contract tests pass. Electron still needs the ticket RPC adapter/replay wiring and the KDS renderer needs to consume authoritative ticket events before this phase is commercial-ready; live two-terminal convergence remains pending isolated backend tests.
