# Phase 1 evidence — device, operation, and audit foundation

Captured 29 July 2026. This phase is source/test green; the migration still requires deployment
to the disposable Supabase backend before online integration tests can run.

## Changes

- `supabase/migrations/20260729090000_phase1_device_operations_audit.sql`
  - registered desktop devices with lodge/device uniqueness and revocation state;
  - idempotent operation receipts with request hash and canonical response;
  - append-only audit events deriving actor/device/server time from the authenticated session;
  - capability checks for role, entitlement, PWA rejection, lodge/outlet scope, and device state;
  - authentication overloads that attach the stable device ID to desktop session metadata.
- `src/shared/operationEnvelope.js` — pure v2 envelope creation/validation/replay reuse.
- `src/main/domains/deviceIdentity.js` — UUID device identity with crash-safe fsync/rename persistence
  and trusted registration cache.
- `src/main/domains/health.js` — stable device identity and contract/legacy queue health fields.
- `src/main/domains/authLogin.js` — sends device metadata during online session bootstrap and registers
  the device without preventing a login when an older backend has not received the migration.

## Tests

| Test | Result |
| --- | --- |
| `npm run test:phase1-device-operation` | PASS |
| `npm run test:phase1-security-contract` | PASS (6 passed, 1 disposable-backend test skipped by guard) |
| `npm run build` | PASS |

The disposable security RPC test correctly skips against the current `.env` because the environment
is marked `BOROKO_TEST_TENANT=false` and uses the known production project. No customer data was
mutated.

## Remaining integration gate

Apply the additive migration to a dedicated test tenant, set `BOROKO_TEST_TENANT=true` and
`BOROKO_TEST_LODGE_ID` outside `.env`, issue a short-lived desktop session with device metadata, then
run the actor-spoof, cross-lodge/outlet, revocation, and duplicate-operation tests before Phase 2.

