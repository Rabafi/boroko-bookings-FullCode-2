# Phase 3 evidence — Returns, voids, and approval proof

| Field | Evidence |
|---|---|
| Phase | 3 — authoritative returns/voids |
| Migration(s) | `20260729090200_phase3_returns_voids_v2.sql` |
| RPC contract version | Return/void operation envelopes, version 2 |
| Files changed | `pos.js`, `approvalProof.js`, POS renderer, preload/IPC/database facade, migration |
| Tests passed | SQL contract, Electron approval contract, renderer return contract, production build |
| Offline crash test | Durable queue and approval proof helper are covered statically; live isolated replay pending |
| Duplicate replay test | Operation receipts and unique operation IDs defined for returns/voids |
| Concurrency test | Source order/item locks and cumulative remaining-quantity checks defined |
| Access-control test | Server approval assertion/capability/outlet checks defined; live tenant pending |
| Reconciliation result | Offline operations are pending/reviewable; authoritative return/void response controls final state |
| Remaining risks | Migration not applied; device signature verification requires registered credential metadata; legacy PIN IPC remains for compatibility but never queues a PIN |
| Rollback path | Feature-disable return/void v2 UI; preserve pending operations for supervised retry |
| Go/no-go | Code gate green; production gate blocked on isolated SQL and supervised refund reconciliation |
