# Phase 9 release qualification checklist

This checklist is intentionally fail-closed. A commercial build is no-go until:

- the isolated Supabase tenant is explicitly marked `BOROKO_TEST_TENANT=true`;
- migrations `20260729090000` through `20260729090700` apply cleanly;
- online/offline duplicate replay, crash recovery, concurrency, access, and reconciliation suites pass;
- desktop build, Manager PWA build, booking-site build, dependency audit, and installer smoke test pass;
- legacy `create_pos_order` queue entries are counted and drained or manually reviewed;
- hardware documentation states the supported MVP/manual tier (no claimed provider integration);
- seven supervised operating days reconcile receipts, tenders, returns/voids, cash-up, stock, checks, tickets, and pending queue items.

Rollback is feature-disable plus preservation of queued v2 operations. Do not clear a queue or re-enable the insecure v1 sale path to make health green.
