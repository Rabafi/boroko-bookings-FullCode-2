# Phase 4 evidence — Inventory offline parity

| Field | Evidence |
|---|---|
| Phase | 4 — purchases and stock adjustments |
| Migration(s) | `20260729090300_phase4_inventory_offline_v2.sql` |
| RPC contract version | `record_inventory_purchase_v2`, `adjust_inventory_stock_v2`, `set_pos_menu_item_availability_v2`, envelope version 2 |
| Files changed | `inventory.js`, sync queue classifiers, migration |
| Tests passed | `test:phase4-inventory-contract`, Electron build |
| Offline crash test | Purchase/adjustment write provisional cache then durable v2 queue entry; live restart test pending isolated tenant |
| Duplicate replay test | Shared operation receipt claim/record and unique purchase operation index |
| Concurrency test | Inventory rows lock before stock mutation; negative balances reject atomically |
| Access-control test | PWA rejection and capability checks are server-side |
| Reconciliation result | Inventory movement ledger is written by RPC; local rows carry pending metadata until replay |
| Remaining risks | Offline stocktake session/count/post and menu availability UI still need full v2 queue integration; migration not applied |
| Rollback path | Disable offline inventory mutation controls while retaining queued operations |
| Go/no-go | Partial code gate; do not ship until stocktake and availability conflict paths are complete |
