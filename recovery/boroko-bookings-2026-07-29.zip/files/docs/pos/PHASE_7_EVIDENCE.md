# Phase 7 evidence — Restaurant check/table ledger

Migration: `20260729090600_phase7_restaurant_checks_v2.sql`.

The migration adds durable checks, rounds, immutable check items, event sequencing, active-table uniqueness, offline-safe open/round/transfer/settle RPCs, and settlement through the authoritative sale RPC. Static contract tests pass. Merge, void-item, full renderer table workflow, and live concurrent-table tests remain before a commercial go decision.
