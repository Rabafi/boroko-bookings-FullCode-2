# POS and inventory contract inventory — v2 freeze

Status: Phase 0 inventory only. This document records the current repository contract and the
target envelope frozen by `docs/LUNA_RESTAURANT_BAR_MULTI_AGENT_IMPLEMENTATION_PLAN.md`. It does
not claim that the v2 contract is implemented yet. The current client still sends the legacy
RPC shapes described below.

Sources inspected:

- `src/main/domains/pos.js`
- `src/main/domains/inventory.js`
- `src/main/domains/syncShared.js`
- `src/main/domains/infrastructure.js`
- `src/shared/syncQueue.js`
- `supabase/migrations/20260526101632_baseline_20260526_remote_schema.sql`
- `supabase/migrations/20260604120000_pos_inventory_launch_readiness.sql`
- `supabase/migrations/20260604143000_pos_table_sessions.sql`
- `supabase/migrations/20260604153000_pos_world_class_features.sql`
- `supabase/migrations/20260604201454_pos_void_pin_server_verification.sql`

Only the active files under `supabase/migrations/` were treated as the current repository
contract. The similarly named files under `supabase/migrations_archive/2026-05-26-pre-baseline/`
are historical alternatives and were not treated as deployed behavior; in particular, archived
inventory-idempotency SQL must not be assumed to be active until the database baseline is verified.

## 1. Frozen operation envelope

Every critical Restaurant and Bar operation must use the same envelope. `outlet_id` is nullable
for lodge-wide operations, but a cashier/supervisor request is still checked against the
authenticated outlet scope by the server.

```json
{
  "contract_version": 2,
  "operation_id": "00000000-0000-0000-0000-000000000001",
  "device_id": "registered-device-id",
  "device_event_at": "2026-07-29T13:00:00.000Z",
  "lodge_id": "00000000-0000-0000-0000-000000000010",
  "outlet_id": "00000000-0000-0000-0000-000000000020",
  "payload": {}
}
```

Rules frozen by the plan:

- `operation_id` is generated once before local mutation and is reused for online execution,
  offline replay, restart recovery, and dead-letter retry.
- `device_id` is accepted only after server-side device/session verification.
- `device_event_at` is retained for ordering/audit; it never overrides server time.
- `lodge_id` and `outlet_id` are checked against the authenticated session.
- Actor identity, role, and approval identity are server-derived; they are not authoritative
  payload fields.
- Each mutation stores `operation_id` (or a shared operation receipt with a unique constraint).
- A v2 response must include the operation ID, authoritative entity IDs, authoritative totals,
  receipt/reference numbers where applicable, accepted server time, and `idempotent`.

The target response shape is therefore:

```json
{
  "success": true,
  "operation_id": "00000000-0000-0000-0000-000000000001",
  "entity_id": "00000000-0000-0000-0000-000000000030",
  "total": 15.0,
  "receipt_number": "R-000001",
  "accepted_at": "2026-07-29T13:00:01.000Z",
  "idempotent": false
}
```

`receipt_number` and `entity_id` are operation-specific. They are shown here because the plan
requires them; the current RPCs do not consistently return them.

## 2. Current queue/replay contract

The Electron queue currently stores `{ type: 'rpc', table: <function>, data: <RPC args> }` plus
local metadata such as `_queue_id`, `_depends_on`, retry state, and sync state. Replay calls:

```js
state.supabase.rpc(item.table, item.data)
```

Current queue classifiers (`src/main/domains/syncShared.js`):

| RPC | Classifier | Current stable local key | Dependency/reconciliation |
| --- | --- | --- | --- |
| `create_pos_order` | POS create | `_queue_id = pos-order-<order id>`; RPC `create_idempotency_key = pos-order:<submit intent>` | Booking dependency may be set; order and inventory caches refresh after replay |
| `approve_pos_void_with_pin` | POS void | `_queue_id = pos-void-<order id>`; `override_log_id` in payload | Depends on a pending order where applicable; order, void history, inventory refresh |
| `upsert_pos_cashup` | Financial table set | `_queue_id = pos-cashup-<id>`; row `id` | No explicit dependency; POS refresh is not an authoritative cash-up reconciliation |
| `create_inventory_item` | Inventory item | `_queue_id = inventory-item-<id>`; payload `id` is client-generated | Inventory refresh after replay; current SQL does not use the payload ID for insert idempotency |
| `adjust_inventory_stock` | Inventory adjustment | `_queue_id = inventory-adjust-<adjustment id>` | Inventory refresh; delta can be applied twice on duplicate replay |
| `upsert_pos_tab` | Table/tab support | `_queue_id = pos-tab-<id>` | No operation receipt; local tab is retained on remote failure |
| `update_pos_tab_status` | Table/tab support | `_queue_id = pos-tab-status-<id>-<status>` | No operation receipt; repeated status operations are not coalesced |
| `upsert_pos_table` | Table support | `_queue_id = pos-table-<id>` | No server delete operation; local delete is not convergent |

`src/shared/syncQueue.js` marks POS sale/void/cash-up as financial. Inventory item creation and
stock adjustment are not in that financial set even though they mutate stock. There is no queue
normalizer that adds the v2 envelope, operation ID, device ID, or outlet context.

## 3. POS RPC inventory

### 3.1 `create_pos_order(payload)`

Current call (online and queued replay):

```json
{
  "payload": {
    "id": "00000000-0000-0000-0000-000000000030",
    "lodge_id": "00000000-0000-0000-0000-000000000010",
    "room_id": null,
    "booking_id": null,
    "walk_in_name": "Walk-in guest",
    "total": 15.0,
    "gross_total": 15.0,
    "discount_total": 0,
    "tax_rate": 0,
    "tax_total": 0,
    "tip_total": 0,
    "notes": null,
    "payment_method": "cash",
    "payment_breakdown": [{ "method": "cash", "amount": 15.0, "reference": null }],
    "outlet_id": "00000000-0000-0000-0000-000000000020",
    "service_mode": "takeaway",
    "table_name": null,
    "tab_name": null,
    "waiter_name": null,
    "cashier_id": "00000000-0000-0000-0000-000000000040",
    "cashier_name": "Cashier",
    "shift_id": null,
    "ticket_status": "new",
    "create_idempotency_key": "pos-order:00000000-0000-0000-0000-000000000050",
    "created_at_client": "2026-07-29T13:00:00.000Z",
    "items": [
      {
        "menu_item_id": "00000000-0000-0000-0000-000000000060",
        "inventory_item_id": null,
        "depletion_qty": 1,
        "item_name": "Coffee",
        "category": "Drinks",
        "modifiers": [],
        "item_notes": null,
        "quantity": 1,
        "unit_price": 15.0
      }
    ]
  }
}
```

The server requires lodge role `cashier`, `supervisor`, `manager`, `admin`, or `super_admin` and
checks POS outlet scope. For a folio sale it resolves/validates an active booking, creates a
`booking_charges` row, and stores the resulting `folio_charge_id`. For a normal sale it validates
the current menu price (except replay behavior), writes the order/items, and decrements linked
inventory atomically.

First successful response (current):

```json
{
  "success": true,
  "id": "00000000-0000-0000-0000-000000000030",
  "total": 15.0,
  "booking_id": null,
  "folio_charge_id": null
}
```

Idempotent replay response (current):

```json
{
  "success": true,
  "id": "00000000-0000-0000-0000-000000000030",
  "total": 15.0,
  "idempotent": true,
  "replayed": true
}
```

Current returned/raised errors include:

- `Room folio charge requires an active booking`;
- `Active booking not found for folio charge`;
- `Existing POS order is incomplete and needs review before replay`;
- `Existing folio POS order is missing its booking charge and needs review`;
- `<item> is not currently available for sale.`;
- `POS menu item <id> not found for lodge <id> - order rejected`;
- `Not enough stock left for <item>. Refresh the POS and try again.`;
- SQLSTATE `42501` from lodge/role/outlet access checks.

The Electron offline path returns `{ success: true, id, offline: true }` immediately, writes a
completed-looking local order, reserves local stock, and queues the same legacy payload. The local
response is provisional and has no server receipt number or accepted server time.

Current gaps: no v2 envelope; actor/cashier fields are caller supplied; no server receipt number;
no explicit operation receipt; no stable machine-readable domain error codes; no explicit negative
quantity rejection; and partial returns currently reuse this sale RPC with negative quantities.

### 3.2 `approve_pos_void_with_pin(payload)`

Current online call:

```json
{
  "payload": {
    "order_id": "00000000-0000-0000-0000-000000000030",
    "lodge_id": "00000000-0000-0000-0000-000000000010",
    "requested_by": "00000000-0000-0000-0000-000000000040",
    "approved_by": "00000000-0000-0000-0000-000000000070",
    "pin": "<plaintext PIN supplied at call time>",
    "reason": "Duplicate order",
    "outlet_id": "00000000-0000-0000-0000-000000000020",
    "override_log_id": "00000000-0000-0000-0000-000000000080",
    "created_at": "2026-07-29T13:05:00.000Z"
  }
}
```

The current online SQL verifies the PIN against the approver's stored hash, locks the order,
restores linked stock, removes a folio charge if present, marks the order `voided`, and inserts a
`pos_override_log` row. A repeated `override_log_id` returns an already-applied response.

Success response:

```json
{
  "success": true,
  "id": "00000000-0000-0000-0000-000000000030",
  "override_log_id": "00000000-0000-0000-0000-000000000080",
  "restored_stock": []
}
```

Already-applied response adds `"already_applied": true`. Current errors include `Order not found`,
`Invalid PIN or unauthorized approver`, `Order is already voided`, and `Cannot void a settled
order`, plus SQLSTATE `42501` access errors.

The offline path verifies a cached approver locally, writes the PIN into the queued RPC payload,
marks the order voided locally, restores the local reservation, and queues the operation. A PIN
must never be persisted in a queue or support bundle; this is a Phase 0 contract gap to fix before
commercial use.

`void_pos_order(p_id, p_lodge_id)` still returns only:

```json
{
  "success": false,
  "error": "POS voids require supervisor, manager, or admin PIN approval."
}
```

### 3.3 Menu and Bar catalog RPCs

`create_pos_menu_item(payload)` receives `lodge_id`, `name`, `category`, `price`, `is_available`,
`barcode`, `inventory_item_id`, `depletion_qty`, and optional `outlet_id`. Success is
`{ "success": true, "id": "<uuid>" }`. It rejects beverage-outlet manual items with
`Bar POS items must come from Bar inventory products.` and otherwise uses text errors plus
SQLSTATE `42501` for role/access checks.

`update_pos_menu_item(p_id, p_lodge_id, payload)` accepts the same mutable fields. Success is
`{ "success": true, "id": "<uuid>" }`. Current errors include `POS menu item not found`,
`Bar pack templates are managed from the Bar template controls.`, and
`Bar bottle details are managed from inventory. Only barcode updates are allowed here.`.

`delete_pos_menu_item(p_id, p_lodge_id)` has no JSON payload. Success is
`{ "success": true, "id": "<uuid>" }`. It returns `POS menu item not found` or
`Inventory-managed Bar items cannot be deleted from the manual menu list.`.

`set_bar_pos_pack_template(payload)` receives `lodge_id`, `inventory_item_id`, `pack_size`, and
`enabled`. `pack_size` must be 6, 12, or 24. Success is `{ "success": true }`. Current errors:

- `Only 6-pack, 12-pack, and case-24 templates are supported.`;
- `Bar inventory product not found.`;
- `Pack templates are only available for Bar inventory products.`;
- `Set a bottle selling price before enabling pack templates.`.

All catalog/template mutations are currently online-only in Electron. They have no queue key,
operation ID, or offline reconciliation.

### 3.4 Cash-up

`upsert_pos_cashup(payload)` receives the local cash-up row: `id`, `lodge_id`, `date`, `outlet_id`,
`opening_float`, `expected_cash_drawer`, `expected_by_method`, `counted_by_method`,
`variance_by_method`, `cash_over_short`, `orders_count`, `void_count`, `pending_count`,
`gross_sales`, `returns_total`, `net_sales`, `notes`, `created_by`, `created_by_name`,
`cashier_id`, `cashier_name`, and `created_at`. Success is `{ "success": true, "id": "<uuid>" }`.
The SQL upserts by `id`; it does not derive or validate the totals from the order ledger.

Offline cash-up queues this RPC. If an online call fails, the current code falls back to a local
pending row without queueing the failed online call, so retryable online failures can be lost.

### 3.5 Table, tab, audit, and reporting RPCs

`upsert_pos_table(payload)` receives `id`, `lodge_id`, `outlet_id`, `name`, `area`, `seats`, and
`active`; success is `{ "success": true, "table": <row> }`; errors are `Access denied.` and
`Table name is required.`.

`upsert_pos_tab(payload)` receives `id`, `lodge_id`, `outlet_id`, `table_name`, `tab_name`,
`customer_name`, `waiter_name`, `room_id`, `booking_id`, `items`, `notes`, `status`, `opened_by`,
`opened_by_name`, and `created_at`; success is `{ "success": true, "tab": <row> }`, with
`already_open: true` when the server finds an active table tab. Errors are `Access denied.` and
`Waiter name is required before opening a table.`.

`update_pos_tab_status(p_tab_id, p_status, p_notes)` returns
`{ "success": true, "tab": <row> }` or `{ "success": false, "error": "Open table tab not found." }`.

`append_pos_audit_log(payload)` receives `id`, `lodge_id`, `action`, `entity_type`, `entity_id`,
`staff_id`, `staff_name`, `details`, and `created_at`; success is `{ "success": true, "event": <row> }`
or `{ "success": false, "error": "Access denied." }`. Electron sends this best-effort online
and does not queue it when offline.

`get_pos_sales_summary(p_lodge_id, p_start_date, p_end_date, p_outlet_selector)` returns
`total_revenue`, `gross_revenue`, `discount_total`, `returns_total`, `tax_total`, `tip_total`,
`net_revenue`, `folio_revenue`, `direct_revenue`, `total_orders`, `avg_order`, `by_payment`,
`by_cashier`, `top_items`, and `daily`. It raises `Start date and end date are required`,
`End date cannot be before start date`, or `Access denied` (SQLSTATE `42501`).

## 4. Inventory RPC inventory

### 4.1 Item and purchase RPCs

`create_inventory_item(payload)` receives `id` (currently sent by Electron but ignored by the
current SQL), `lodge_id`, `name`, `category`, `unit`, `current_stock`, `reorder_level`,
`latest_unit_cost`, `selling_price`, `outlet_id`, and local timestamps. Success is
`{ "success": true, "id": "<server uuid>" }`. Errors include `Selected outlet was not found.`,
`Set a POS selling price greater than zero for Bar inventory items.`, `Inventory item not found`,
and SQLSTATE `42501` role/access failures.

`update_inventory_item(p_id, p_lodge_id, payload)` accepts partial `name`, `category`, `unit`,
`reorder_level`, `selling_price`, and `outlet_id`; success is `{ "success": true, "id": "<uuid>" }`.
Errors include `Inventory item not found`, `Selected outlet was not found.`, and the Bar selling
price validation message above.

`delete_inventory_item(p_id, p_lodge_id)` returns `{ "success": true, "id": "<uuid>" }` or
`{ "success": false, "error": "Inventory item not found" }`. It also deletes inventory purchases
and auto-created POS menu rows for that item.

`add_inventory_purchase(payload)` receives `lodge_id`, `item_id`, `date`, `quantity_purchased`,
`total_cost`, `unit_cost`, and `notes`. Success is
`{ "success": true, "id": "<purchase uuid>", "new_stock": 10 }`; a missing item raises
`Inventory item not found`. There is no current Electron offline queue for purchases.

### 4.2 Stock and stocktake RPCs

`adjust_inventory_stock(p_item_id, p_lodge_id, p_delta, p_notes)` returns
`{ "success": true, "new_stock": 10 }`, `{ "success": false, "error": "Adjustment quantity is required" }`,
or `{ "success": false, "error": "Inventory item not found" }`. The SQL clamps stock at zero and
logs a movement. Electron queues the delta offline, but there is no server idempotency key.

`create_inventory_stocktake_session(payload)` receives `lodge_id`, `outlet_id`, `title`, `notes`,
and `created_by`; success is `{ "success": true, "id": "<uuid>", "line_count": 12 }`.

`save_inventory_stocktake_counts(p_stocktake_id, p_lodge_id, p_lines)` receives an array of
`{ "item_id": "<uuid>", "counted_qty": 3, "notes": "" }` and returns `{ "success": true }`.
Errors are `Stock take session not found` and `Only open stock takes can be updated`.

`post_inventory_stocktake_session(p_stocktake_id, p_lodge_id, p_notes)` returns
`{ "success": true, "variance_count": 2 }` or errors `Stock take session not found` and
`This stock take has already been posted`. It applies counted quantities to current stock.

`get_inventory_spend_summary(p_lodge_id, p_start_date, p_end_date, p_outlet_selector)` returns
`total`, `by_category`, and `purchases`; errors are the same date validation messages and
`Access denied` (SQLSTATE `42501`).

All stocktake calls and purchases are currently online-only in Electron. Stocktake operations have
no durable queue, idempotency key, crash recovery, or cross-device merge contract.

## 5. Error-code inventory and freeze decision

The current contract has one explicitly stable SQLSTATE: `42501` for lodge, role, session, outlet,
and report access denial. Most domain failures are JSON `success:false` with human-readable
`error` strings; PostgREST also surfaces untyped PL/pgSQL exceptions. There is no stable domain
error-code field, no retryability flag, and no conflict payload. `23505` is recognized by the
generic queue as “already applied” for some RPCs, but it is not a documented domain response and
must not be treated as proof of idempotency for every POS/inventory operation.

The Phase 1 database agent must introduce machine-readable codes and operation receipts without
changing the legacy behavior until v2 compatibility is proven. No implementation agent may add a
new request field to the v2 payload without updating this document and the migration contract.

## 6. Non-negotiable gaps carried into later phases

1. Add the envelope and server-verified device/session context to every critical mutation.
2. Make sale, void, return, stock, purchase, cash-up, table/tab, and stocktake operations
   idempotent with one stable operation ID and an original-result replay response.
3. Remove plaintext PINs from queues and persist only an approval proof/reference.
4. Replace negative sale lines with dedicated return semantics and server quantity limits.
5. Queue retryable online failures, not only explicitly offline actions.
6. Add authoritative receipt/reference numbers and accepted server time to responses.
7. Replace human strings with machine-readable error codes plus retryability/conflict metadata.
8. Add server-side cash-up derivation and audit; current cash-up payload totals are caller-owned.
9. Add offline parity for menu, purchases, stocktakes, and table/session workflows with convergence
   rules for Restaurant and Bar using the same RPC contract.
