# Restaurant & Bar offline operation matrix

Phase 0 inventory, captured 29 July 2026. Restaurant (`outlet.type=food`) and Bar
(`outlet.type=beverage`) use the same Electron domain and must converge through the same
versioned RPC contract. A row marked “legacy” is not a release-ready guarantee; it identifies
work required in Phases 1–8.

Legend: `cache` = reads trusted local state; `local` = durable local write; `queue` = deterministic
RPC operation; `idempotency` = stable operation ID; `dependency` = queue prerequisite;
`reconcile` = authoritative replay refresh; `crash` = restart-safe; `converge` = cross-device rule.

| Page/action | Mode | cache | local | queue | idempotency | dependency | reconcile | crash | converge | Current gap / target phase |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Load menu/catalog | Restaurant + Bar | yes | no | no | n/a | none | partial refresh | yes | no | Catalog version/price snapshot required (P2) |
| Create menu item | Restaurant + Bar | yes | optimistic | online RPC only | legacy key absent | outlet scope | partial | partial | no | Queue and server versioning (P2/P8) |
| Edit menu item/availability | Restaurant + Bar | yes | optimistic | online RPC only | legacy key absent | outlet scope | partial | partial | no | Queue and conflict review (P2/P8) |
| Delete menu item | Restaurant + Bar | yes | optimistic | online RPC only | legacy key absent | outlet scope | partial | partial | no | Queue and dependency checks (P2/P8) |
| Bar pack/template setup | Bar | yes | optimistic | online RPC only | absent | menu/inventory link | partial | no | no | Queue authoritative template change (P2/P8) |
| Add sale line | Restaurant + Bar | yes | yes (draft) | no | draft only | trusted catalog | n/a | yes | local terminal only | Draft is provisional; price history required (P2) |
| Change quantity/remove line | Restaurant + Bar | yes | yes (draft) | no | draft only | trusted catalog | n/a | yes | local terminal only | Validate stock at commit; no server mutation yet (P2) |
| Apply modifiers/promotions | Restaurant + Bar | yes | yes (draft) | no | draft only | catalog version | n/a | yes | no | Server semantic pricing/tax (P2) |
| Complete cash/card/split sale | Restaurant + Bar | yes | yes (optimistic) | `create_pos_order` legacy | `_idempotency_key` legacy | shift optionally | partial order refresh | partial | no | Replace with v2 envelope/RPC; authoritative tender/receipt (P2) |
| Charge active room folio | Restaurant + Bar | yes | yes (optimistic) | legacy sale RPC | legacy key | active booking | partial | partial | no | Atomic folio + sale v2 (P2) |
| Print/reprint receipt | Restaurant + Bar | cached orders | no | no | n/a | completed order | refresh order | yes | no | Reprint must use authoritative receipt (P2/P8) |
| Void sale request | Restaurant + Bar | yes | optimistic | online/legacy | legacy key | order exists | partial | no | no | Approval proof and queued void (P3) |
| Approve void with PIN | Restaurant + Bar | yes | yes (pending) | legacy `approve_pos_void_with_pin` | legacy key | supervisor capability | partial | no (PIN risk) | no | Never queue plaintext PIN; proof/reference only (P3) |
| Partial return | Restaurant + Bar | yes | optimistic | legacy return RPC | legacy key | original order/remaining qty | partial | no | no | Dedicated return ledger/idempotent RPC (P3) |
| Open cash shift | Restaurant + Bar | yes | yes | local only | absent | device/user registration | no | partial | no | Server shift RPC and operation receipt (P5) |
| Close cash shift/cash-up | Restaurant + Bar | yes | yes | legacy `upsert_pos_cashup` | local row ID | open shift | partial | partial | no | Server-derived expectation and variance (P5) |
| View cash-up history | Restaurant + Bar | cache | no | read online/cache | n/a | none | partial | yes | no | Reconcile server cash-up history (P5) |
| Open table/tab | Restaurant + Bar | yes | yes | legacy `upsert_pos_tab` | row ID only | table/outlet scope | partial | partial | no | v2 tab ledger and dependency ordering (P7) |
| Save tab notes/waiter | Restaurant + Bar | yes | yes | legacy `upsert_pos_tab` | row ID only | open tab | partial | partial | no | Queue field edits and convergence (P7) |
| Transfer/merge table | Restaurant + Bar | yes | yes | no/online-only | absent | source + target tabs | no | no | no | Atomic transfer/merge RPC + conflict review (P7) |
| Close table/tab | Restaurant + Bar | yes | yes | legacy status RPC | absent | open tab | partial | partial | no | Queued close and authoritative status (P7) |
| Configure floor/table layout | Restaurant + Bar | yes | optimistic | legacy `upsert_pos_table` | row ID only | outlet scope | partial | partial | no | Configuration queue/version (P8) |
| Update kitchen/bar ticket status | Restaurant + Bar | yes | yes | online-only | absent | ticket exists | partial | no | no | Durable KDS ticket event stream (P6) |
| Route ticket to station | Restaurant + Bar | yes | yes | no | absent | menu station config | no | no | no | Server station routing + replay (P6) |
| Open kitchen/bar display | Restaurant + Bar | cache | no | no | n/a | ticket cache | partial | yes | partial | Reconnect cursor/convergence (P6) |
| Create inventory item | Restaurant + Bar | yes | optimistic | legacy `create_inventory_item` | local item ID | outlet scope | partial | partial | no | `inventory_item_v2` and receipts (P4) |
| Edit/delete inventory item | Restaurant + Bar | yes | optimistic | online-only | absent | item ownership | partial | no | no | Queue and conflict behavior (P4) |
| Record inventory purchase | Restaurant + Bar | yes | no | online-only | absent | item ownership | no | no | no | Offline purchase RPC/ledger (P4) |
| Adjust stock | Restaurant + Bar | yes | yes | legacy `adjust_inventory_stock` | queue ID only | item exists | partial | partial | no | Operation envelope/atomic ledger (P4) |
| Start stocktake | Restaurant + Bar | yes | no | online-only | absent | outlet scope | no | no | no | Offline stocktake session (P4) |
| Save stocktake counts | Restaurant + Bar | yes | no | online-only | absent | open stocktake | no | no | no | Offline count queue and dependency (P4) |
| Post stocktake | Restaurant + Bar | yes | no | online-only | absent | counts complete | no | no | no | Atomic post/reconciliation RPC (P4) |
| Low-stock/report reads | Restaurant + Bar | cache | no | no | n/a | last sync | partial | yes | no | Show stale/source badge; no silent empty success (P4/P8) |
| Hardware/terminal test | Restaurant + Bar | cached settings | local settings | no | n/a | device registration | n/a | yes | device-local | Explicit unsupported/connected state (P8) |
| Customer display snapshot | Restaurant + Bar | yes | local snapshot | no | n/a | active sale | n/a | yes | device-local | Device-local display is acceptable; never financial source (P8) |

## Required v2 queue metadata

Every row that becomes a mutation must carry the frozen envelope and local queue metadata:

```json
{
  "_queue_id": "<entity>-<operation_id>",
  "_depends_on": "<prior-operation-queue-id-or-null>",
  "_state": "pending",
  "_contract_version": 2,
  "_entity_type": "pos_sale",
  "_entity_id": "<local-uuid>",
  "type": "rpc",
  "table": "<versioned-rpc-name>",
  "data": { "contract_version": 2, "operation_id": "<uuid>", "payload": {} }
}
```

Replay must call the same RPC as online execution. Success replaces provisional IDs, totals,
stock, receipt/reference numbers, and timestamps with the RPC response. A retryable failure stays
pending; a server rejection moves to review and reverses provisional state exactly once. No row may
turn a failed remote mutation into an empty successful list.

## Phase exit evidence

This matrix is the Phase 0 inventory. It intentionally records the current gaps; Phases 1–8 must
update the corresponding cells and add tests for duplicate replay, crash recovery, concurrency,
cross-device convergence, and financial/stock reconciliation before the commercial no-go boundary
is lifted.

