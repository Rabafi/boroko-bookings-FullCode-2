# Phase 0 baseline

Captured 29 July 2026 on branch `refactor/database-split` before feature implementation.

## Environment safety

- `.env` remains local and ignored by Git.
- `BOROKO_TEST_TENANT=false` is explicitly present in the local environment and `.env.example`.
- Integration helpers must require an explicit `BOROKO_TEST_TENANT=true` opt-in and a dedicated test lodge; no customer profile may be used as a fixture.
- Secret values are intentionally not recorded in this document.

## Existing worktree to preserve

The following changes predate Phase 0 and are not to be reset or overwritten:

- package lockfiles in the root, `manager-pwa`, and `booking-site`;
- `src/main/domains/authLogin.js`;
- `src/main/domains/inventory.js`;
- `src/main/domains/profiles.js`;
- `AGENTS.md`;
- existing Supabase migrations `20260607170000_authenticate_user_for_device.sql` and `20260611120000_inventory_items_updated_at.sql`;
- the commercial audit and Luna implementation plan.

## Baseline gates

| Command | Result |
| --- | --- |
| `npm test` | PASS — `production-guardrails: ok` |
| `npm run test:offline-queue-critical` | PASS — `offline-queue-regression: ok` |
| `npm run test:offline-pos-critical` | PASS — `offline-pos-regression: ok` |
| `npm run test:inventory-offline-sync` | PASS — inventory draft sync/day-use checks passed |
| `npm run test:import-critical` | PASS — `import-system-regression: ok` |
| `npm run test:phase0-tenant-guard` | PASS — 9/9 non-network safety tests |
| `npm run build` | PASS — Electron main, preload, and renderer bundles built |

PowerShell emitted a local npm wrapper access warning after each command; it did not change any command's exit status or test result.

`node scripts/test/seed-reset.mjs preview` was intentionally rejected against the current local
`.env` because it is opted out (`BOROKO_TEST_TENANT=false`), has no disposable lodge ID, and points
at the known production Supabase project. This is the expected fail-closed result.

## Phase 0 exit evidence still required

- frozen v2 request/response/error contract;
- page/action offline operation matrix for Restaurant and Bar;
- isolated integration guard and disposable seed/reset helper;
- behavioral baseline mapping that distinguishes source-pattern checks from real user behavior.
