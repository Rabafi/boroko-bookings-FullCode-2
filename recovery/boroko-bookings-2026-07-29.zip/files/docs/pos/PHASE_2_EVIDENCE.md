# Phase 2 evidence — Sale v2

| Field | Evidence |
|---|---|
| Phase | 2 — authoritative Restaurant/Bar sale |
| Commit(s) | Not committed; shared worktree integration in progress |
| Migration(s) | `20260729090100_phase2_pos_sale_v2.sql` |
| RPC contract version | `create_pos_order_v2`, envelope version 2 |
| Files changed | `src/main/domains/pos.js`, `src/main/domains/pos/saleV2.js`, `src/main/domains/syncShared.js`, `src/main/domains/infrastructure.js`, `POS.jsx`, renderer sale presentation, migration |
| Tests added | `tests/phase2-sale-adapter.test.mjs`, `tests/pos-renderer-v2-contract.test.mjs`, `tests/security/phase2-sale-v2-contract.test.mjs` |
| Tests passed | Phase 2 adapter, renderer contract, static SQL contract, Electron production build |
| Offline crash test | Queue-first write and provisional cache paths are covered by source contract; isolated runtime tenant not configured |
| Duplicate replay test | Operation receipt claim/record and unique operation index are defined; live integration skipped fail-closed |
| Concurrency test | Inventory and receipt sequence rows are locked in the RPC; live race test pending isolated backend |
| Access-control test | `app_reject_pwa_financial_mutation` and `app_require_capability` are required by the RPC; live test pending isolated backend |
| Reconciliation result | v2 replay updates authoritative receipt/totals and moves rejected provisional sales to manual review; replay is wired into queue processing |
| Remaining risks | Migration has not been applied to an isolated Supabase tenant; legacy v1 queue draining/disablement and modifier/tender-reference validation remain follow-up work |
| Rollback path | Keep v2 queued operations; feature-disable v2 UI and do not re-enable insecure v1 fallback |
| Go/no-go | Code gate green; deployment gate blocked until isolated SQL integration and legacy queue audit pass |
