# Phase 5 evidence — Shifts and cash-up

Migration: `20260729090400_phase5_shifts_cashup_v2.sql`.

The migration adds idempotent `open_pos_shift_v2` and `close_pos_shift_and_cashup_v2` RPCs, locks shifts, rebuilds expected tender buckets from authoritative sale/return/void rows, ignores client expected totals, seals the shift/cash-up, and records audit/operation receipts. Both operations use the server-derived `pos.sale` capability so a cashier can complete the offline drawer workflow; lodge capability overrides can restrict close policy. Live SQL/concurrency verification is blocked by the missing isolated tenant.
