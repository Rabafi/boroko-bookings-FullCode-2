# Phase 8 evidence — Configuration and Manager oversight

Migration: `20260729090700_phase8_pos_configuration_oversight.sql`.

The migration adds versioned configuration revisions with expected-version conflict detection and a read-only `get_manager_pos_oversight` RPC. The Manager PWA now has a read-only Restaurant & Bar oversight route; it does not expose POS financial mutation controls. Hardware remains MVP/manual (system printer, manually opened drawer, external payment reference) until an idempotent provider bridge is implemented. Static contract and PWA build gates remain required.
