# POS behavioral baseline — Restaurant and Bar

**Captured:** 29 July 2026  
**Branch:** `refactor/database-split` (`867d591`)  
**Purpose:** Phase 0 evidence for the Luna implementation plan. This is a test inventory, not a release approval.

## How to read this baseline

The existing suite contains several different kinds of evidence. They must not be reported as equivalent:

| Evidence class | What it proves | What it does not prove |
| --- | --- | --- |
| Source-pattern | A regular expression or source extraction still contains an intended guard/helper/RPC call. | That the application can execute the path, that Postgres accepts it, or that a user can complete the workflow. |
| Pure helper simulation | A small extracted function or stubbed RPC behaves for the supplied inputs. | Database constraints, RLS, concurrency, authenticated identity, or renderer behavior. |
| Synthetic cache UI | Electron starts and renders data deliberately written to a temporary profile. | A real mutation, replay, server reconciliation, or a customer profile being safe to use. |
| Desktop IPC integration | A real Electron process calls the preload/database path and reads the local cache. | The visible terminal workflow when the test calls `window.api` directly, or an isolated backend when `.env` is used. |
| Live-backend E2E | Electron and Supabase execute together. | Safety for release: the current harness can target the installed profile and live `.env` tenant. |

The offline-first contract is the expected behavior: a disconnected terminal may continue to operate from trusted local state, but every critical mutation must be durable, queued as the same versioned RPC operation, replayed idempotently, reconciled, and surfaced on rejection. “Works offline” therefore means more than returning a local row.

## Existing automated checks

### Node regression checks

| Test | Classification | Current coverage | Restaurant / Bar evidence | Important limitation |
| --- | --- | --- | --- | --- |
| `tests/offline-pos-regression.test.mjs` (`npm run test:offline-pos-critical`) | **Source-pattern** | Checks local stock reservation/merge helpers, queue construction, inventory linkage fields, and SQL text for `create_pos_order`. | None. It does not construct a `food` or `beverage` outlet. | No Electron, no Postgres, no RPC execution, no authenticated session, no crash/replay. A passing regex can coexist with a broken runtime path. |
| `tests/offline-queue-regression.test.mjs` (`npm run test:offline-queue-critical`) | **Source-pattern plus pure helper extraction** | Checks generic queue lifecycle, dependency markers, failed-item UI strings, and POS queue calls. | None. Outlet type and business mode are not part of assertions. | Most assertions are text matches. It does not prove the queue accepts the frozen `contract_version: 2` envelope or that a real replay returns the original result. |
| `tests/release-behavior.test.mjs` | **Pure helper/stub simulation** | Exercises dependency selection, nested booking-reference rewrite, an emulated payment replay, and `createPosOrder` against a fake Supabase client. | None. `outlet_id` is a string fixture only; no food/bar behavior. | No Postgres constraints/RLS/locks/server pricing. The fake RPC is not the production SQL contract. |
| `tests/production-guardrails.test.mjs` (`npm test`) | **Source-pattern** | Broad release guardrails, including POS source/migration invariants and UI prohibitions. | None. | Does not run a POS workflow or verify either mode in a running app. |
| `tests/inventory-offline-sync-regression.test.mjs` (`npm run test:inventory-offline-sync`) | **Pure helper tests** | Inventory draft patch/remove and day-use reporting/config helpers. | None. | It does not execute a POS sale, inventory RPC, or restaurant/bar outlet. |

### Desktop Playwright checks

All rows below launch Electron. Unless noted otherwise, `createPosOrderFromSeed`/`createPosOrderViaApi` call `window.api.pos.createOrder` directly; they do not click the terminal’s menu, quantity, tender, or submit controls. Tests that call `getRealBackendEnv()` read the repository `.env` and seed from the installed `%APPDATA%\\boroko-bookings` profile.

| Test | Classification | Real behavior exercised | Restaurant / Bar evidence | Important limitation |
| --- | --- | --- | --- | --- |
| `desktop-pos-offline-order.spec.mjs` | **Desktop IPC + synthetic/local cache** | Creates a local offline order, checks pending queue metadata, and renders History status. | None; seed outlet is whatever is supplied, with no type assertion. | Mutation is IPC-driven, not terminal-driven; no replay/server result. |
| `desktop-pos-status-visibility.spec.mjs` | **Synthetic cache UI** | Renders pending, failed, and manual-review statuses from seeded JSON and opens details. | **Bar label only**: cache contains `{ type: 'beverage' }`; no order is created through that outlet. | This is visual state coverage, not Bar sale behavior and not Restaurant behavior. |
| `desktop-pos-live-order.spec.mjs` | **Live-backend E2E + IPC** | Sends an online order, reads the persisted order, and renders History details. | Unknown: first installed-profile outlet is selected; type is not asserted. | Uses live `.env` and installed lodge; no isolated tenant; no visible sale-entry path. |
| `desktop-pos-reconnect-sync-success.spec.mjs` | **Live-backend E2E + offline replay** | Creates offline, reconnects, syncs, checks one order and queue cleanup. | Unknown outlet type. | Customer-data risk; no contract envelope/response assertions; direct IPC mutation. |
| `desktop-pos-crash-recovery.spec.mjs` | **Live-backend E2E + restart** | Persists a pending order across forced Electron close/restart, then replays. | Unknown outlet type. | Same live tenant risk; no renderer entry path; no cross-device convergence. |
| `desktop-pos-duplicate-sync.spec.mjs` | **Live-backend E2E + concurrent replay** | Calls `sync.runNow()` twice and checks one business row. | Unknown outlet type. | Two calls in one process are not two authorized terminals; server response/idempotency receipt is not inspected. |
| `desktop-pos-cross-process-sync.spec.mjs` | **Live-backend E2E + two Electron processes** | Shares one profile and triggers replay concurrently, checking one order. | Unknown outlet type. | This is same-profile cross-process, not separate registered devices or cross-outlet convergence. |
| `desktop-pos-multiline-replay.spec.mjs` | **Live-backend E2E + offline replay** | Creates two lines offline, verifies local totals, replays, and renders both lines. | Unknown outlet type; no `food`/`beverage` fixture. | Client computes expected totals; no server-priced/taxed response verification. |
| `desktop-pos-financial-consistency.spec.mjs` | **Live-backend E2E + local/replay comparison** | Compares subtotal/line values before and after replay and renders details. | Unknown outlet type. | It proves equality with client-derived expectations, not server authority, tax, tender, receipt, or discount correctness. |
| `desktop-pos-failed-sync-retry.spec.mjs` | **Live-backend E2E + forced failure/retry** | Forces a broken endpoint, checks failed visibility, restores access, and retries. | Unknown outlet type. | Failure is transport-level; no SQL rejection/conflict/error code or dead-letter reconciliation. |
| `desktop-pos-inventory-depletion.spec.mjs` | **Live-backend E2E + stock mutation** | Creates an inventory-backed online sale, observes stock decrement, and attempts a stock restore. | Unknown outlet type; no beverage pack assertion. | Mutates live stock and cleanup can leak if the restore fails; no offline crash/replay or movement-ledger assertion. |
| `desktop-pos-folio-linkage.spec.mjs` | **Live-backend E2E + booking/POS IPC** | Creates an online booking, sends a folio POS order, and reads the booking charge. | Unknown outlet type. | Uses a live available room and direct IPC; no offline folio dependency/replay or payment-ledger proof. |
| `desktop-pos-void-approval.spec.mjs` | **Live-backend E2E + IPC approval** | Creates a live order, creates/updates a supervisor user, rejects a bad PIN, approves a void, and renders the audit trail. | Unknown outlet type. | No offline void queue, replay proof, return quantity limits, or explicit capability/outlet assertions; creates live users. |

### What is not a POS behavior test

The desktop support helpers (`Playwright tests/desktop/support/desktop-app.mjs` and `desktop-flows.mjs`) are fixtures and drivers. They contain useful local-cache plumbing, but their existence is not evidence that a user can operate Restaurant or Bar mode. In particular, `createPosOrderFromSeed` selects the first available outlet and calls the preload API; it does not prove the `POS.jsx` mode filters, tender controls, pricing display, or receipt flow.

## Mode coverage audit

The renderer distinguishes POS outlets by `type === 'food'` (Restaurant) and `type === 'beverage'` (Bar) in `src/renderer/src/components/POS.jsx`. The business-profile value `restaurant` is a separate setting and is not an outlet-mode substitute.

| Mode / axis | Existing evidence | Baseline verdict |
| --- | --- | --- |
| Restaurant (`food` outlet) | No existing POS test creates an explicit `food` outlet or asserts `selectedOutlet.type === 'food'`. Live tests inherit an unknown installed-profile outlet. | **Missing** |
| Bar (`beverage` outlet) | `desktop-pos-status-visibility` seeds a Bar label and a `beverage` outlet, but only renders pre-seeded statuses. No sale, stock depletion, ticket, void, or replay uses that outlet. | **Visual-only / missing behavior** |
| Business profile `restaurant` | `createDesktopSeed` defaults `settings.business_type` to `lodge`; no POS test asserts navigation/labels for a restaurant business profile. | **Missing** |
| Shared financial contract | Source checks and fake-RPC tests reference POS calls, but no mode-paired runtime test proves identical server-side validation and totals. | **Missing** |
| Manager PWA oversight | No POS order/ticket/shift/void/return behavior test exercises the PWA. | **Missing** |

## Required baseline matrix for the implementation waves

This is the minimum behavior matrix the later phases must turn green. “Partial” means there is some evidence above, not that the scenario is commercially safe.

| ID | Scenario | Restaurant (`food`) | Bar (`beverage`) | Offline-first proof required | Current status |
| --- | --- | --- | --- | --- | --- |
| B-01 | Create one sale with server pricing and authoritative totals | No explicit fixture | No explicit fixture | Local provisional row; v2 RPC replay; authoritative response reconciled | **Partial/unsafe** |
| B-02 | Multi-line sale, quantity and decimal rounding | Unknown outlet | Unknown outlet | Same line payload and total after restart/replay | **Partial/unsafe** |
| B-03 | Tax, discount, tip, and split tenders | None | None | Server derives/validates all amounts; rejected payload stays visible | **Missing** |
| B-04 | Receipt/reference allocation | None | None | Stable reference after retry; no number reuse after void/return | **Missing** |
| B-05 | Inventory-linked sale and stock reservation | Live unknown outlet only | None | Local reservation, crash recovery, atomic server decrement, movement ledger | **Partial/unsafe** |
| B-06 | Bar pack/recipe depletion | None | None | Pack conversion and replay are idempotent | **Missing** |
| B-07 | Folio/room charge | Live unknown outlet only | None | Booking dependency, queued RPC, charge reconciliation | **Partial/unsafe** |
| B-08 | Void with capability/approval proof | Live unknown outlet only | None | Offline approval envelope, server verification, stock/cash reversal | **Partial/unsafe** |
| B-09 | Partial and full returns | None | None | Remaining quantity race, tender reversal, receipt/audit trail | **Missing** |
| B-10 | Shift open/close and cash-up | None | None | Durable queue, server-derived expected totals, sealed period | **Missing** |
| B-11 | Kitchen/bar prep ticket creation and status | None | None | Ticket operation queued and visible on another authorized terminal | **Missing** |
| B-12 | Restaurant table/tab save, transfer, merge | None | None | Atomic check ledger and queued transfer/merge | **Missing** |
| B-13 | Menu availability, price/config changes | None | None | Offline local config operation, replay conflict, operator review | **Missing** |
| B-14 | Stock receive/stocktake/adjustment | None | None | RPC/movement ledger, offline crash/replay, impossible-state rejection | **Missing** |
| B-15 | Transport failure, SQL rejection, dead-letter retry | Transport failure only | None | Error code/category, durable failed item, manual review, exact replay | **Partial/unsafe** |
| B-16 | Two registered devices converge | Same profile only | None | Server operation receipt and conflict/convergence assertions | **Missing** |
| B-17 | Capability, outlet, actor, and device authorization | None | None | Server derives identity and rejects spoofed payload fields | **Missing** |
| B-18 | Clean isolated test tenant guard | None | None | Tests refuse production URL/lodge and require explicit test opt-in | **Missing in existing E2E harness** |

## P0/P1 gaps exposed by the baseline

1. **Live-tenant risk:** `getRealBackendEnv()` reads `.env`; the live-backend tests use the installed profile and can create orders, charges, users, and stock changes. This is incompatible with a commercial release gate until Phase 0’s isolated tenant guard exists.
2. **No explicit mode fixtures:** there is no paired `food`/`beverage` seed, and only a status-label test mentions Bar. A green POS suite could still hide a broken Restaurant or Bar filter.
3. **Renderer bypass:** the creation path is normally `window.api.pos.createOrder`, so menu selection, quantity entry, tender selection, discounts, tips, table/tab state, receipts, and validation messages are not exercised.
4. **Source assertions overstate safety:** regex checks can pass while RPC payloads, migrations, RLS, or queue replay disagree. They are useful guardrails but not behavioral evidence.
5. **No frozen v2 contract check:** existing tests do not require the complete `contract_version: 2` envelope (`operation_id`, trusted `device_id`, event time, lodge/outlet scope) or the authoritative response/error-code shape.
6. **No server-authority assertions:** current totals are compared with values calculated in test JavaScript. There is no proof that server price history, tax, tender totals, receipt numbers, or actor identity win over caller input.
7. **No offline coverage for most operations:** returns, voids, shifts/cash-up, tickets, table transfer/merge, menu availability, purchases, stocktakes, and configuration do not have durable local/replay tests.
8. **No cross-device Restaurant/Bar convergence:** same-profile concurrent replay is not equivalent to two registered devices or a kitchen/bar display receiving a server operation.

## Phase 0 acceptance criteria for this document

- Keep the source-pattern tests, but label them as such in reports.
- Do not run the current live-backend POS specs as a release gate until the isolated test-tenant guard is installed.
- Add paired disposable `food` and `beverage` fixtures before Phase 1 agents claim POS mode coverage.
- Add a renderer-level sale smoke test for each mode; keep IPC tests as lower-level evidence.
- Require every new behavior test to state whether it is source, helper, synthetic cache, IPC integration, isolated-backend E2E, or live-backend E2E.
- Promote a scenario only after it verifies local durable state, the exact v2 RPC envelope, replay/idempotency, authoritative reconciliation, and operator-visible rejection/conflict handling.

