-- Phase 1: verified desktop devices, idempotent operation receipts, and immutable audit.
-- Additive only. Do not edit the baseline migrations.

create table if not exists public.app_registered_devices (
  id uuid primary key default gen_random_uuid(),
  lodge_id uuid not null,
  device_id text not null,
  status text not null default 'active',
  public_key text,
  credential_fingerprint text,
  registered_by uuid,
  registered_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  revoked_at timestamptz,
  metadata jsonb not null default '{}'::jsonb,
  constraint app_registered_devices_status_chk check (status in ('active', 'suspended', 'revoked')),
  constraint app_registered_devices_identity_uk unique (lodge_id, device_id)
);

create index if not exists app_registered_devices_lodge_status_idx
  on public.app_registered_devices (lodge_id, status, last_seen_at desc);

create table if not exists public.app_operation_receipts (
  operation_id uuid primary key,
  lodge_id uuid not null,
  device_id text not null,
  operation_type text not null,
  entity_id uuid,
  request_hash text not null,
  canonical_response jsonb not null default '{}'::jsonb,
  accepted_at timestamptz not null default now(),
  completed_at timestamptz,
  status text not null default 'claimed',
  created_at timestamptz not null default now(),
  constraint app_operation_receipts_status_chk check (status in ('claimed', 'completed', 'rejected'))
);

create index if not exists app_operation_receipts_lodge_created_idx
  on public.app_operation_receipts (lodge_id, created_at desc);

create table if not exists public.app_operation_audit_log (
  id uuid primary key default gen_random_uuid(),
  operation_id uuid references public.app_operation_receipts(operation_id),
  lodge_id uuid not null,
  operation_type text not null,
  entity_type text,
  entity_id uuid,
  actor_id uuid,
  device_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- Stable audit name used by later domain RPCs. This is intentionally append-only;
-- app_operation_audit_log remains as a compatibility ledger for Phase 1 receipts.
create table if not exists public.app_audit_events (
  id uuid primary key default gen_random_uuid(),
  operation_id uuid references public.app_operation_receipts(operation_id),
  lodge_id uuid not null,
  event_type text not null,
  entity_type text,
  entity_id uuid,
  actor_id uuid,
  device_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists app_audit_events_lodge_created_idx
  on public.app_audit_events (lodge_id, created_at desc);

create index if not exists app_operation_audit_log_lodge_created_idx
  on public.app_operation_audit_log (lodge_id, created_at desc);

alter table public.app_registered_devices enable row level security;
alter table public.app_operation_receipts enable row level security;
alter table public.app_operation_audit_log enable row level security;
alter table public.app_audit_events enable row level security;

drop policy if exists app_registered_devices_lodge_select on public.app_registered_devices;
create policy app_registered_devices_lodge_select
  on public.app_registered_devices for select
  using (public.app_lodge_access(lodge_id));

drop policy if exists app_operation_receipts_lodge_select on public.app_operation_receipts;
create policy app_operation_receipts_lodge_select
  on public.app_operation_receipts for select
  using (public.app_lodge_access(lodge_id));

drop policy if exists app_operation_audit_log_lodge_select on public.app_operation_audit_log;
create policy app_operation_audit_log_lodge_select
  on public.app_operation_audit_log for select
  using (public.app_lodge_access(lodge_id));

drop policy if exists app_audit_events_lodge_select on public.app_audit_events;
create policy app_audit_events_lodge_select
  on public.app_audit_events for select
  using (public.app_lodge_access(lodge_id));

revoke all on public.app_registered_devices from anon, authenticated;
revoke all on public.app_operation_receipts from anon, authenticated;
revoke all on public.app_operation_audit_log from anon, authenticated;
revoke all on public.app_audit_events from anon, authenticated;
grant select on public.app_registered_devices, public.app_operation_receipts, public.app_operation_audit_log, public.app_audit_events to authenticated;

create or replace function public.app_register_device(
  p_lodge_id uuid,
  p_device_id text,
  p_metadata jsonb default '{}'::jsonb
)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_session public.app_sessions%rowtype;
  v_user public.users%rowtype;
  v_device public.app_registered_devices%rowtype;
begin
  v_session := public.app_current_session_row();
  if v_session.id is null or v_session.session_type <> 'desktop' then
    raise exception 'A valid desktop session is required to register a device.' using errcode = '42501';
  end if;
  if v_session.lodge_id <> p_lodge_id then
    raise exception 'Access denied for this lodge.' using errcode = '42501';
  end if;
  select * into v_user from public.users u
   where u.id = v_session.user_id and u.lodge_id = p_lodge_id and lower(coalesce(u.status, 'active')) = 'active';
  if v_user.id is null then
    raise exception 'The authenticated staff account is suspended or unavailable.' using errcode = '42501';
  end if;
  if nullif(btrim(coalesce(p_device_id, '')), '') is null or v_session.metadata->>'device_id' is distinct from btrim(p_device_id) then
    raise exception 'The device identity must match the authenticated desktop session.' using errcode = '42501';
  end if;

  insert into public.app_registered_devices (
    lodge_id, device_id, status, registered_by, registered_at, last_seen_at,
    revoked_at, metadata
  ) values (
    p_lodge_id, btrim(p_device_id), 'active', v_session.user_id, now(), now(), null,
    coalesce(p_metadata, '{}'::jsonb)
  )
  on conflict (lodge_id, device_id) do update
    set status = 'active', revoked_at = null, last_seen_at = now(),
        registered_by = excluded.registered_by,
        metadata = public.app_registered_devices.metadata || excluded.metadata;

  select * into v_device from public.app_registered_devices d
   where d.lodge_id = p_lodge_id and d.device_id = btrim(p_device_id);
  return jsonb_build_object(
    'success', true,
    'device_id', v_device.device_id,
    'lodge_id', v_device.lodge_id,
    'status', v_device.status,
    'offline_entitled', true,
    'registered_at', v_device.registered_at
  );
end;
$$;

create or replace function public.app_require_registered_device(
  p_lodge_id uuid,
  p_device_id text
)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_session public.app_sessions%rowtype;
  v_device public.app_registered_devices%rowtype;
begin
  if public.app_is_service_role() then
    return jsonb_build_object('success', true, 'service_role', true, 'device_id', p_device_id);
  end if;
  v_session := public.app_current_session_row();
  if v_session.id is null or v_session.session_type <> 'desktop' then
    raise exception 'A valid desktop session is required.' using errcode = '42501';
  end if;
  if v_session.lodge_id <> p_lodge_id then
    raise exception 'Access denied for this lodge.' using errcode = '42501';
  end if;
  if nullif(btrim(coalesce(p_device_id, '')), '') is null
     or v_session.metadata->>'device_id' is distinct from btrim(p_device_id) then
    raise exception 'The operation device does not match the authenticated device.' using errcode = '42501';
  end if;
  select * into v_device
    from public.app_registered_devices d
   where d.lodge_id = p_lodge_id
     and d.device_id = btrim(p_device_id)
     and d.status = 'active'
     and d.revoked_at is null
   for update;
  if v_device.id is null then
    raise exception 'This desktop device is not registered or has been revoked.' using errcode = '42501';
  end if;
  update public.app_registered_devices set last_seen_at = now() where id = v_device.id;
  return jsonb_build_object('success', true, 'device_id', v_device.device_id, 'status', v_device.status, 'offline_entitled', true);
end;
$$;

create or replace function public.app_require_capability(
  p_lodge_id uuid,
  p_capability text,
  p_outlet_id uuid default null,
  p_device_id text default null
)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_session public.app_sessions%rowtype;
  v_user public.users%rowtype;
  v_role text;
  v_capability text := lower(btrim(coalesce(p_capability, '')));
  v_feature text;
  v_entitlement jsonb;
  v_override jsonb;
  v_allowed boolean := false;
begin
  if public.app_is_service_role() then
    return jsonb_build_object('success', true, 'service_role', true, 'capability', v_capability);
  end if;
  v_session := public.app_current_session_row();
  if v_session.id is null then
    raise exception 'A valid app session is required.' using errcode = '42501';
  end if;
  if v_session.lodge_id <> p_lodge_id then
    raise exception 'Access denied for this lodge.' using errcode = '42501';
  end if;
  select * into v_user from public.users u
   where u.id = v_session.user_id and u.lodge_id = p_lodge_id and lower(coalesce(u.status, 'active')) = 'active';
  if v_user.id is null then
    raise exception 'The authenticated user is suspended or unavailable.' using errcode = '42501';
  end if;
  if v_session.session_type = 'pwa'
     and (v_capability like 'pos.%' or v_capability like 'inventory.%' or v_capability like 'stock.%'
       or v_capability like 'cashup.%' or v_capability like 'kds.%' or v_capability like 'table.%') then
    raise exception 'This action is only available in the Front Desk system.' using errcode = '42501';
  end if;
  if p_device_id is not null then perform public.app_require_registered_device(p_lodge_id, p_device_id); end if;
  if p_outlet_id is not null and (v_capability like 'pos.%' or v_capability like 'inventory.%'
      or v_capability like 'stock.%' or v_capability like 'kds.%' or v_capability like 'table.%') then
    perform public.app_require_pos_outlet_access(p_lodge_id, p_outlet_id);
  end if;

  v_role := lower(coalesce(v_user.role, ''));
  v_feature := case
    when v_capability like 'pos.%' then 'pos'
    when v_capability like 'inventory.%' or v_capability like 'stock.%' then 'inventory'
    when v_capability like 'kds.%' or v_capability like 'table.%' or v_capability like 'cashup.%' then 'pos'
    when v_capability like 'reports.%' then 'reports'
    when v_capability like 'audit.%' then 'audit'
    else null
  end;
  v_entitlement := public.get_lodge_entitlement(p_lodge_id);
  if v_feature is not null and coalesce((v_entitlement->'effective_features'->>v_feature)::boolean, true) = false then
    raise exception 'This capability is not enabled for the lodge plan.' using errcode = '42501';
  end if;

  v_allowed := case
    when v_role in ('master_admin', 'super_admin', 'admin') then true
    when v_role = 'manager' then v_capability not like 'admin.%'
    when v_role = 'finance' then v_capability in ('reports.view', 'reports.revenue', 'reports.profit_loss', 'expenses.view', 'expenses.manage', 'audit.view')
    when v_role = 'supervisor' then v_capability like 'pos.%' or v_capability like 'inventory.%' or v_capability like 'stock.%'
      or v_capability like 'kds.%' or v_capability like 'table.%' or v_capability in ('reports.view', 'audit.view')
    when v_role = 'cashier' then v_capability in ('pos.view', 'pos.sale', 'pos.return', 'pos.void.request', 'pos.discount', 'table.view', 'table.open', 'table.close', 'kds.view')
    when v_role = 'receptionist' then v_capability like 'bookings.%' or v_capability like 'rooms.%' or v_capability like 'guests.%'
    else false
  end;
  v_override := v_user.capability_overrides -> v_capability;
  if jsonb_typeof(v_override) = 'boolean' then v_allowed := (v_override)::text = 'true'; end if;
  if not v_allowed then
    raise exception 'This session is not allowed to perform that action.' using errcode = '42501';
  end if;
  return jsonb_build_object('success', true, 'capability', v_capability, 'lodge_id', p_lodge_id,
    'user_id', v_user.id, 'role', v_role, 'session_type', v_session.session_type, 'outlet_id', p_outlet_id);
end;
$$;

create or replace function public.app_claim_operation_receipt(
  p_operation_id uuid,
  p_lodge_id uuid,
  p_device_id text,
  p_operation_type text,
  p_request_hash text
)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_existing public.app_operation_receipts%rowtype;
begin
  if public.app_is_service_role() = false then perform public.app_require_registered_device(p_lodge_id, p_device_id); end if;
  select * into v_existing from public.app_operation_receipts where operation_id = p_operation_id for update;
  if v_existing.operation_id is not null then
    if v_existing.lodge_id <> p_lodge_id or v_existing.request_hash <> p_request_hash then
      raise exception 'Operation ID was already used with a different request.' using errcode = '23505';
    end if;
    if v_existing.status = 'completed' then
      return jsonb_build_object('success', true, 'idempotent', true, 'replay', true, 'response', v_existing.canonical_response);
    end if;
    return jsonb_build_object('success', true, 'idempotent', true, 'replay', false, 'claimed', false, 'status', v_existing.status);
  end if;
  insert into public.app_operation_receipts(operation_id, lodge_id, device_id, operation_type, request_hash, status)
  values (p_operation_id, p_lodge_id, p_device_id, p_operation_type, p_request_hash, 'claimed');
  return jsonb_build_object('success', true, 'idempotent', false, 'replay', false, 'claimed', true, 'operation_id', p_operation_id);
end;
$$;

create or replace function public.app_record_operation_receipt(
  p_operation_id uuid,
  p_lodge_id uuid,
  p_device_id text,
  p_operation_type text,
  p_entity_id uuid,
  p_request_hash text,
  p_canonical_response jsonb
)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_existing public.app_operation_receipts%rowtype;
  v_response jsonb := coalesce(p_canonical_response, '{}'::jsonb);
begin
  select * into v_existing from public.app_operation_receipts where operation_id = p_operation_id for update;
  if v_existing.operation_id is not null then
    if v_existing.lodge_id <> p_lodge_id or v_existing.request_hash <> p_request_hash then
      raise exception 'Operation ID was already used with a different request.' using errcode = '23505';
    end if;
    if v_existing.status = 'completed' then
      return jsonb_build_object('success', true, 'idempotent', true, 'response', v_existing.canonical_response);
    end if;
    update public.app_operation_receipts
       set entity_id = coalesce(p_entity_id, entity_id), canonical_response = v_response,
           completed_at = now(), accepted_at = coalesce(accepted_at, now()), status = 'completed'
     where operation_id = p_operation_id;
  else
    insert into public.app_operation_receipts(operation_id, lodge_id, device_id, operation_type, entity_id,
      request_hash, canonical_response, accepted_at, completed_at, status)
    values (p_operation_id, p_lodge_id, p_device_id, p_operation_type, p_entity_id, p_request_hash,
      v_response, now(), now(), 'completed');
  end if;
  return jsonb_build_object('success', true, 'idempotent', false, 'response', v_response);
end;
$$;

create or replace function public.app_append_operation_audit(
  p_lodge_id uuid,
  p_operation_id uuid,
  p_operation_type text,
  p_entity_type text,
  p_entity_id uuid,
  p_details jsonb default '{}'::jsonb
)
returns uuid
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_session public.app_sessions%rowtype;
  v_device_id text;
  v_id uuid;
begin
  v_session := public.app_current_session_row();
  if v_session.id is null and not public.app_is_service_role() then
    raise exception 'A valid app session is required.' using errcode = '42501';
  end if;
  if v_session.id is not null and v_session.lodge_id <> p_lodge_id then
    raise exception 'Access denied for this lodge.' using errcode = '42501';
  end if;
  v_device_id := nullif(v_session.metadata->>'device_id', '');
  insert into public.app_operation_audit_log(operation_id, lodge_id, operation_type, entity_type, entity_id, actor_id, device_id, details, created_at)
  values (p_operation_id, p_lodge_id, p_operation_type, p_entity_type, p_entity_id,
    v_session.user_id, v_device_id, coalesce(p_details, '{}'::jsonb), now())
  returning id into v_id;
  return v_id;
end;
$$;

create or replace function public.app_current_device_id()
returns text
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_session public.app_sessions%rowtype;
  v_device_id text;
begin
  v_session := public.app_current_session_row();
  v_device_id := nullif(btrim(coalesce(v_session.metadata->>'device_id', '')), '');
  if v_device_id is null then return null; end if;
  if not exists (
    select 1 from public.app_registered_devices d
     where d.lodge_id = v_session.lodge_id
       and d.device_id = v_device_id
       and d.status = 'active'
       and d.revoked_at is null
  ) then
    return null;
  end if;
  return v_device_id;
end;
$$;

create or replace function public.app_append_audit_event(
  p_lodge_id uuid,
  p_event_type text,
  p_entity_type text default null,
  p_entity_id uuid default null,
  p_operation_id uuid default null,
  p_details jsonb default '{}'::jsonb
)
returns uuid
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_session public.app_sessions%rowtype;
  v_device_id text;
  v_id uuid;
begin
  v_session := public.app_current_session_row();
  if v_session.id is null and not public.app_is_service_role() then
    raise exception 'A valid app session is required.' using errcode = '42501';
  end if;
  if v_session.id is not null and v_session.lodge_id <> p_lodge_id then
    raise exception 'Access denied for this lodge.' using errcode = '42501';
  end if;
  v_device_id := public.app_current_device_id();
  insert into public.app_audit_events(operation_id, lodge_id, event_type, entity_type, entity_id, actor_id, device_id, details, created_at)
  values (p_operation_id, p_lodge_id, nullif(btrim(p_event_type), ''), p_entity_type, p_entity_id,
    v_session.user_id, v_device_id, coalesce(p_details, '{}'::jsonb), now())
  returning id into v_id;
  return v_id;
end;
$$;

revoke all on function public.app_register_device(uuid, text, jsonb) from public;
revoke all on function public.app_require_registered_device(uuid, text) from public;
revoke all on function public.app_require_capability(uuid, text, uuid, text) from public;
revoke all on function public.app_claim_operation_receipt(uuid, uuid, text, text, text) from public;
revoke all on function public.app_record_operation_receipt(uuid, uuid, text, text, uuid, text, jsonb) from public;
revoke all on function public.app_append_operation_audit(uuid, uuid, text, text, uuid, jsonb) from public;
revoke all on function public.app_current_device_id() from public;
revoke all on function public.app_append_audit_event(uuid, text, text, uuid, uuid, jsonb) from public;
grant execute on function public.app_register_device(uuid, text, jsonb) to anon, authenticated;
grant execute on function public.app_require_registered_device(uuid, text) to authenticated;
grant execute on function public.app_require_capability(uuid, text, uuid, text) to authenticated;

-- Device metadata is attached to the authenticated session during online setup.
-- These overloads preserve the existing authentication signatures for older clients.
create or replace function public.authenticate_user_for_device(
  p_email text,
  p_password text,
  p_session_type text,
  p_metadata jsonb
)
returns table(
  contract_version integer,
  found boolean,
  authenticated boolean,
  id uuid,
  name text,
  email text,
  role text,
  lodge_id uuid,
  created_at timestamptz,
  session_token text,
  session_expires_at timestamptz,
  reason text
)
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_row record;
begin
  for v_row in select * from public.authenticate_user_for_device(p_email, p_password, p_session_type)
  loop
    if v_row.session_token is not null and coalesce(p_metadata, '{}'::jsonb) <> '{}'::jsonb then
      update public.app_sessions
         set metadata = coalesce(metadata, '{}'::jsonb) || p_metadata
       where token_hash = public.app_hash_token(v_row.session_token);
    end if;
    return next v_row;
  end loop;
end;
$$;

create or replace function public.authenticate_user_from_supabase(
  p_lodge_id uuid,
  p_session_type text,
  p_metadata jsonb
)
returns table(
  contract_version integer,
  found boolean,
  authenticated boolean,
  id uuid,
  name text,
  email text,
  role text,
  lodge_id uuid,
  created_at timestamptz,
  session_token text,
  session_expires_at timestamptz
)
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_row record;
begin
  for v_row in select * from public.authenticate_user_from_supabase(p_lodge_id, p_session_type)
  loop
    if v_row.session_token is not null and coalesce(p_metadata, '{}'::jsonb) <> '{}'::jsonb then
      update public.app_sessions
         set metadata = coalesce(metadata, '{}'::jsonb) || p_metadata
       where token_hash = public.app_hash_token(v_row.session_token);
    end if;
    return next v_row;
  end loop;
end;
$$;

grant execute on function public.authenticate_user_for_device(text, text, text, jsonb) to anon, authenticated;
grant execute on function public.authenticate_user_from_supabase(uuid, text, jsonb) to anon, authenticated;
