-- Phase 3: authoritative returns, voids, and offline approval proofs.
--
-- This migration is deliberately additive.  Returns and voids are financial
-- operations and are exposed only through the security-definer RPCs below.
-- The desktop operation envelope and the operation-receipt ledger from Phase
-- 1 are reused so a crash/retry cannot create a second refund or reversal.

create table if not exists public.pos_returns (
  id uuid primary key default gen_random_uuid(),
  lodge_id uuid not null,
  outlet_id uuid not null references public.outlets(id) on delete restrict,
  operation_id uuid not null,
  device_id text not null,
  operation_contract_version integer not null default 2,
  original_order_id uuid not null references public.pos_orders(id) on delete restrict,
  status text not null default 'accepted',
  reason text not null,
  requested_by uuid,
  approved_by uuid,
  approval_assertion jsonb not null default '{}'::jsonb,
  receipt_number text,
  gross_total numeric not null default 0,
  modifier_total numeric not null default 0,
  discount_total numeric not null default 0,
  tax_total numeric not null default 0,
  net_total numeric not null default 0,
  refund_status text not null default 'recorded',
  refund_reference text,
  folio_credit_charge_id uuid references public.booking_charges(id) on delete set null,
  accepted_at timestamptz not null default now(),
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  constraint pos_returns_status_chk check (status in ('accepted', 'pending_external_refund', 'rejected')),
  constraint pos_returns_refund_status_chk check (refund_status in ('not_required', 'recorded', 'pending_external_refund')),
  constraint pos_returns_amounts_nonnegative_chk check (
    gross_total >= 0 and modifier_total >= 0 and discount_total >= 0 and tax_total >= 0 and net_total >= 0
  ),
  constraint pos_returns_operation_uk unique (operation_id)
);

create index if not exists pos_returns_order_idx
  on public.pos_returns (lodge_id, original_order_id, created_at desc);
create unique index if not exists pos_returns_receipt_uidx
  on public.pos_returns (lodge_id, receipt_number) where receipt_number is not null;

create table if not exists public.pos_return_items (
  id uuid primary key default gen_random_uuid(),
  lodge_id uuid not null,
  return_id uuid not null references public.pos_returns(id) on delete cascade,
  original_order_id uuid not null references public.pos_orders(id) on delete restrict,
  original_order_item_id uuid not null references public.pos_order_items(id) on delete restrict,
  quantity integer not null check (quantity > 0),
  inventory_item_id uuid references public.inventory_items(id) on delete set null,
  depletion_qty numeric not null default 1 check (depletion_qty > 0),
  gross_amount numeric not null default 0 check (gross_amount >= 0),
  modifier_amount numeric not null default 0 check (modifier_amount >= 0),
  discount_amount numeric not null default 0 check (discount_amount >= 0),
  tax_amount numeric not null default 0 check (tax_amount >= 0),
  net_amount numeric not null default 0 check (net_amount >= 0),
  created_at timestamptz not null default now(),
  constraint pos_return_items_lodge_return_fk foreign key (return_id) references public.pos_returns(id) on delete cascade
);

create index if not exists pos_return_items_original_idx
  on public.pos_return_items (lodge_id, original_order_item_id, created_at);

alter table public.pos_returns add column if not exists shift_id uuid references public.pos_shifts(id) on delete set null;

create table if not exists public.pos_return_tenders (
  id uuid primary key default gen_random_uuid(),
  lodge_id uuid not null,
  return_id uuid not null references public.pos_returns(id) on delete cascade,
  method text not null,
  amount numeric not null check (amount > 0),
  status text not null default 'recorded',
  external_reference text,
  recorded_at timestamptz,
  created_at timestamptz not null default now(),
  constraint pos_return_tenders_method_chk check (method in ('cash', 'card', 'mobile_money', 'bank_transfer')),
  constraint pos_return_tenders_status_chk check (status in ('recorded', 'pending_external_refund', 'failed'))
);

create index if not exists pos_return_tenders_return_idx
  on public.pos_return_tenders (return_id, created_at);

create table if not exists public.pos_voids (
  id uuid primary key default gen_random_uuid(),
  lodge_id uuid not null,
  outlet_id uuid not null references public.outlets(id) on delete restrict,
  operation_id uuid not null,
  device_id text not null,
  operation_contract_version integer not null default 2,
  order_id uuid not null references public.pos_orders(id) on delete restrict,
  shift_id uuid references public.pos_shifts(id) on delete set null,
  status text not null default 'accepted',
  reason text not null,
  requested_by uuid,
  approved_by uuid,
  approval_assertion jsonb not null default '{}'::jsonb,
  folio_credit_charge_id uuid references public.booking_charges(id) on delete set null,
  reversal_status text not null default 'not_required',
  accepted_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  constraint pos_voids_status_chk check (status in ('accepted', 'rejected')),
  constraint pos_voids_reversal_status_chk check (reversal_status in ('not_required', 'recorded')),
  constraint pos_voids_operation_uk unique (operation_id)
);

create unique index if not exists pos_voids_order_accepted_uidx
  on public.pos_voids (lodge_id, order_id) where status = 'accepted';

alter table public.pos_orders
  add column if not exists voided_at timestamptz,
  add column if not exists voided_by uuid,
  add column if not exists void_reason text,
  add column if not exists void_operation_id uuid,
  add column if not exists void_folio_credit_id uuid references public.booking_charges(id) on delete set null;

alter table public.pos_returns enable row level security;
alter table public.pos_return_items enable row level security;
alter table public.pos_return_tenders enable row level security;
alter table public.pos_voids enable row level security;

drop policy if exists pos_returns_lodge_scope_select on public.pos_returns;
create policy pos_returns_lodge_scope_select on public.pos_returns for select using (public.app_lodge_access(lodge_id));
drop policy if exists pos_return_items_lodge_scope_select on public.pos_return_items;
create policy pos_return_items_lodge_scope_select on public.pos_return_items for select using (public.app_lodge_access(lodge_id));
drop policy if exists pos_return_tenders_lodge_scope_select on public.pos_return_tenders;
create policy pos_return_tenders_lodge_scope_select on public.pos_return_tenders for select using (public.app_lodge_access(lodge_id));
drop policy if exists pos_voids_lodge_scope_select on public.pos_voids;
create policy pos_voids_lodge_scope_select on public.pos_voids for select using (public.app_lodge_access(lodge_id));

revoke all on public.pos_returns, public.pos_return_items, public.pos_return_tenders, public.pos_voids from anon, authenticated;
grant select on public.pos_returns, public.pos_return_items, public.pos_return_tenders, public.pos_voids to authenticated;

-- Verify an offline approval assertion without ever accepting a PIN.  The
-- desktop signs the assertion fields (before adding signature metadata) with
-- its registered credential fingerprint.  JSONB text is canonical in
-- PostgreSQL (keys sorted), matching the desktop canonicalizer.
create or replace function public.app_verify_pos_approval(
  p_lodge_id uuid,
  p_outlet_id uuid,
  p_entity_id uuid,
  p_operation_id uuid,
  p_reason text,
  p_device_id text,
  p_assertion jsonb,
  p_capability text
)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_session public.app_sessions%rowtype;
  v_device public.app_registered_devices%rowtype;
  v_approver public.users%rowtype;
  v_assertion jsonb := coalesce(p_assertion, '{}'::jsonb);
  v_core jsonb;
  v_approver_id uuid;
  v_asserted_operation uuid;
  v_asserted_entity uuid;
  v_asserted_outlet uuid;
  v_asserted_at timestamptz;
  v_signature text;
  v_credential text;
  v_expected text;
  v_role text;
  v_allowed boolean := false;
begin
  perform public.app_reject_pwa_financial_mutation();
  v_session := public.app_current_session_row();
  if v_session.id is null or v_session.session_type <> 'desktop' then
    raise exception 'A desktop session is required for an approval.' using errcode = '42501';
  end if;
  if v_session.lodge_id <> p_lodge_id then
    raise exception 'Approval lodge does not match the authenticated session.' using errcode = '42501';
  end if;
  if nullif(btrim(coalesce(p_reason, '')), '') is null then
    raise exception 'A non-empty approval reason is required.' using errcode = '22023';
  end if;
  if nullif(btrim(coalesce(p_device_id, '')), '') is null then
    raise exception 'A registered device is required for an approval.' using errcode = '42501';
  end if;
  perform public.app_require_registered_device(p_lodge_id, p_device_id);
  select * into v_device from public.app_registered_devices d
   where d.lodge_id = p_lodge_id and d.device_id = btrim(p_device_id) and d.status = 'active' and d.revoked_at is null
   for update;
  if v_device.id is null then raise exception 'The approval device is not registered.' using errcode = '42501'; end if;

  v_approver_id := nullif(coalesce(v_assertion->>'approver_id', ''), '')::uuid;
  v_asserted_operation := nullif(coalesce(v_assertion->>'operation_id', ''), '')::uuid;
  v_asserted_entity := nullif(coalesce(v_assertion->>'entity_id', ''), '')::uuid;
  v_asserted_outlet := nullif(coalesce(v_assertion->>'outlet_id', ''), '')::uuid;
  v_asserted_at := nullif(coalesce(v_assertion->>'asserted_at', ''), '')::timestamptz;
  v_signature := nullif(btrim(coalesce(v_assertion->>'signature', v_assertion->>'approval_signature', '')), '');
  if v_approver_id is null or v_asserted_operation is distinct from p_operation_id
     or v_asserted_entity is distinct from p_entity_id or v_asserted_outlet is distinct from p_outlet_id
     or v_assertion->>'reason' is distinct from p_reason or v_assertion->>'device_id' is distinct from p_device_id
     or v_asserted_at is null or v_signature is null then
    raise exception 'Approval assertion does not match this operation.' using errcode = '42501';
  end if;
  if v_asserted_at > now() + interval '5 minutes' or v_asserted_at < now() - interval '7 days' then
    raise exception 'Approval assertion is outside the accepted time window.' using errcode = '42501';
  end if;

  select * into v_approver from public.users u
   where u.id = v_approver_id and u.lodge_id = p_lodge_id and lower(coalesce(u.status, 'active')) = 'active';
  if v_approver.id is null then raise exception 'The approving staff account is unavailable.' using errcode = '42501'; end if;
  v_role := lower(coalesce(v_approver.role, ''));
  v_allowed := v_role in ('master_admin', 'super_admin', 'admin', 'manager', 'supervisor');
  if jsonb_typeof(v_approver.capability_overrides -> lower(p_capability)) = 'boolean' then
    v_allowed := (v_approver.capability_overrides -> lower(p_capability))::text = 'true';
  end if;
  if not v_allowed then raise exception 'The approver is not entitled to approve this operation.' using errcode = '42501'; end if;
  if v_role not in ('master_admin', 'super_admin', 'admin', 'manager')
     and not coalesce(p_outlet_id = any(coalesce(v_approver.allowed_outlet_ids, '{}'::uuid[])), false) then
    raise exception 'The approver is not assigned to this outlet.' using errcode = '42501';
  end if;

  v_credential := nullif(coalesce(v_device.credential_fingerprint, v_device.public_key,
    v_device.metadata->>'credential_fingerprint', v_assertion->>'credential_fingerprint', v_device.device_id), '');
  if v_credential is null then raise exception 'The device has no approval credential.' using errcode = '42501'; end if;
  if v_assertion ? 'credential_fingerprint'
     and v_device.credential_fingerprint is not null
     and v_assertion->>'credential_fingerprint' is distinct from v_device.credential_fingerprint then
    raise exception 'Approval credential does not match the registered device.' using errcode = '42501';
  end if;
  v_core := v_assertion - 'signature' - 'approval_signature' - 'credential_fingerprint' - 'signature_algorithm' - 'proof_version' - 'signed';
  v_expected := encode(extensions.digest(convert_to(v_core::text || ':' || v_credential, 'UTF8'), 'sha256'), 'hex');
  if v_signature <> v_expected then
    raise exception 'Approval signature verification failed.' using errcode = '42501';
  end if;
  return jsonb_build_object('success', true, 'approver_id', v_approver.id, 'approver_role', v_role,
    'device_id', v_device.device_id, 'asserted_at', v_asserted_at);
end;
$$;

revoke all on function public.app_verify_pos_approval(uuid, uuid, uuid, uuid, text, text, jsonb, text) from public;

create or replace function public.return_pos_order_v2(payload jsonb)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_contract integer := nullif(payload->>'contract_version', '')::integer;
  v_operation_id uuid := nullif(payload->>'operation_id', '')::uuid;
  v_device_id text := nullif(btrim(payload->>'device_id'), '');
  v_lodge_id uuid := nullif(payload->>'lodge_id', '')::uuid;
  v_outlet_id uuid := nullif(payload->>'outlet_id', '')::uuid;
  v_body jsonb := coalesce(payload->'payload', '{}'::jsonb);
  v_order_id uuid := nullif(v_body->>'order_id', '')::uuid;
  v_items jsonb := coalesce(v_body->'items', '[]'::jsonb);
  v_reason text := nullif(btrim(v_body->>'reason'), '');
  v_order public.pos_orders%rowtype;
  v_item public.pos_order_items%rowtype;
  v_return public.pos_returns%rowtype;
  v_return_item_id uuid;
  v_entry jsonb;
  v_requested numeric;
  v_returned numeric;
  v_available numeric;
  v_gross numeric;
  v_modifier numeric;
  v_discount numeric;
  v_tax numeric;
  v_net numeric;
  v_prev_gross numeric;
  v_prev_modifier numeric;
  v_prev_discount numeric;
  v_prev_tax numeric;
  v_prev_net numeric;
  v_depletion numeric;
  v_stock numeric;
  v_line_total numeric := 0;
  v_gross_total numeric := 0;
  v_modifier_total numeric := 0;
  v_discount_total numeric := 0;
  v_tax_total numeric := 0;
  v_net_total numeric := 0;
  v_claim jsonb;
  v_hash text := encode(extensions.digest(convert_to(payload::text, 'UTF8'), 'sha256'), 'hex');
  v_approval jsonb;
  v_receipt_year integer;
  v_receipt_seq integer;
  v_receipt text;
  v_tender jsonb;
  v_tenders jsonb := coalesce(v_body->'refund_tenders', '[]'::jsonb);
  v_tender_total numeric := 0;
  v_tender_status text;
  v_refund_status text := 'recorded';
  v_folio_credit_id uuid;
  v_booking_id uuid;
  v_response jsonb;
begin
  if v_contract is distinct from 2 or v_operation_id is null or v_device_id is null or v_lodge_id is null or v_outlet_id is null then
    return jsonb_build_object('success', false, 'code', 'OPERATION_ENVELOPE_INVALID', 'retryable', false);
  end if;
  perform public.app_reject_pwa_financial_mutation();
  perform public.app_require_capability(v_lodge_id, 'pos.return', v_outlet_id, v_device_id);
  v_claim := public.app_claim_operation_receipt(v_operation_id, v_lodge_id, v_device_id, 'pos_return_v2', v_hash);
  if coalesce((v_claim->>'replay')::boolean, false) then return coalesce(v_claim->'response', v_claim); end if;
  if not coalesce((v_claim->>'claimed')::boolean, false) then
    return jsonb_build_object('success', false, 'code', 'OPERATION_IN_PROGRESS', 'retryable', true, 'operation_id', v_operation_id);
  end if;
  if v_order_id is null or v_reason is null or jsonb_typeof(v_items) <> 'array' or jsonb_array_length(v_items) = 0 then
    raise exception 'A return requires an order, non-empty reason, and at least one item.' using errcode = '22023';
  end if;
  select * into v_order from public.pos_orders po where po.id = v_order_id and po.lodge_id = v_lodge_id for update;
  if v_order.id is null or v_order.outlet_id is distinct from v_outlet_id then raise exception 'Order is outside the lodge or outlet scope.' using errcode = '42501'; end if;
  if lower(coalesce(v_order.status, '')) in ('voided', 'open') then raise exception 'Only a completed sale can be returned.' using errcode = '40901'; end if;
  v_approval := coalesce(v_body->'approval_assertion', '{}'::jsonb);
  perform public.app_verify_pos_approval(v_lodge_id, v_outlet_id, v_order_id, v_operation_id, v_reason, v_device_id, v_approval, 'pos.return');
  -- Claim the return entity before inserting line rows so foreign keys remain
  -- valid even if the operation is later rolled back by a tender/stock check.
  insert into public.pos_returns(lodge_id, outlet_id, operation_id, device_id, original_order_id, shift_id, status, reason, requested_by, approved_by, approval_assertion)
  values(v_lodge_id, v_outlet_id, v_operation_id, v_device_id, v_order_id, v_order.shift_id, 'accepted', v_reason, public.app_current_user_id(),
    nullif(v_approval->>'approver_id', '')::uuid, v_approval)
  returning * into v_return;

  for v_entry in select value from jsonb_array_elements(v_items) order by value->>'order_item_id'
  loop
    v_item := null;
    select * into v_item from public.pos_order_items poi
     where poi.id = nullif(v_entry->>'order_item_id', '')::uuid and poi.order_id = v_order_id and poi.lodge_id = v_lodge_id
     for update;
    if v_item.id is null then raise exception 'The selected sale line is not part of this order.' using errcode = '42501'; end if;
    v_requested := nullif(v_entry->>'quantity', '')::numeric;
    if v_requested is null or v_requested <= 0 or v_requested <> trunc(v_requested) then raise exception 'Return quantities must be positive whole numbers.' using errcode = '22023'; end if;
    select coalesce(sum(pri.quantity), 0), coalesce(sum(pri.gross_amount), 0), coalesce(sum(pri.modifier_amount), 0),
           coalesce(sum(pri.discount_amount), 0), coalesce(sum(pri.tax_amount), 0), coalesce(sum(pri.net_amount), 0)
      into v_returned, v_prev_gross, v_prev_modifier, v_prev_discount, v_prev_tax, v_prev_net
      from public.pos_return_items pri join public.pos_returns pr on pr.id = pri.return_id
     where pri.original_order_item_id = v_item.id and pr.lodge_id = v_lodge_id
       and pr.status in ('accepted', 'pending_external_refund');
    v_available := coalesce(v_item.quantity, 0) - coalesce(v_returned, 0);
    if v_requested > v_available then raise exception 'Return quantity exceeds the remaining sold quantity.' using errcode = '40902'; end if;
    v_gross := coalesce(nullif(v_item.gross_subtotal, 0), nullif(v_item.subtotal, 0), v_item.unit_price * v_item.quantity);
    v_modifier := coalesce(v_item.modifier_subtotal, 0);
    v_discount := coalesce(v_item.discount_allocated, 0);
    v_tax := coalesce(v_item.tax_allocated, 0);
    -- `net_subtotal` in legacy rows is pre-tax; return value is the
    -- authoritative gross less discount plus the allocated tax.
    v_net := greatest(0, v_gross - v_discount + v_tax);
    if v_requested = v_available then
      v_gross := greatest(0, v_gross - v_prev_gross); v_modifier := greatest(0, v_modifier - v_prev_modifier);
      v_discount := greatest(0, v_discount - v_prev_discount); v_tax := greatest(0, v_tax - v_prev_tax); v_net := greatest(0, v_net - v_prev_net);
    else
      v_gross := round(v_gross * v_requested / nullif(v_item.quantity, 0), 2);
      v_modifier := round(v_modifier * v_requested / nullif(v_item.quantity, 0), 2);
      v_discount := round(v_discount * v_requested / nullif(v_item.quantity, 0), 2);
      v_tax := round(v_tax * v_requested / nullif(v_item.quantity, 0), 2);
      v_net := round(v_net * v_requested / nullif(v_item.quantity, 0), 2);
    end if;
    v_depletion := greatest(coalesce(v_item.depletion_qty, 1), 0.0001);
    insert into public.pos_return_items(lodge_id, return_id, original_order_id, original_order_item_id, quantity, inventory_item_id, depletion_qty,
      gross_amount, modifier_amount, discount_amount, tax_amount, net_amount)
    values(v_lodge_id, v_return.id, v_order_id, v_item.id, v_requested::integer, v_item.inventory_item_id, v_depletion,
      v_gross, v_modifier, v_discount, v_tax, v_net)
    returning id into v_return_item_id;
    if v_item.inventory_item_id is not null then
      update public.inventory_items set current_stock = coalesce(current_stock, 0) + (v_requested * v_depletion)
       where id = v_item.inventory_item_id and lodge_id = v_lodge_id returning current_stock into v_stock;
      perform public._log_inventory_movement(v_lodge_id, v_item.inventory_item_id, 'pos_return', v_requested * v_depletion,
        (select coalesce(ii.latest_unit_cost, 0) from public.inventory_items ii where ii.id = v_item.inventory_item_id),
        v_item.item_name, 'pos_return_item', v_return_item_id, 'pos_return', public.app_current_user_id());
    end if;
    v_gross_total := v_gross_total + v_gross; v_modifier_total := v_modifier_total + v_modifier;
    v_discount_total := v_discount_total + v_discount; v_tax_total := v_tax_total + v_tax; v_net_total := v_net_total + v_net;
  end loop;
  if v_net_total <= 0 then raise exception 'The return amount must be greater than zero.' using errcode = '22023'; end if;

  v_receipt_year := extract(year from now())::integer;
  insert into public.pos_receipt_sequences(lodge_id, year, last_number) values(v_lodge_id, v_receipt_year, 0) on conflict(lodge_id, year) do nothing;
  select last_number into v_receipt_seq from public.pos_receipt_sequences where lodge_id = v_lodge_id and year = v_receipt_year for update;
  update public.pos_receipt_sequences set last_number = v_receipt_seq + 1 where lodge_id = v_lodge_id and year = v_receipt_year;
  v_receipt := 'CR-' || v_receipt_year::text || '-' || lpad((v_receipt_seq + 1)::text, 6, '0');
  update public.pos_returns set receipt_number = v_receipt, gross_total = v_gross_total, modifier_total = v_modifier_total,
    discount_total = v_discount_total, tax_total = v_tax_total, net_total = v_net_total, completed_at = now()
   where id = v_return.id;

  v_booking_id := v_order.booking_id;
  if lower(coalesce(v_order.payment_method, '')) = 'folio' and v_booking_id is not null then
    perform 1 from public.bookings where id = v_booking_id and lodge_id = v_lodge_id for update;
    insert into public.booking_charges(lodge_id, booking_id, description, amount, category, quantity, outlet_id)
    values(v_lodge_id, v_booking_id, 'POS return ' || v_receipt, -v_net_total, 'pos_return_credit', 1, v_outlet_id)
    returning id into v_folio_credit_id;
    update public.pos_returns set folio_credit_charge_id = v_folio_credit_id where id = v_return.id;
  else
    if jsonb_typeof(v_tenders) <> 'array' or jsonb_array_length(v_tenders) = 0 then raise exception 'Refund tenders are required for a non-folio return.' using errcode = '22023'; end if;
    for v_tender in select value from jsonb_array_elements(v_tenders)
    loop
      if lower(coalesce(v_tender->>'method', '')) not in ('cash', 'card', 'mobile_money', 'bank_transfer') then raise exception 'Refund tender method is not allowed.' using errcode = '22023'; end if;
      if coalesce((v_tender->>'amount')::numeric, 0) <= 0 then raise exception 'Refund tender amount must be positive.' using errcode = '22023'; end if;
      v_tender_total := v_tender_total + round((v_tender->>'amount')::numeric, 2);
      v_tender_status := lower(coalesce(v_tender->>'status', case when lower(v_tender->>'method') = 'cash' then 'recorded' else 'pending_external_refund' end));
      if lower(v_tender->>'method') <> 'cash' and (v_tender_status <> 'recorded' or nullif(btrim(v_tender->>'external_reference'), '') is null) then v_refund_status := 'pending_external_refund'; v_tender_status := 'pending_external_refund'; end if;
      insert into public.pos_return_tenders(lodge_id, return_id, method, amount, status, external_reference, recorded_at)
      values(v_lodge_id, v_return.id, lower(v_tender->>'method'), round((v_tender->>'amount')::numeric, 2), v_tender_status,
        nullif(btrim(v_tender->>'external_reference'), ''), case when v_tender_status = 'recorded' then now() else null end);
    end loop;
    if round(v_tender_total, 2) <> round(v_net_total, 2) then raise exception 'Refund tender total does not match the authoritative return amount.' using errcode = '22023'; end if;
    if v_refund_status = 'pending_external_refund' then
      update public.pos_returns set status = 'pending_external_refund', refund_status = 'pending_external_refund' where id = v_return.id;
    end if;
  end if;
  select * into v_return from public.pos_returns where id = v_return.id;
  v_response := jsonb_build_object('success', true, 'operation_id', v_operation_id, 'entity_id', v_return.id, 'id', v_return.id,
    'order_id', v_order_id, 'receipt_number', v_return.receipt_number, 'return_receipt_number', v_return.receipt_number,
    'accepted_at', v_return.accepted_at, 'refund_status', v_return.refund_status, 'refund_state', v_return.refund_status,
    'folio_credit_charge_id', v_return.folio_credit_charge_id,
    'authoritative_totals', jsonb_build_object('gross_total', v_return.gross_total, 'modifier_total', v_return.modifier_total,
      'discount_total', v_return.discount_total, 'tax_total', v_return.tax_total, 'net_total', v_return.net_total));
  perform public.app_record_operation_receipt(v_operation_id, v_lodge_id, v_device_id, 'pos_return_v2', v_return.id, v_hash, v_response);
  perform public.app_append_audit_event(v_lodge_id, 'pos_return_v2_completed', 'pos_return', v_return.id, v_operation_id, v_response);
  return v_response;
end;
$$;

-- Name retained for the plan's original spelling; both names share one implementation.
create or replace function public.return_pos_order_items_v2(payload jsonb)
returns jsonb language sql security definer set search_path to 'public'
as $$ select public.return_pos_order_v2(payload); $$;

create or replace function public.void_pos_order_v2(payload jsonb)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_contract integer := nullif(payload->>'contract_version', '')::integer;
  v_operation_id uuid := nullif(payload->>'operation_id', '')::uuid;
  v_device_id text := nullif(btrim(payload->>'device_id'), '');
  v_lodge_id uuid := nullif(payload->>'lodge_id', '')::uuid;
  v_outlet_id uuid := nullif(payload->>'outlet_id', '')::uuid;
  v_body jsonb := coalesce(payload->'payload', '{}'::jsonb);
  v_order_id uuid := nullif(v_body->>'order_id', '')::uuid;
  v_reason text := nullif(btrim(v_body->>'reason'), '');
  v_order public.pos_orders%rowtype;
  v_void public.pos_voids%rowtype;
  v_claim jsonb;
  v_approval jsonb;
  v_hash text := encode(extensions.digest(convert_to(payload::text, 'UTF8'), 'sha256'), 'hex');
  v_folio_credit_id uuid;
  v_response jsonb;
begin
  if v_contract is distinct from 2 or v_operation_id is null or v_device_id is null or v_lodge_id is null or v_outlet_id is null then
    return jsonb_build_object('success', false, 'code', 'OPERATION_ENVELOPE_INVALID', 'retryable', false);
  end if;
  perform public.app_reject_pwa_financial_mutation();
  perform public.app_require_capability(v_lodge_id, 'pos.void.request', v_outlet_id, v_device_id);
  v_claim := public.app_claim_operation_receipt(v_operation_id, v_lodge_id, v_device_id, 'pos_void_v2', v_hash);
  if coalesce((v_claim->>'replay')::boolean, false) then return coalesce(v_claim->'response', v_claim); end if;
  if not coalesce((v_claim->>'claimed')::boolean, false) then return jsonb_build_object('success', false, 'code', 'OPERATION_IN_PROGRESS', 'retryable', true, 'operation_id', v_operation_id); end if;
  if v_order_id is null or v_reason is null then raise exception 'A void requires an order and non-empty reason.' using errcode = '22023'; end if;
  select * into v_order from public.pos_orders po where po.id = v_order_id and po.lodge_id = v_lodge_id for update;
  if v_order.id is null or v_order.outlet_id is distinct from v_outlet_id then raise exception 'Order is outside the lodge or outlet scope.' using errcode = '42501'; end if;
  if lower(coalesce(v_order.status, '')) = 'voided' then raise exception 'The order is already voided.' using errcode = '40901'; end if;
  if lower(coalesce(v_order.status, '')) in ('completed', 'settled') then raise exception 'A settled sale requires a return instead of a void.' using errcode = '40901'; end if;
  if exists(select 1 from public.pos_return_items pri join public.pos_returns pr on pr.id = pri.return_id where pri.original_order_id = v_order_id and pr.status in ('accepted','pending_external_refund')) then raise exception 'A returned sale cannot be voided.' using errcode = '40901'; end if;
  v_approval := coalesce(v_body->'approval_assertion', '{}'::jsonb);
  perform public.app_verify_pos_approval(v_lodge_id, v_outlet_id, v_order_id, v_operation_id, v_reason, v_device_id, v_approval, 'pos.void');
  insert into public.pos_voids(lodge_id, outlet_id, operation_id, device_id, order_id, shift_id, status, reason, requested_by, approved_by, approval_assertion)
  values(v_lodge_id, v_outlet_id, v_operation_id, v_device_id, v_order_id, v_order.shift_id, 'accepted', v_reason, public.app_current_user_id(), nullif(v_approval->>'approver_id', '')::uuid, v_approval)
  returning * into v_void;
  perform public._restore_pos_order_stock(v_order_id, v_lodge_id);
  if lower(coalesce(v_order.payment_method, '')) = 'folio' and v_order.booking_id is not null then
    perform 1 from public.bookings where id = v_order.booking_id and lodge_id = v_lodge_id for update;
    insert into public.booking_charges(lodge_id, booking_id, description, amount, category, quantity, outlet_id)
    values(v_lodge_id, v_order.booking_id, 'POS void reversal ' || v_order.id::text, -abs(coalesce(v_order.total, 0)), 'pos_void_credit', 1, v_outlet_id)
    returning id into v_folio_credit_id;
    update public.pos_voids set folio_credit_charge_id = v_folio_credit_id, reversal_status = 'recorded' where id = v_void.id;
  end if;
  update public.pos_orders set status = 'voided', voided_at = now(), voided_by = public.app_current_user_id(), void_reason = v_reason,
    void_operation_id = v_operation_id, void_folio_credit_id = v_folio_credit_id where id = v_order_id and lodge_id = v_lodge_id;
  select * into v_void from public.pos_voids where id = v_void.id;
  v_response := jsonb_build_object('success', true, 'operation_id', v_operation_id, 'entity_id', v_order_id, 'void_id', v_void.id,
    'accepted_at', v_void.accepted_at, 'voided_at', now(), 'reversal_status', v_void.reversal_status,
    'folio_credit_charge_id', v_void.folio_credit_charge_id);
  perform public.app_record_operation_receipt(v_operation_id, v_lodge_id, v_device_id, 'pos_void_v2', v_order_id, v_hash, v_response);
  perform public.app_append_audit_event(v_lodge_id, 'pos_void_v2_completed', 'pos_order', v_order_id, v_operation_id, v_response);
  return v_response;
end;
$$;

revoke all on function public.return_pos_order_v2(jsonb) from public;
revoke all on function public.return_pos_order_items_v2(jsonb) from public;
revoke all on function public.void_pos_order_v2(jsonb) from public;
grant execute on function public.return_pos_order_v2(jsonb), public.return_pos_order_items_v2(jsonb), public.void_pos_order_v2(jsonb) to anon, authenticated, service_role;
