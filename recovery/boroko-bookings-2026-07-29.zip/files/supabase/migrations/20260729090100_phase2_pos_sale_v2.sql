-- Phase 2: authoritative Restaurant/Bar sale contract.
-- Additive migration. Legacy create_pos_order remains available only for draining old queues;
-- new clients call create_pos_order_v2 and never silently fall back to v1.

create table if not exists public.pos_tax_profiles (
  id uuid primary key default gen_random_uuid(),
  lodge_id uuid not null,
  outlet_id uuid,
  name text not null default 'Default tax profile',
  rate numeric not null default 0 check (rate >= 0 and rate <= 100),
  currency text,
  effective_from timestamptz not null default now(),
  effective_to timestamptz,
  active boolean not null default true,
  created_by uuid,
  created_at timestamptz not null default now()
);

create index if not exists pos_tax_profiles_scope_idx
  on public.pos_tax_profiles (lodge_id, outlet_id, active, effective_from desc);

create table if not exists public.pos_menu_price_history (
  id uuid primary key default gen_random_uuid(),
  lodge_id uuid not null,
  outlet_id uuid,
  menu_item_id uuid not null references public.pos_menu_items(id) on delete cascade,
  unit_price numeric not null check (unit_price >= 0),
  tax_profile_id uuid references public.pos_tax_profiles(id),
  catalog_version text not null,
  effective_from timestamptz not null default now(),
  effective_to timestamptz,
  created_by uuid,
  created_at timestamptz not null default now(),
  immutable_marker boolean not null default true,
  unique (lodge_id, menu_item_id, catalog_version)
);

create index if not exists pos_menu_price_history_lookup_idx
  on public.pos_menu_price_history (lodge_id, outlet_id, menu_item_id, effective_from desc);

alter table public.pos_menu_items
  add column if not exists current_price_history_id uuid,
  add column if not exists catalog_version text;

alter table public.pos_orders
  add column if not exists operation_id uuid,
  add column if not exists device_id text,
  add column if not exists operation_contract_version integer,
  add column if not exists cashier_actor_id uuid,
  add column if not exists accepted_at timestamptz,
  add column if not exists authoritative_total numeric,
  add column if not exists authoritative_gross_total numeric,
  add column if not exists authoritative_discount_total numeric,
  add column if not exists authoritative_tax_total numeric,
  add column if not exists authoritative_tip_total numeric,
  add column if not exists tax_profile_id uuid,
  add column if not exists reconciliation_state text not null default 'authoritative';

alter table public.pos_order_items
  add column if not exists price_history_id uuid,
  add column if not exists catalog_version text,
  add column if not exists modifiers jsonb not null default '[]'::jsonb,
  add column if not exists item_notes text,
  add column if not exists gross_subtotal numeric not null default 0,
  add column if not exists modifier_subtotal numeric not null default 0,
  add column if not exists discount_allocated numeric not null default 0,
  add column if not exists tax_allocated numeric not null default 0,
  add column if not exists net_subtotal numeric not null default 0;

create unique index if not exists pos_orders_operation_id_uidx
  on public.pos_orders (operation_id)
  where operation_id is not null;

create unique index if not exists pos_receipt_sequences_lodge_year_uidx
  on public.pos_receipt_sequences (lodge_id, year);

-- Backfill a trusted historical price snapshot for existing menus. Legacy entries are explicitly
-- versioned; they are never repriced during replay.
insert into public.pos_menu_price_history (
  lodge_id, outlet_id, menu_item_id, unit_price, catalog_version, effective_from
)
select pmi.lodge_id,
       pmi.outlet_id,
       pmi.id,
       greatest(coalesce(pmi.price, 0), 0),
       'legacy-' || pmi.id::text,
       coalesce(pmi.created_at, now())
  from public.pos_menu_items pmi
 where not exists (
   select 1 from public.pos_menu_price_history ph
    where ph.menu_item_id = pmi.id
      and ph.lodge_id = pmi.lodge_id
      and ph.catalog_version = 'legacy-' || pmi.id::text
 );

update public.pos_menu_items pmi
   set current_price_history_id = ph.id,
       catalog_version = ph.catalog_version
  from public.pos_menu_price_history ph
 where ph.menu_item_id = pmi.id
   and ph.lodge_id = pmi.lodge_id
   and pmi.current_price_history_id is null;

insert into public.pos_tax_profiles (lodge_id, name, rate, effective_from, active)
select s.lodge_id, 'Default tax profile', greatest(0, least(100, coalesce(s.vat_rate, 0))), now(), true
  from public.settings s
 where not exists (
   select 1 from public.pos_tax_profiles tp
    where tp.lodge_id = s.lodge_id and tp.outlet_id is null and tp.active = true
 );

alter table public.pos_tax_profiles enable row level security;
alter table public.pos_menu_price_history enable row level security;

drop policy if exists pos_tax_profiles_lodge_select on public.pos_tax_profiles;
create policy pos_tax_profiles_lodge_select on public.pos_tax_profiles for select using (public.app_lodge_access(lodge_id));
drop policy if exists pos_menu_price_history_lodge_select on public.pos_menu_price_history;
create policy pos_menu_price_history_lodge_select on public.pos_menu_price_history for select using (public.app_lodge_access(lodge_id));

revoke all on public.pos_tax_profiles, public.pos_menu_price_history from anon, authenticated;
grant select on public.pos_tax_profiles, public.pos_menu_price_history to anon, authenticated;

create or replace function public.create_pos_order_v2(payload jsonb)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_contract integer := nullif(payload->>'contract_version', '')::integer;
  v_operation_id uuid := nullif(payload->>'operation_id', '')::uuid;
  v_device_id text := nullif(btrim(payload->>'device_id'), '');
  v_lodge_id uuid := nullif(payload->>'lodge_id', '')::uuid;
  v_outlet_id uuid := nullif(payload->>'outlet_id', '')::uuid;
  v_body jsonb := coalesce(payload->'payload', '{}'::jsonb);
  v_items jsonb := coalesce(v_body->'items', '[]'::jsonb);
  v_item jsonb;
  v_menu public.pos_menu_items%rowtype;
  v_history public.pos_menu_price_history%rowtype;
  v_inventory public.inventory_items%rowtype;
  v_tax_profile public.pos_tax_profiles%rowtype;
  v_booking public.bookings%rowtype;
  v_line jsonb;
  v_server_items jsonb := '[]'::jsonb;
  v_seen integer := 0;
  v_menu_id uuid;
  v_history_id uuid;
  v_inventory_id uuid;
  v_qty numeric;
  v_depletion numeric;
  v_price numeric;
  v_line_gross numeric;
  v_modifier_total numeric;
  v_gross numeric := 0;
  v_discount numeric := 0;
  v_tax_rate numeric := 0;
  v_tax_amount numeric := 0;
  v_tip numeric := 0;
  v_total numeric := 0;
  v_payment_method text := lower(coalesce(v_body->>'payment_method', 'cash'));
  v_tenders jsonb := coalesce(v_body->'tenders', '[]'::jsonb);
  v_tender jsonb;
  v_tender_total numeric := 0;
  v_receipt_year integer;
  v_receipt_seq integer;
  v_receipt text;
  v_order_id uuid := coalesce(nullif(v_body->>'id', '')::uuid, v_operation_id);
  v_actor_id uuid := public.app_current_user_id();
  v_claim jsonb;
  v_hash text := encode(extensions.digest(convert_to(payload::text, 'UTF8'), 'sha256'), 'hex');
  v_folio_result jsonb;
  v_folio_charge_id uuid;
  v_response jsonb;
begin
  if v_contract is distinct from 2 or v_operation_id is null or v_lodge_id is null or v_device_id is null then
    return jsonb_build_object('success', false, 'code', 'OPERATION_ENVELOPE_INVALID', 'retryable', false);
  end if;
  if v_outlet_id is null then
    return jsonb_build_object('success', false, 'code', 'OUTLET_REQUIRED', 'retryable', false);
  end if;
  perform public.app_reject_pwa_financial_mutation();
  perform public.app_require_capability(v_lodge_id, 'pos.sale', v_outlet_id, v_device_id);

  v_claim := public.app_claim_operation_receipt(v_operation_id, v_lodge_id, v_device_id, 'pos_sale_v2', v_hash);
  if coalesce((v_claim->>'replay')::boolean, false) then
    return coalesce(v_claim->'response', v_claim);
  end if;
  if coalesce((v_claim->>'claimed')::boolean, false) = false then
    return jsonb_build_object('success', false, 'code', 'OPERATION_IN_PROGRESS', 'retryable', true, 'operation_id', v_operation_id);
  end if;

  if jsonb_typeof(v_items) <> 'array' or jsonb_array_length(v_items) = 0 then
    raise exception using errcode = '22023', message = 'A POS sale must contain at least one item.';
  end if;

  for v_item in select value from jsonb_array_elements(v_items)
  loop
    v_seen := v_seen + 1;
    v_menu_id := nullif(v_item->>'menu_item_id', '')::uuid;
    v_history_id := nullif(v_item->>'price_history_id', '')::uuid;
    v_qty := nullif(v_item->>'quantity', '')::numeric;
    if v_menu_id is null or v_qty is null or v_qty <= 0 or v_qty <> trunc(v_qty) then
      raise exception using errcode = '22023', message = 'POS sale quantities must be positive whole numbers and menu items are required.';
    end if;
    select * into v_menu from public.pos_menu_items pmi
     where pmi.id = v_menu_id and pmi.lodge_id = v_lodge_id and pmi.is_available = true
       and (pmi.outlet_id = v_outlet_id or pmi.outlet_id is null)
     for share;
    if v_menu.id is null then raise exception using errcode = '42501', message = 'Menu item is unavailable for this lodge or outlet.'; end if;
    if v_history_id is null then
      raise exception using errcode = '40901', message = 'Trusted price history is required for this sale.';
    end if;
    select * into v_history from public.pos_menu_price_history ph
     where ph.id = v_history_id and ph.lodge_id = v_lodge_id and ph.menu_item_id = v_menu_id
       and (ph.outlet_id = v_outlet_id or ph.outlet_id is null)
       ;
    if v_history.id is null then raise exception using errcode = '40901', message = 'Trusted price version is unavailable; sale requires review.'; end if;
    v_price := v_history.unit_price;
    v_inventory_id := coalesce(nullif(v_item->>'inventory_item_id', '')::uuid, v_menu.inventory_item_id);
    if v_inventory_id is not null then
      if v_menu.inventory_item_id is not null and v_inventory_id <> v_menu.inventory_item_id then
        raise exception using errcode = '42501', message = 'Inventory link does not match the menu catalog.';
      end if;
      select * into v_inventory from public.inventory_items ii where ii.id = v_inventory_id and ii.lodge_id = v_lodge_id for update;
      if v_inventory.id is null then raise exception using errcode = '42501', message = 'Inventory item is outside the lodge scope.'; end if;
      v_depletion := greatest(coalesce(v_menu.depletion_qty, 1), 0.0001);
      if coalesce(v_inventory.current_stock, 0) < v_depletion * v_qty then
        raise exception using errcode = '40902', message = 'Insufficient inventory for this sale.';
      end if;
    else
      v_depletion := 1;
    end if;
    v_modifier_total := 0;
    v_line_gross := round(v_price * v_qty, 2);
    v_gross := v_gross + v_line_gross;
    v_server_items := v_server_items || jsonb_build_array(jsonb_build_object(
      'menu_item_id', v_menu.id, 'inventory_item_id', v_inventory_id, 'depletion_qty', v_depletion,
      'item_name', v_menu.name, 'category', v_menu.category, 'quantity', v_qty,
      'unit_price', v_price, 'gross_subtotal', v_line_gross, 'modifier_subtotal', v_modifier_total,
      'price_history_id', v_history.id, 'catalog_version', v_history.catalog_version,
      'modifiers', coalesce(v_item->'modifiers', '[]'::jsonb), 'item_notes', v_item->>'item_notes'
    ));
  end loop;

  v_discount := greatest(0, least(v_gross, round(coalesce((v_body->'discount'->>'amount')::numeric, 0), 2)));
  if v_discount > 0 then perform public.app_require_capability(v_lodge_id, 'pos.discount', v_outlet_id, v_device_id); end if;
  select * into v_tax_profile from public.pos_tax_profiles tp
   where tp.lodge_id = v_lodge_id and tp.active = true and (tp.outlet_id = v_outlet_id or tp.outlet_id is null)
     and tp.effective_from <= now() and (tp.effective_to is null or tp.effective_to > now())
   order by (tp.outlet_id is not null) desc, tp.effective_from desc limit 1;
  v_tax_rate := coalesce(v_tax_profile.rate, 0);
  v_tax_amount := round(greatest(0, v_gross - v_discount) * v_tax_rate / 100, 2);
  v_tip := greatest(0, round(coalesce((v_body->>'tip_hint')::numeric, 0), 2));
  v_total := round(greatest(0, v_gross - v_discount) + v_tax_amount + v_tip, 2);

  if v_payment_method = 'folio' then
    select * into v_booking from public.bookings b where b.id = nullif(v_body->>'booking_id', '')::uuid and b.lodge_id = v_lodge_id
      and b.status in ('confirmed', 'checked_in') for update;
    if v_booking.id is null then raise exception using errcode = '42501', message = 'Active booking is required for a folio sale.'; end if;
    v_folio_result := public.add_booking_charge(v_booking.id, v_lodge_id, 'POS sale', 'pos', 1, v_total, v_outlet_id, null);
    if coalesce((v_folio_result->>'success')::boolean, false) = false then raise exception using errcode = '40001', message = coalesce(v_folio_result->>'error', 'Folio charge failed.'); end if;
    v_folio_charge_id := nullif(v_folio_result->>'id', '')::uuid;
  else
    for v_tender in select value from jsonb_array_elements(v_tenders)
    loop
      if lower(coalesce(v_tender->>'method', '')) not in ('cash', 'card', 'mobile_money', 'bank_transfer') then
        raise exception using errcode = '22023', message = 'Tender method is not allowed.';
      end if;
      if coalesce((v_tender->>'amount')::numeric, 0) <= 0 then raise exception using errcode = '22023', message = 'Tender amount must be positive.'; end if;
      v_tender_total := v_tender_total + round((v_tender->>'amount')::numeric, 2);
    end loop;
    if round(v_tender_total, 2) <> v_total then raise exception using errcode = '22023', message = 'Tender total does not match the authoritative sale total.'; end if;
  end if;

  v_receipt_year := extract(year from now())::integer;
  insert into public.pos_receipt_sequences(lodge_id, year, last_number) values (v_lodge_id, v_receipt_year, 0)
    on conflict (lodge_id, year) do nothing;
  select last_number into v_receipt_seq from public.pos_receipt_sequences where lodge_id = v_lodge_id and year = v_receipt_year for update;
  update public.pos_receipt_sequences set last_number = v_receipt_seq + 1 where lodge_id = v_lodge_id and year = v_receipt_year;
  v_receipt := 'R-' || v_receipt_year::text || '-' || lpad((v_receipt_seq + 1)::text, 6, '0');

  insert into public.pos_orders(
    id, lodge_id, room_id, booking_id, walk_in_name, status, total, gross_total, discount_total, tax_rate, tax_total,
    tip_total, payment_method, payment_breakdown, notes, created_at, completed_at, outlet_id, folio_charge_id,
    receipt_number, shift_id, operation_id, device_id, operation_contract_version, cashier_actor_id, accepted_at,
    authoritative_total, authoritative_gross_total, authoritative_discount_total, authoritative_tax_total, authoritative_tip_total,
    tax_profile_id, reconciliation_state
  ) values (
    v_order_id, v_lodge_id, nullif(v_body->>'room_id', '')::uuid, nullif(v_body->>'booking_id', '')::uuid,
    nullif(v_body->>'walk_in_name', ''), 'completed', v_total, v_gross, v_discount, v_tax_rate, v_tax_amount, v_tip,
    v_payment_method, v_tenders, nullif(v_body->>'notes', ''), now(), now(), v_outlet_id, v_folio_charge_id,
    v_receipt, nullif(v_body->>'shift_id', '')::uuid, v_operation_id, v_device_id, 2, v_actor_id, now(), v_total, v_gross, v_discount, v_tax_amount, v_tip,
    v_tax_profile.id, 'authoritative'
  );

  for v_line in select value from jsonb_array_elements(v_server_items)
  loop
    insert into public.pos_order_items(
      lodge_id, order_id, menu_item_id, item_name, quantity, unit_price, subtotal, inventory_item_id, depletion_qty,
      category, modifiers, item_notes, price_history_id, catalog_version, gross_subtotal, modifier_subtotal,
      discount_allocated, tax_allocated, net_subtotal
    ) values (
      v_lodge_id, v_order_id, (v_line->>'menu_item_id')::uuid, v_line->>'item_name', (v_line->>'quantity')::integer,
      (v_line->>'unit_price')::numeric, (v_line->>'gross_subtotal')::numeric, nullif(v_line->>'inventory_item_id', '')::uuid,
      (v_line->>'depletion_qty')::numeric, v_line->>'category', coalesce(v_line->'modifiers', '[]'::jsonb), v_line->>'item_notes',
      (v_line->>'price_history_id')::uuid, v_line->>'catalog_version', (v_line->>'gross_subtotal')::numeric,
      (v_line->>'modifier_subtotal')::numeric, round(v_discount * ((v_line->>'gross_subtotal')::numeric / nullif(v_gross, 0)), 2),
      round(v_tax_amount * ((v_line->>'gross_subtotal')::numeric / nullif(v_gross, 0)), 2),
      round((v_line->>'gross_subtotal')::numeric - v_discount * ((v_line->>'gross_subtotal')::numeric / nullif(v_gross, 0)), 2)
    );
    if nullif(v_line->>'inventory_item_id', '') is not null then
      update public.inventory_items set current_stock = current_stock - ((v_line->>'depletion_qty')::numeric * (v_line->>'quantity')::numeric)
       where id = (v_line->>'inventory_item_id')::uuid and lodge_id = v_lodge_id;
      insert into public.inventory_movements(lodge_id, item_id, movement_type, quantity, unit_cost, total_cost, notes, reference_type, reference_id, source, created_by)
      select v_lodge_id, (v_line->>'inventory_item_id')::uuid, 'use', -((v_line->>'depletion_qty')::numeric * (v_line->>'quantity')::numeric),
        coalesce(ii.latest_unit_cost, 0), -((v_line->>'depletion_qty')::numeric * (v_line->>'quantity')::numeric) * coalesce(ii.latest_unit_cost, 0),
        'POS sale v2', 'pos_order', v_order_id, 'pos_sale_v2', v_actor_id
       from public.inventory_items ii where ii.id = (v_line->>'inventory_item_id')::uuid and ii.lodge_id = v_lodge_id;
    end if;
  end loop;

  v_response := jsonb_build_object(
    'success', true, 'operation_id', v_operation_id, 'entity_id', v_order_id, 'id', v_order_id,
    'total', v_total, 'receipt_number', v_receipt, 'accepted_at', now(), 'idempotent', false,
    'authoritative_totals', jsonb_build_object('gross_total', v_gross, 'discount_total', v_discount, 'tax_total', v_tax_amount, 'tip_total', v_tip, 'total', v_total),
    'folio_charge_id', v_folio_charge_id
  );
  perform public.app_record_operation_receipt(v_operation_id, v_lodge_id, v_device_id, 'pos_sale_v2', v_order_id, v_hash, v_response);
  perform public.app_append_audit_event(v_lodge_id, 'pos_sale_v2_completed', 'pos_order', v_order_id, v_operation_id, v_response);
  return v_response;
exception
  when others then
    -- The surrounding transaction rolls back order, stock, folio, receipt sequence, and claim.
    raise;
end;
$$;

revoke all on function public.create_pos_order_v2(jsonb) from public;
grant execute on function public.create_pos_order_v2(jsonb) to anon, authenticated, service_role;
