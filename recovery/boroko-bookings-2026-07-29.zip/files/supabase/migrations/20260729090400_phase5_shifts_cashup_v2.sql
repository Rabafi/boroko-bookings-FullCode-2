-- Phase 5: server-authoritative POS shifts and cash-up.
--
-- Shift opening and closing are financial operations.  The desktop may keep a
-- provisional local copy while offline, but only these RPCs can create or seal
-- a shift.  Expected tenders are rebuilt from accepted sale/return/void rows;
-- client supplied expected totals are deliberately ignored.

alter table public.pos_shifts
  add column if not exists operation_id uuid,
  add column if not exists device_id text,
  add column if not exists operation_contract_version integer,
  add column if not exists cashier_actor_id uuid,
  add column if not exists close_operation_id uuid,
  add column if not exists close_boundary_at timestamptz,
  add column if not exists sealed_at timestamptz,
  add column if not exists expected_by_method jsonb not null default '{}'::jsonb,
  add column if not exists counted_by_method jsonb not null default '{}'::jsonb,
  add column if not exists variance_by_method jsonb not null default '{}'::jsonb,
  add column if not exists expected_total numeric not null default 0,
  add column if not exists counted_total numeric not null default 0,
  add column if not exists variance_total numeric not null default 0,
  add column if not exists void_total numeric not null default 0,
  add column if not exists reconciliation_state text not null default 'authoritative',
  add column if not exists updated_at timestamptz not null default now();

alter table public.pos_cashup_sessions
  add column if not exists shift_id uuid references public.pos_shifts(id) on delete restrict,
  add column if not exists operation_id uuid,
  add column if not exists device_id text,
  add column if not exists operation_contract_version integer,
  add column if not exists close_boundary_at timestamptz,
  add column if not exists sealed_at timestamptz,
  add column if not exists status text not null default 'sealed',
  add column if not exists expected_total numeric not null default 0,
  add column if not exists counted_total numeric not null default 0,
  add column if not exists variance_total numeric not null default 0,
  add column if not exists void_total numeric not null default 0;

create unique index if not exists pos_shifts_open_identity_uidx
  on public.pos_shifts (lodge_id, outlet_id, cashier_actor_id, device_id)
  where status in ('open', 'closing');
create unique index if not exists pos_shifts_open_operation_uidx
  on public.pos_shifts (operation_id) where operation_id is not null;
create unique index if not exists pos_shifts_close_operation_uidx
  on public.pos_shifts (close_operation_id) where close_operation_id is not null;
create unique index if not exists pos_cashup_sessions_shift_uidx
  on public.pos_cashup_sessions (shift_id) where shift_id is not null;
create unique index if not exists pos_cashup_sessions_operation_uidx
  on public.pos_cashup_sessions (operation_id) where operation_id is not null;

create index if not exists pos_orders_shift_authoritative_idx
  on public.pos_orders (lodge_id, shift_id, accepted_at, created_at);
create index if not exists pos_returns_shift_authoritative_idx
  on public.pos_returns (lodge_id, original_order_id, accepted_at, created_at);
create index if not exists pos_voids_shift_authoritative_idx
  on public.pos_voids (lodge_id, order_id, accepted_at, created_at);

-- A sale that names a sealed shift must wait for the close transaction and is
-- rejected after the close boundary.  The Phase 2 sale RPC supplies shift_id;
-- this trigger also protects direct/legacy callers that happen to provide it.
create or replace function public.pos_order_shift_guard_v2()
returns trigger
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_status text;
begin
  if new.shift_id is null then return new; end if;
  select status into v_status from public.pos_shifts
   where id = new.shift_id and lodge_id = new.lodge_id
   for update;
  if not found then
    raise exception 'The POS shift is outside the lodge scope.' using errcode = '42501';
  end if;
  if v_status not in ('open', 'closing') then
    raise exception 'The POS shift is sealed and cannot accept a new sale.' using errcode = '40901';
  end if;
  return new;
end;
$$;

drop trigger if exists pos_orders_shift_guard_v2 on public.pos_orders;
create trigger pos_orders_shift_guard_v2
  before insert or update of shift_id on public.pos_orders
  for each row execute function public.pos_order_shift_guard_v2();

create or replace function public._pos_shift_authoritative_totals_v2(
  p_shift_id uuid,
  p_boundary timestamptz
)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_shift public.pos_shifts%rowtype;
  v_cash numeric := 0;
  v_card numeric := 0;
  v_mobile numeric := 0;
  v_bank numeric := 0;
  v_folio numeric := 0;
  v_orders integer := 0;
  v_voids integer := 0;
  v_returns integer := 0;
  v_pending integer := 0;
  v_gross numeric := 0;
  v_void_total numeric := 0;
  v_returns_total numeric := 0;
  v_expected jsonb;
begin
  select * into v_shift from public.pos_shifts where id = p_shift_id;
  if v_shift.id is null then
    raise exception 'POS shift not found.' using errcode = '42501';
  end if;

  -- The payment breakdown is an authoritative server row written by the sale
  -- RPC.  Legacy rows with an empty breakdown are represented by their single
  -- payment_method/total so that migration does not lose historical cash.
  with sales as (
    select po.id,
           po.total,
           po.gross_total,
           lower(coalesce(po.payment_method, 'cash')) as fallback_method,
           case when jsonb_typeof(coalesce(po.payment_breakdown, '[]'::jsonb)) = 'array'
                     and jsonb_array_length(coalesce(po.payment_breakdown, '[]'::jsonb)) > 0
                then po.payment_breakdown
                else jsonb_build_array(jsonb_build_object('method', lower(coalesce(po.payment_method, 'cash')), 'amount', po.total))
           end as breakdown,
           exists (
             select 1 from public.pos_voids pv
              where pv.order_id = po.id and pv.lodge_id = v_shift.lodge_id
                and pv.status = 'accepted'
                and coalesce(pv.accepted_at, pv.created_at) >= v_shift.opened_at
                and coalesce(pv.accepted_at, pv.created_at) < p_boundary
           ) as was_voided
      from public.pos_orders po
     where po.lodge_id = v_shift.lodge_id
       and po.outlet_id is not distinct from v_shift.outlet_id
       and po.shift_id = v_shift.id
       and lower(coalesce(po.status, '')) in ('completed', 'settled')
       and coalesce(po.accepted_at, po.completed_at, po.created_at) >= v_shift.opened_at
       and coalesce(po.accepted_at, po.completed_at, po.created_at) < p_boundary
  ), sale_tenders as (
    select lower(nullif(btrim(t.value->>'method'), '')) as method,
           coalesce(nullif(t.value->>'amount', '')::numeric, 0) * case when s.was_voided then -1 else 1 end as amount
      from sales s cross join lateral jsonb_array_elements(s.breakdown) t(value)
     where lower(nullif(btrim(t.value->>'method'), '')) in ('cash', 'card', 'mobile_money', 'bank_transfer', 'folio')
  )
  select coalesce(sum(case when method = 'cash' then amount end), 0),
         coalesce(sum(case when method = 'card' then amount end), 0),
         coalesce(sum(case when method = 'mobile_money' then amount end), 0),
         coalesce(sum(case when method = 'bank_transfer' then amount end), 0),
         coalesce(sum(case when method = 'folio' then amount end), 0),
         (select count(*) from sales),
         coalesce((select sum(greatest(0, gross_total)) from sales), 0),
         coalesce((select sum(case when was_voided then greatest(0, total) else 0 end) from sales), 0)
    into v_cash, v_card, v_mobile, v_bank, v_folio, v_orders, v_gross, v_void_total;

  -- Only recorded refund tenders leave the drawer/card settlement.  A
  -- pending external refund is surfaced separately and never silently
  -- subtracted from the authoritative expected tender.
  with returns as (
    select pr.id, pr.net_total,
           case when pr.status = 'pending_external_refund' then 1 else 0 end as is_pending
      from public.pos_returns pr
      join public.pos_orders po on po.id = pr.original_order_id and po.lodge_id = v_shift.lodge_id
     where pr.lodge_id = v_shift.lodge_id
       and po.outlet_id is not distinct from v_shift.outlet_id
       and po.shift_id = v_shift.id
       and pr.status in ('accepted', 'pending_external_refund')
       and coalesce(pr.accepted_at, pr.created_at) >= v_shift.opened_at
       and coalesce(pr.accepted_at, pr.created_at) < p_boundary
  ), return_tenders as (
    select lower(nullif(btrim(rt.method), '')) as method, rt.amount, r.is_pending
      from returns r join public.pos_return_tenders rt on rt.return_id = r.id
     where rt.status = 'recorded'
  )
  select v_cash - coalesce(sum(case when method = 'cash' then amount end), 0),
         v_card - coalesce(sum(case when method = 'card' then amount end), 0),
         v_mobile - coalesce(sum(case when method = 'mobile_money' then amount end), 0),
         v_bank - coalesce(sum(case when method = 'bank_transfer' then amount end), 0),
         coalesce((select count(*) from returns), 0),
         coalesce((select count(*) from returns where is_pending = 1), 0),
         coalesce((select sum(net_total) from returns), 0)
    into v_cash, v_card, v_mobile, v_bank, v_returns, v_pending, v_returns_total
    from return_tenders;

  select count(*) into v_voids
    from public.pos_voids pv
    join public.pos_orders po on po.id = pv.order_id and po.lodge_id = v_shift.lodge_id
   where pv.lodge_id = v_shift.lodge_id and po.shift_id = v_shift.id
     and pv.status = 'accepted'
     and coalesce(pv.accepted_at, pv.created_at) >= v_shift.opened_at
     and coalesce(pv.accepted_at, pv.created_at) < p_boundary;

  v_cash := round(coalesce(v_cash, 0) + coalesce(v_shift.opening_float, 0), 2);
  v_card := round(coalesce(v_card, 0), 2);
  v_mobile := round(coalesce(v_mobile, 0), 2);
  v_bank := round(coalesce(v_bank, 0), 2);
  v_folio := round(coalesce(v_folio, 0), 2);
  v_expected := jsonb_build_object(
    'cash', v_cash,
    'card', v_card,
    'mobile_money', v_mobile,
    'bank_transfer', v_bank,
    'folio', v_folio,
    'physical_total', round(v_cash + v_card + v_mobile + v_bank, 2)
  );
  return jsonb_build_object(
    'expected_by_method', v_expected,
    'orders_count', v_orders,
    'void_count', v_voids,
    'returns_count', v_returns,
    'pending_count', v_pending,
    'gross_sales', round(coalesce(v_gross, 0), 2),
    'void_total', round(coalesce(v_void_total, 0), 2),
    'returns_total', round(coalesce(v_returns_total, 0), 2),
    'net_sales', round(coalesce(v_gross, 0) - coalesce(v_void_total, 0) - coalesce(v_returns_total, 0), 2)
  );
end;
$$;

create or replace function public._pos_shift_sealed_guard_v2()
returns trigger
language plpgsql
security definer
set search_path to 'public'
as $$
begin
  if old.status = 'sealed' and to_jsonb(old) is distinct from to_jsonb(new) then
    raise exception 'Sealed POS shifts and cash-ups are immutable.' using errcode = '55000';
  end if;
  return new;
end;
$$;

drop trigger if exists pos_shifts_sealed_guard_v2 on public.pos_shifts;
create trigger pos_shifts_sealed_guard_v2
  before update on public.pos_shifts
  for each row execute function public._pos_shift_sealed_guard_v2();
drop trigger if exists pos_cashup_sessions_sealed_guard_v2 on public.pos_cashup_sessions;
create trigger pos_cashup_sessions_sealed_guard_v2
  before update on public.pos_cashup_sessions
  for each row execute function public._pos_shift_sealed_guard_v2();

create or replace function public.open_pos_shift_v2(payload jsonb)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_contract integer := nullif(payload->>'contract_version', '')::integer;
  v_operation_id uuid := nullif(payload->>'operation_id', '')::uuid;
  v_device_id text := nullif(btrim(payload->>'device_id'), '');
  v_lodge_id uuid := nullif(payload->>'lodge_id', '')::uuid;
  v_outlet_id uuid := nullif(payload->>'outlet_id', '')::uuid;
  v_body jsonb := coalesce(payload->'payload', '{}'::jsonb);
  v_shift_id uuid := coalesce(nullif(v_body->>'id', '')::uuid, v_operation_id);
  v_opening_float numeric := round(coalesce(nullif(v_body->>'opening_float', '')::numeric, 0), 2);
  v_actor_id uuid := public.app_current_user_id();
  v_actor_name text;
  v_existing public.pos_shifts%rowtype;
  v_shift public.pos_shifts%rowtype;
  v_claim jsonb;
  v_hash text := encode(extensions.digest(convert_to(payload::text, 'UTF8'), 'sha256'), 'hex');
  v_response jsonb;
begin
  if v_contract is distinct from 2 or v_operation_id is null or v_lodge_id is null or v_outlet_id is null or v_device_id is null then
    return jsonb_build_object('success', false, 'code', 'OPERATION_ENVELOPE_INVALID', 'retryable', false);
  end if;
  if v_opening_float < 0 then
    return jsonb_build_object('success', false, 'code', 'OPENING_FLOAT_INVALID', 'retryable', false);
  end if;
  perform public.app_reject_pwa_financial_mutation();
  -- Cashiers already hold the server-derived pos.sale capability; opening a
  -- drawer is part of their normal offline POS workflow.
  perform public.app_require_capability(v_lodge_id, 'pos.sale', v_outlet_id, v_device_id);
  v_claim := public.app_claim_operation_receipt(v_operation_id, v_lodge_id, v_device_id, 'pos_shift_open_v2', v_hash);
  if coalesce((v_claim->>'replay')::boolean, false) then return coalesce(v_claim->'response', v_claim); end if;
  if not coalesce((v_claim->>'claimed')::boolean, false) then
    return jsonb_build_object('success', false, 'code', 'OPERATION_IN_PROGRESS', 'retryable', true, 'operation_id', v_operation_id);
  end if;

  select u.name into v_actor_name from public.users u where u.id = v_actor_id and u.lodge_id = v_lodge_id;
  select * into v_existing
    from public.pos_shifts
   where lodge_id = v_lodge_id and outlet_id = v_outlet_id
     and cashier_actor_id = v_actor_id and device_id = v_device_id
     and status in ('open', 'closing')
   for update;
  if v_existing.id is not null then
    if v_existing.operation_id = v_operation_id then
      v_response := jsonb_build_object('success', true, 'idempotent', true, 'already_open', true,
        'operation_id', v_operation_id, 'entity_id', v_existing.id, 'shift_id', v_existing.id,
        'shift', to_jsonb(v_existing));
    else
      v_response := jsonb_build_object('success', false, 'code', 'ACTIVE_SHIFT_EXISTS', 'retryable', false,
        'already_open', true, 'shift_id', v_existing.id);
    end if;
    perform public.app_record_operation_receipt(v_operation_id, v_lodge_id, v_device_id, 'pos_shift_open_v2', v_existing.id, v_hash, v_response);
    return v_response;
  end if;

  insert into public.pos_shifts(
    id, lodge_id, outlet_id, cashier_id, cashier_name, opening_float, status,
    opened_at, notes, operation_id, device_id, operation_contract_version,
    cashier_actor_id, reconciliation_state, updated_at
  ) values (
    v_shift_id, v_lodge_id, v_outlet_id, v_actor_id, v_actor_name, v_opening_float, 'open',
    now(), nullif(v_body->>'notes', ''), v_operation_id, v_device_id, 2,
    v_actor_id, 'authoritative', now()
  ) returning * into v_shift;

  v_response := jsonb_build_object('success', true, 'idempotent', false, 'operation_id', v_operation_id,
    'entity_id', v_shift.id, 'shift_id', v_shift.id, 'accepted_at', v_shift.opened_at,
    'opening_float', v_shift.opening_float, 'shift', to_jsonb(v_shift));
  perform public.app_record_operation_receipt(v_operation_id, v_lodge_id, v_device_id, 'pos_shift_open_v2', v_shift.id, v_hash, v_response);
  perform public.app_append_audit_event(v_lodge_id, 'pos_shift_opened_v2', 'pos_shift', v_shift.id, v_operation_id, v_response);
  return v_response;
exception
  when unique_violation then
    -- A concurrent opener may win the partial identity index.  Return a
    -- deterministic conflict instead of allowing a second active drawer.
    select * into v_existing from public.pos_shifts
     where lodge_id = v_lodge_id and outlet_id = v_outlet_id
       and cashier_actor_id = v_actor_id and device_id = v_device_id
       and status in ('open', 'closing') limit 1;
    if v_existing.id is not null then
      v_response := jsonb_build_object('success', false, 'code', 'ACTIVE_SHIFT_EXISTS', 'retryable', false,
        'already_open', true, 'shift_id', v_existing.id);
      perform public.app_record_operation_receipt(v_operation_id, v_lodge_id, v_device_id, 'pos_shift_open_v2', v_existing.id, v_hash, v_response);
      return v_response;
    end if;
    raise;
end;
$$;

create or replace function public.close_pos_shift_and_cashup_v2(payload jsonb)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_contract integer := nullif(payload->>'contract_version', '')::integer;
  v_operation_id uuid := nullif(payload->>'operation_id', '')::uuid;
  v_device_id text := nullif(btrim(payload->>'device_id'), '');
  v_lodge_id uuid := nullif(payload->>'lodge_id', '')::uuid;
  v_outlet_id uuid := nullif(payload->>'outlet_id', '')::uuid;
  v_body jsonb := coalesce(payload->'payload', '{}'::jsonb);
  v_shift_id uuid := nullif(v_body->>'shift_id', '')::uuid;
  v_counted jsonb := coalesce(v_body->'counted_by_method', '{}'::jsonb);
  v_notes text := nullif(v_body->>'notes', '');
  v_shift public.pos_shifts%rowtype;
  v_cashup public.pos_cashup_sessions%rowtype;
  v_claim jsonb;
  v_totals jsonb;
  v_expected jsonb;
  v_counted_clean jsonb;
  v_variance jsonb;
  v_expected_cash numeric;
  v_expected_card numeric;
  v_expected_mobile numeric;
  v_expected_bank numeric;
  v_counted_cash numeric;
  v_counted_card numeric;
  v_counted_mobile numeric;
  v_counted_bank numeric;
  v_expected_total numeric;
  v_counted_total numeric;
  v_variance_total numeric;
  v_boundary timestamptz := clock_timestamp();
  v_actor_id uuid := public.app_current_user_id();
  v_hash text := encode(extensions.digest(convert_to(payload::text, 'UTF8'), 'sha256'), 'hex');
  v_response jsonb;
begin
  if v_contract is distinct from 2 or v_operation_id is null or v_lodge_id is null or v_outlet_id is null or v_device_id is null or v_shift_id is null then
    return jsonb_build_object('success', false, 'code', 'OPERATION_ENVELOPE_INVALID', 'retryable', false);
  end if;
  perform public.app_reject_pwa_financial_mutation();
  -- Closing remains an authoritative POS operation.  Site policy can restrict
  -- it further with a capability override without changing the RPC contract.
  perform public.app_require_capability(v_lodge_id, 'pos.sale', v_outlet_id, v_device_id);
  v_claim := public.app_claim_operation_receipt(v_operation_id, v_lodge_id, v_device_id, 'pos_shift_close_v2', v_hash);
  if coalesce((v_claim->>'replay')::boolean, false) then return coalesce(v_claim->'response', v_claim); end if;
  if not coalesce((v_claim->>'claimed')::boolean, false) then
    return jsonb_build_object('success', false, 'code', 'OPERATION_IN_PROGRESS', 'retryable', true, 'operation_id', v_operation_id);
  end if;

  select * into v_shift from public.pos_shifts where id = v_shift_id and lodge_id = v_lodge_id and outlet_id = v_outlet_id for update;
  if v_shift.id is null then raise exception 'POS shift is outside the lodge or outlet scope.' using errcode = '42501'; end if;
  if v_shift.status = 'sealed' then
    v_response := jsonb_build_object('success', false, 'code', 'SHIFT_ALREADY_SEALED', 'retryable', false,
      'shift_id', v_shift.id, 'cashup_id', (select id from public.pos_cashup_sessions where shift_id = v_shift.id));
    perform public.app_record_operation_receipt(v_operation_id, v_lodge_id, v_device_id, 'pos_shift_close_v2', v_shift.id, v_hash, v_response);
    return v_response;
  end if;
  if v_shift.status not in ('open', 'closing') then raise exception 'POS shift is not open.' using errcode = '40901'; end if;

  v_totals := public._pos_shift_authoritative_totals_v2(v_shift.id, v_boundary);
  v_expected := coalesce(v_totals->'expected_by_method', '{}'::jsonb);
  v_expected_cash := round(coalesce((v_expected->>'cash')::numeric, 0), 2);
  v_expected_card := round(coalesce((v_expected->>'card')::numeric, 0), 2);
  v_expected_mobile := round(coalesce((v_expected->>'mobile_money')::numeric, 0), 2);
  v_expected_bank := round(coalesce((v_expected->>'bank_transfer')::numeric, 0), 2);
  v_counted_cash := round(coalesce(nullif(v_counted->>'cash', '')::numeric, 0), 2);
  v_counted_card := round(coalesce(nullif(v_counted->>'card', '')::numeric, 0), 2);
  v_counted_mobile := round(coalesce(nullif(v_counted->>'mobile_money', '')::numeric, 0), 2);
  v_counted_bank := round(coalesce(nullif(v_counted->>'bank_transfer', '')::numeric, 0), 2);
  if least(v_counted_cash, v_counted_card, v_counted_mobile, v_counted_bank) < 0 then
    raise exception 'Counted tenders cannot be negative.' using errcode = '22023';
  end if;
  v_counted_clean := jsonb_build_object('cash', v_counted_cash, 'card', v_counted_card,
    'mobile_money', v_counted_mobile, 'bank_transfer', v_counted_bank);
  v_variance := jsonb_build_object(
    'cash', round(v_counted_cash - v_expected_cash, 2),
    'card', round(v_counted_card - v_expected_card, 2),
    'mobile_money', round(v_counted_mobile - v_expected_mobile, 2),
    'bank_transfer', round(v_counted_bank - v_expected_bank, 2)
  );
  v_expected_total := round(v_expected_cash + v_expected_card + v_expected_mobile + v_expected_bank, 2);
  v_counted_total := round(v_counted_cash + v_counted_card + v_counted_mobile + v_counted_bank, 2);
  v_variance_total := round(v_counted_total - v_expected_total, 2);

  insert into public.pos_cashup_sessions(
    lodge_id, date, outlet_id, shift_id, opening_float, expected_cash_drawer,
    expected_by_method, counted_by_method, variance_by_method, cash_over_short,
    orders_count, void_count, pending_count, gross_sales, returns_total, net_sales,
    notes, created_by, cashier_id, cashier_name, created_at, operation_id, device_id,
    operation_contract_version, close_boundary_at, sealed_at, status, expected_total,
    counted_total, variance_total, void_total
  ) values (
    v_lodge_id, current_date, v_outlet_id, v_shift.id, v_shift.opening_float,
    v_expected_cash, v_expected, v_counted_clean, v_variance, (v_variance->>'cash')::numeric,
    coalesce((v_totals->>'orders_count')::integer, 0), coalesce((v_totals->>'void_count')::integer, 0),
    coalesce((v_totals->>'pending_count')::integer, 0), coalesce((v_totals->>'gross_sales')::numeric, 0),
    coalesce((v_totals->>'returns_total')::numeric, 0), coalesce((v_totals->>'net_sales')::numeric, 0),
    v_notes, v_actor_id, v_shift.cashier_id, v_shift.cashier_name, now(), v_operation_id, v_device_id,
    2, v_boundary, v_boundary, 'sealed', v_expected_total, v_counted_total, v_variance_total,
    coalesce((v_totals->>'void_total')::numeric, 0)
  ) returning * into v_cashup;

  update public.pos_shifts
     set status = 'sealed', closed_at = v_boundary, close_notes = v_notes,
         close_operation_id = v_operation_id, close_boundary_at = v_boundary,
         sealed_at = v_boundary, expected_by_method = v_expected,
         counted_by_method = v_counted_clean, variance_by_method = v_variance,
         expected_total = v_expected_total, counted_total = v_counted_total,
         variance_total = v_variance_total,
         void_total = coalesce((v_totals->>'void_total')::numeric, 0),
         reconciliation_state = 'authoritative', updated_at = now()
   where id = v_shift.id and lodge_id = v_lodge_id;

  v_response := jsonb_build_object('success', true, 'idempotent', false, 'operation_id', v_operation_id,
    'entity_id', v_shift.id, 'shift_id', v_shift.id, 'cashup_id', v_cashup.id,
    'accepted_at', v_boundary, 'close_boundary_at', v_boundary, 'sealed_at', v_boundary,
    'expected_by_method', v_expected, 'counted_by_method', v_counted_clean, 'variance_by_method', v_variance,
    'expected_total', v_expected_total, 'counted_total', v_counted_total, 'variance_total', v_variance_total,
    'orders_count', v_totals->'orders_count', 'void_count', v_totals->'void_count',
    'returns_count', v_totals->'returns_count', 'pending_count', v_totals->'pending_count',
    'gross_sales', v_totals->'gross_sales', 'void_total', v_totals->'void_total',
    'returns_total', v_totals->'returns_total', 'net_sales', v_totals->'net_sales');
  perform public.app_record_operation_receipt(v_operation_id, v_lodge_id, v_device_id, 'pos_shift_close_v2', v_shift.id, v_hash, v_response);
  perform public.app_append_audit_event(v_lodge_id, 'pos_shift_closed_v2', 'pos_shift', v_shift.id, v_operation_id, v_response);
  return v_response;
end;
$$;

revoke all on public.pos_shifts, public.pos_cashup_sessions from anon, authenticated;
grant select on public.pos_shifts, public.pos_cashup_sessions to anon, authenticated, service_role;
revoke all on function public.pos_order_shift_guard_v2() from public;
revoke all on function public._pos_shift_sealed_guard_v2() from public;
revoke all on function public._pos_shift_authoritative_totals_v2(uuid, timestamptz) from public;
revoke all on function public.open_pos_shift_v2(jsonb) from public;
revoke all on function public.close_pos_shift_and_cashup_v2(jsonb) from public;
grant execute on function public.open_pos_shift_v2(jsonb), public.close_pos_shift_and_cashup_v2(jsonb) to anon, authenticated, service_role;
