alter table public.inventory_items
  add column if not exists updated_at timestamptz;

update public.inventory_items
   set updated_at = coalesce(updated_at, created_at, now())
 where updated_at is null;

alter table public.inventory_items
  alter column updated_at set default now(),
  alter column updated_at set not null;

create or replace function public.touch_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists inventory_items_touch_updated_at on public.inventory_items;

create trigger inventory_items_touch_updated_at
before update on public.inventory_items
for each row
execute function public.touch_updated_at();

create index if not exists inventory_items_lodge_updated_at_idx
  on public.inventory_items (lodge_id, updated_at desc);

notify pgrst, 'reload schema';
