-- Phase 6: durable kitchen/bar prep tickets and cross-terminal convergence.
--
-- Tickets are an append-only event stream around an immutable order-round
-- snapshot.  The two RPCs below intentionally accept the shared v2 operation
-- envelope (`contract_version`, `operation_id`, `device_id`, `lodge_id`,
-- `outlet_id`, `payload`) so offline replay is idempotent and server time,
-- actor identity, station permissions and outlet scope remain authoritative.

-- Phase 2 stores the submitted modifier/instruction snapshot on order lines.
-- These columns are additive so this migration is safe on installations that
-- already have the newer sale migration applied.
alter table public.pos_order_items
  add column if not exists modifiers jsonb not null default '[]'::jsonb,
  add column if not exists item_notes text;

create table if not exists public.pos_kds_station_mappings (
  id uuid primary key default gen_random_uuid(),
  lodge_id uuid not null,
  outlet_id uuid references public.outlets(id) on delete cascade,
  menu_item_id uuid references public.pos_menu_items(id) on delete cascade,
  station text not null,
  active boolean not null default true,
  priority integer not null default 0,
  created_by uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint pos_kds_station_mapping_station_chk
    check (station in ('kitchen', 'bar'))
);

create unique index if not exists pos_kds_station_mapping_item_uidx
  on public.pos_kds_station_mappings (lodge_id, coalesce(outlet_id, '00000000-0000-0000-0000-000000000000'::uuid), menu_item_id)
  where menu_item_id is not null;
create unique index if not exists pos_kds_station_mapping_default_uidx
  on public.pos_kds_station_mappings (lodge_id, coalesce(outlet_id, '00000000-0000-0000-0000-000000000000'::uuid), priority)
  where menu_item_id is null;
create index if not exists pos_kds_station_mapping_lookup_idx
  on public.pos_kds_station_mappings (lodge_id, outlet_id, menu_item_id, active, priority desc);

create table if not exists public.pos_kds_tickets (
  id uuid primary key,
  lodge_id uuid not null,
  outlet_id uuid references public.outlets(id) on delete set null,
  order_id uuid not null references public.pos_orders(id) on delete cascade,
  check_round_id uuid not null,
  station text not null,
  ticket_key text not null,
  status text not null default 'new',
  version bigint not null default 0,
  last_event_seq bigint not null default 0,
  last_operation_id uuid,
  last_device_id text,
  snapshot_hash text not null,
  item_snapshot jsonb not null default '[]'::jsonb,
  table_name text,
  tab_name text,
  waiter_name text,
  room_id uuid references public.rooms(id) on delete set null,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint pos_kds_ticket_station_chk check (station in ('kitchen', 'bar')),
  constraint pos_kds_ticket_status_chk check (status in ('new', 'preparing', 'ready', 'served', 'cancelled')),
  constraint pos_kds_ticket_key_uk unique (ticket_key)
);

create index if not exists pos_kds_tickets_lodge_station_status_idx
  on public.pos_kds_tickets (lodge_id, station, status, updated_at desc);
create index if not exists pos_kds_tickets_order_idx
  on public.pos_kds_tickets (lodge_id, order_id, check_round_id);

create table if not exists public.pos_kds_ticket_events (
  id uuid primary key default gen_random_uuid(),
  lodge_id uuid not null,
  ticket_id uuid not null references public.pos_kds_tickets(id) on delete cascade,
  operation_id uuid not null,
  device_id text not null,
  event_seq bigint not null,
  from_status text,
  to_status text not null,
  event_type text not null,
  expected_version bigint,
  actor_id uuid,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  constraint pos_kds_ticket_event_status_chk
    check (to_status in ('new', 'preparing', 'ready', 'served', 'cancelled')),
  constraint pos_kds_ticket_event_type_chk
    check (event_type in ('created', 'preparing', 'ready', 'served', 'cancelled')),
  -- A single create operation may materialize both a kitchen and a bar
  -- ticket.  Idempotency is therefore scoped to the ticket plus operation;
  -- the shared app_operation_receipts table still deduplicates the envelope.
  constraint pos_kds_ticket_event_operation_uk unique (ticket_id, operation_id),
  constraint pos_kds_ticket_event_sequence_uk unique (ticket_id, event_seq)
);

create index if not exists pos_kds_ticket_events_ticket_idx
  on public.pos_kds_ticket_events (ticket_id, event_seq);
create index if not exists pos_kds_ticket_events_lodge_created_idx
  on public.pos_kds_ticket_events (lodge_id, created_at desc);

alter table public.pos_kds_station_mappings enable row level security;
alter table public.pos_kds_tickets enable row level security;
alter table public.pos_kds_ticket_events enable row level security;

drop policy if exists pos_kds_station_mappings_lodge_select on public.pos_kds_station_mappings;
create policy pos_kds_station_mappings_lodge_select
  on public.pos_kds_station_mappings for select
  using (public.app_lodge_access(lodge_id));
drop policy if exists pos_kds_tickets_lodge_select on public.pos_kds_tickets;
create policy pos_kds_tickets_lodge_select
  on public.pos_kds_tickets for select
  using (public.app_lodge_access(lodge_id));
drop policy if exists pos_kds_ticket_events_lodge_select on public.pos_kds_ticket_events;
create policy pos_kds_ticket_events_lodge_select
  on public.pos_kds_ticket_events for select
  using (public.app_lodge_access(lodge_id));

revoke all on public.pos_kds_station_mappings, public.pos_kds_tickets, public.pos_kds_ticket_events from anon, authenticated;
grant select on public.pos_kds_station_mappings, public.pos_kds_tickets, public.pos_kds_ticket_events to authenticated;

-- Stable ticket identity: order/check-round plus station.  md5 is available in
-- every supported PostgreSQL installation and its 32 hex characters are a
-- valid UUID representation when cast to uuid.
create or replace function public.pos_kds_ticket_id(
  p_order_id uuid,
  p_check_round_id uuid,
  p_station text
)
returns uuid
language sql
immutable
as $$
  select md5(concat(p_order_id::text, '|', p_check_round_id::text, '|', lower(btrim(p_station))))::uuid;
$$;

create or replace function public.create_pos_tickets_v2(payload jsonb)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_contract integer := coalesce(nullif(payload->>'contract_version', '')::integer, 0);
  v_operation_id uuid := nullif(payload->>'operation_id', '')::uuid;
  v_lodge_id uuid := nullif(payload->>'lodge_id', '')::uuid;
  v_outlet_id uuid := nullif(payload->>'outlet_id', '')::uuid;
  v_device_id text := nullif(btrim(payload->>'device_id'), '');
  v_body jsonb := coalesce(payload->'payload', '{}'::jsonb);
  v_order_id uuid := nullif(v_body->>'order_id', '')::uuid;
  v_round_id uuid := coalesce(
    nullif(v_body->>'check_round_id', '')::uuid,
    nullif(v_body->>'round_id', '')::uuid,
    v_order_id
  );
  v_order public.pos_orders%rowtype;
  v_claim jsonb;
  v_response jsonb;
  v_station text;
  v_ticket_id uuid;
  v_ticket_key text;
  v_snapshot jsonb;
  v_snapshot_hash text;
  v_existing public.pos_kds_tickets%rowtype;
  v_created jsonb := '[]'::jsonb;
  v_created_one jsonb;
  v_request_hash text := md5(payload::text);
  v_session public.app_sessions%rowtype;
begin
  if v_contract <> 2 then
    raise exception 'Unsupported ticket operation contract.' using errcode = '22023';
  end if;
  if v_operation_id is null or v_lodge_id is null or v_device_id is null or v_order_id is null then
    raise exception 'Ticket operation envelope is incomplete.' using errcode = '22023';
  end if;

  -- The manager PWA is read-only for durable KDS mutations.  A desktop app
  -- session (including service-role maintenance) is required.
  v_session := public.app_current_session_row();
  if v_session.id is not null and v_session.session_type = 'pwa' then
    raise exception 'KDS ticket creation is only available in the Front Desk system.' using errcode = '42501';
  end if;

  select * into v_order
    from public.pos_orders
   where id = v_order_id and lodge_id = v_lodge_id
   for share;
  if v_order.id is null then
    raise exception 'The POS order for this ticket round was not found.' using errcode = '23503';
  end if;
  if v_outlet_id is null then v_outlet_id := v_order.outlet_id; end if;

  perform public.app_require_capability(v_lodge_id, 'pos.sale', v_outlet_id, v_device_id);
  v_claim := public.app_claim_operation_receipt(v_operation_id, v_lodge_id, v_device_id, 'pos.ticket.create', v_request_hash);
  if coalesce((v_claim->>'replay')::boolean, false) then
    return coalesce(v_claim->'response', v_claim);
  end if;
  if coalesce((v_claim->>'claimed')::boolean, false) = false then
    return jsonb_build_object('success', false, 'operation_id', v_operation_id,
      'status', 'operation_in_progress', 'retryable', true);
  end if;

  -- One ticket is materialized for each configured station represented in the
  -- order.  Item-specific rules win, then outlet/lodge defaults.  The final
  -- kitchen default is deterministic for legacy menus; operators can replace
  -- it with an explicit mapping without changing ticket identity semantics.
  for v_station in
    select distinct coalesce(
      (select m.station from public.pos_kds_station_mappings m
        where m.lodge_id = v_lodge_id and m.active
          and m.menu_item_id = poi.menu_item_id
          and (m.outlet_id = v_outlet_id or m.outlet_id is null)
        order by case when m.outlet_id = v_outlet_id then 0 else 1 end, m.priority desc, m.updated_at desc
        limit 1),
      (select m.station from public.pos_kds_station_mappings m
        where m.lodge_id = v_lodge_id and m.active and m.menu_item_id is null
          and (m.outlet_id = v_outlet_id or m.outlet_id is null)
        order by case when m.outlet_id = v_outlet_id then 0 else 1 end, m.priority desc, m.updated_at desc
        limit 1),
      'kitchen')
    from public.pos_order_items poi
    where poi.order_id = v_order_id and poi.lodge_id = v_lodge_id
    order by 1
  loop
    select coalesce(jsonb_agg(
      jsonb_build_object(
        'order_item_id', poi.id,
        'menu_item_id', poi.menu_item_id,
        'item_name', poi.item_name,
        'quantity', poi.quantity,
        'unit_price', poi.unit_price,
        'depletion_qty', poi.depletion_qty,
        'modifiers', coalesce(poi.modifiers, '[]'::jsonb),
        'instructions', coalesce(poi.item_notes, '')
      ) order by poi.id
    ), '[]'::jsonb)
    into v_snapshot
    from public.pos_order_items poi
    where poi.order_id = v_order_id and poi.lodge_id = v_lodge_id
      and coalesce(
        (select m.station from public.pos_kds_station_mappings m
          where m.lodge_id = v_lodge_id and m.active
            and m.menu_item_id = poi.menu_item_id
            and (m.outlet_id = v_outlet_id or m.outlet_id is null)
          order by case when m.outlet_id = v_outlet_id then 0 else 1 end, m.priority desc, m.updated_at desc
          limit 1),
        (select m.station from public.pos_kds_station_mappings m
          where m.lodge_id = v_lodge_id and m.active and m.menu_item_id is null
            and (m.outlet_id = v_outlet_id or m.outlet_id is null)
          order by case when m.outlet_id = v_outlet_id then 0 else 1 end, m.priority desc, m.updated_at desc
          limit 1),
        'kitchen') = v_station;

    v_snapshot_hash := md5(v_snapshot::text);
    v_ticket_id := public.pos_kds_ticket_id(v_order_id, v_round_id, v_station);
    v_ticket_key := concat(v_order_id::text, ':', v_round_id::text, ':', v_station);

    select * into v_existing from public.pos_kds_tickets where id = v_ticket_id for update;
    if v_existing.id is not null then
      if v_existing.snapshot_hash <> v_snapshot_hash then
        raise exception 'Ticket snapshot is immutable; submit changed items as a new check round.' using errcode = '40001';
      end if;
      v_created_one := jsonb_build_object(
        'id', v_existing.id, 'ticket_id', v_existing.id, 'station', v_existing.station,
        'status', v_existing.status, 'version', v_existing.version,
        'last_event_seq', v_existing.last_event_seq, 'idempotent', true,
        'item_snapshot', v_existing.item_snapshot);
    else
      insert into public.pos_kds_tickets (
        id, lodge_id, outlet_id, order_id, check_round_id, station, ticket_key,
        status, version, last_event_seq, last_operation_id, last_device_id,
        snapshot_hash, item_snapshot, table_name, tab_name, waiter_name, room_id, notes
      ) values (
        v_ticket_id, v_lodge_id, v_outlet_id, v_order_id, v_round_id, v_station, v_ticket_key,
        'new', 0, 0, v_operation_id, v_device_id,
        v_snapshot_hash, v_snapshot, v_order.table_name, v_order.tab_name, v_order.waiter_name, v_order.room_id, v_order.notes
      );
      insert into public.pos_kds_ticket_events (
        lodge_id, ticket_id, operation_id, device_id, event_seq, from_status,
        to_status, event_type, expected_version, actor_id, payload
      ) values (
        v_lodge_id, v_ticket_id, v_operation_id, v_device_id, 0, null,
        'new', 'created', null, v_session.user_id,
        jsonb_build_object('item_snapshot', v_snapshot, 'check_round_id', v_round_id, 'station', v_station)
      )
      on conflict (ticket_id, operation_id) do nothing;
      v_created_one := jsonb_build_object(
        'id', v_ticket_id, 'ticket_id', v_ticket_id, 'station', v_station,
        'status', 'new', 'version', 0, 'last_event_seq', 0,
        'idempotent', false, 'item_snapshot', v_snapshot);
    end if;
    v_created := v_created || jsonb_build_array(v_created_one);
  end loop;

  v_response := jsonb_build_object(
    'success', true, 'operation_id', v_operation_id, 'order_id', v_order_id,
    'check_round_id', v_round_id, 'tickets', v_created, 'accepted_at', now(),
    'contract_version', 2);
  perform public.app_record_operation_receipt(
    v_operation_id, v_lodge_id, v_device_id, 'pos.ticket.create', null,
    v_request_hash, v_response
  );
  perform public.app_append_audit_event(
    v_lodge_id, 'pos.kds.tickets_created', 'pos_order', v_order_id,
    v_operation_id, jsonb_build_object('check_round_id', v_round_id, 'tickets', v_created)
  );
  return v_response;
end;
$$;

create or replace function public.status_pos_ticket_v2(payload jsonb)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_contract integer := coalesce(nullif(payload->>'contract_version', '')::integer, 0);
  v_operation_id uuid := nullif(payload->>'operation_id', '')::uuid;
  v_lodge_id uuid := nullif(payload->>'lodge_id', '')::uuid;
  v_outlet_id uuid := nullif(payload->>'outlet_id', '')::uuid;
  v_device_id text := nullif(btrim(payload->>'device_id'), '');
  v_body jsonb := coalesce(payload->'payload', '{}'::jsonb);
  v_ticket_id uuid := nullif(v_body->>'ticket_id', '')::uuid;
  v_order_id uuid := nullif(v_body->>'order_id', '')::uuid;
  v_round_id uuid := coalesce(
    nullif(v_body->>'check_round_id', '')::uuid,
    nullif(v_body->>'round_id', '')::uuid
  );
  v_station text := lower(btrim(coalesce(v_body->>'station', '')));
  v_target text := lower(btrim(coalesce(v_body->>'status', v_body->>'next_status', '')));
  v_expected bigint := nullif(v_body->>'expected_version', '')::bigint;
  v_ticket public.pos_kds_tickets%rowtype;
  v_claim jsonb;
  v_response jsonb;
  v_hash text := md5(payload::text);
  v_capability text;
  v_session public.app_sessions%rowtype;
  v_from_status text;
begin
  if v_contract <> 2 then
    raise exception 'Unsupported ticket status contract.' using errcode = '22023';
  end if;
  if v_operation_id is null or v_lodge_id is null or v_device_id is null then
    raise exception 'Ticket status operation envelope is incomplete.' using errcode = '22023';
  end if;
  v_session := public.app_current_session_row();
  if v_session.id is not null and v_session.session_type = 'pwa' then
    raise exception 'KDS ticket status changes are only available in the Front Desk system.' using errcode = '42501';
  end if;
  if v_ticket_id is null then
    if v_order_id is null or v_round_id is null or v_station not in ('kitchen', 'bar') then
      raise exception 'A ticket id or complete order/check-round/station identity is required.' using errcode = '22023';
    end if;
    v_ticket_id := public.pos_kds_ticket_id(v_order_id, v_round_id, v_station);
  end if;
  if v_target not in ('preparing', 'ready', 'served', 'cancelled') then
    raise exception 'Unsupported ticket status transition.' using errcode = '22023';
  end if;

  select * into v_ticket from public.pos_kds_tickets where id = v_ticket_id and lodge_id = v_lodge_id for update;
  if v_ticket.id is null then
    raise exception 'The KDS ticket was not found.' using errcode = '23503';
  end if;
  if v_outlet_id is null then v_outlet_id := v_ticket.outlet_id; end if;

  v_capability := case when v_target = 'cancelled' then 'kds.cancel' else 'kds.update' end;
  perform public.app_require_capability(v_lodge_id, v_capability, v_outlet_id, v_device_id);
  v_claim := public.app_claim_operation_receipt(v_operation_id, v_lodge_id, v_device_id, 'pos.ticket.status', v_hash);
  if coalesce((v_claim->>'replay')::boolean, false) then
    return coalesce(v_claim->'response', v_claim);
  end if;
  if coalesce((v_claim->>'claimed')::boolean, false) = false then
    return jsonb_build_object('success', false, 'operation_id', v_operation_id,
      'status', 'operation_in_progress', 'retryable', true);
  end if;

  if v_expected is not null and v_expected <> v_ticket.version then
    v_response := jsonb_build_object(
      'success', false, 'conflict', true, 'status', 'version_conflict',
      'operation_id', v_operation_id, 'ticket_id', v_ticket.id,
      'current_status', v_ticket.status, 'current_version', v_ticket.version,
      'last_event_seq', v_ticket.last_event_seq);
    perform public.app_record_operation_receipt(v_operation_id, v_lodge_id, v_device_id,
      'pos.ticket.status', v_ticket.id, v_hash, v_response);
    return v_response;
  end if;

  if v_ticket.status = 'cancelled' or v_ticket.status = 'served' then
    raise exception 'A served or cancelled ticket is terminal.' using errcode = '40901';
  end if;
  if v_target = 'preparing' and v_ticket.status <> 'new' then
    raise exception 'Only a new ticket can enter preparing.' using errcode = '40901';
  elsif v_target = 'ready' and v_ticket.status <> 'preparing' then
    raise exception 'Only a preparing ticket can become ready.' using errcode = '40901';
  elsif v_target = 'served' and v_ticket.status <> 'ready' then
    raise exception 'Only a ready ticket can be served.' using errcode = '40901';
  elsif v_target = 'cancelled' and v_ticket.status not in ('new', 'preparing', 'ready') then
    raise exception 'This ticket cannot be cancelled from its current state.' using errcode = '40901';
  end if;

  v_from_status := v_ticket.status;

  update public.pos_kds_tickets
     set status = v_target,
         version = version + 1,
         last_event_seq = last_event_seq + 1,
         last_operation_id = v_operation_id,
         last_device_id = v_device_id,
         updated_at = now()
   where id = v_ticket.id
   returning * into v_ticket;

  insert into public.pos_kds_ticket_events (
    lodge_id, ticket_id, operation_id, device_id, event_seq, from_status,
    to_status, event_type, expected_version, actor_id, payload
  ) values (
    v_lodge_id, v_ticket.id, v_operation_id, v_device_id, v_ticket.last_event_seq,
    v_from_status,
    v_target, v_target, v_expected, v_session.user_id, coalesce(v_body->'metadata', '{}'::jsonb)
  );

  v_response := jsonb_build_object(
    'success', true, 'operation_id', v_operation_id, 'ticket_id', v_ticket.id,
    'status', v_ticket.status, 'version', v_ticket.version,
    'last_event_seq', v_ticket.last_event_seq, 'accepted_at', now(),
    'contract_version', 2);
  perform public.app_record_operation_receipt(v_operation_id, v_lodge_id, v_device_id,
    'pos.ticket.status', v_ticket.id, v_hash, v_response);
  perform public.app_append_audit_event(v_lodge_id, 'pos.kds.ticket_status_changed',
    'pos_kds_ticket', v_ticket.id, v_operation_id,
    jsonb_build_object('from_status', v_from_status, 'to_status', v_target,
      'version', v_ticket.version, 'last_event_seq', v_ticket.last_event_seq));
  return v_response;
end;
$$;

revoke all on function public.pos_kds_ticket_id(uuid, uuid, text) from public;
revoke all on function public.create_pos_tickets_v2(jsonb) from public;
revoke all on function public.status_pos_ticket_v2(jsonb) from public;
grant execute on function public.pos_kds_ticket_id(uuid, uuid, text) to anon, authenticated;
grant execute on function public.create_pos_tickets_v2(jsonb) to anon, authenticated, service_role;
grant execute on function public.status_pos_ticket_v2(jsonb) to anon, authenticated, service_role;
