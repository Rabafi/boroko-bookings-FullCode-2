-- Phase 4: offline inventory parity and authoritative movement ledger.
-- All mutations accept the frozen v2 operation envelope and are idempotent.

alter table public.inventory_purchases
  add column if not exists operation_id uuid,
  add column if not exists device_id text,
  add column if not exists operation_contract_version integer,
  add column if not exists accepted_at timestamptz;

alter table public.inventory_stocktakes
  add column if not exists operation_id uuid,
  add column if not exists device_id text,
  add column if not exists operation_contract_version integer,
  add column if not exists reconciliation_state text not null default 'authoritative';

alter table public.inventory_stocktake_lines
  add column if not exists count_operation_id uuid,
  add column if not exists counted_at timestamptz,
  add column if not exists expected_version timestamptz;

create unique index if not exists inventory_purchases_operation_id_uidx
  on public.inventory_purchases(operation_id) where operation_id is not null;
create unique index if not exists inventory_stocktakes_operation_id_uidx
  on public.inventory_stocktakes(operation_id) where operation_id is not null;

create or replace function public.record_inventory_purchase_v2(payload jsonb)
returns jsonb language plpgsql security definer set search_path to 'public'
as $$
declare
  v_op uuid := nullif(payload->>'operation_id','')::uuid;
  v_lodge uuid := nullif(payload->>'lodge_id','')::uuid;
  v_device text := nullif(btrim(payload->>'device_id'),'');
  v_body jsonb := coalesce(payload->'payload','{}'::jsonb);
  v_item uuid := nullif(v_body->>'item_id','')::uuid;
  v_purchase uuid := coalesce(nullif(v_body->>'id','')::uuid, v_op);
  v_qty numeric := nullif(v_body->>'quantity_purchased','')::numeric;
  v_cost numeric := nullif(v_body->>'total_cost','')::numeric;
  v_unit numeric;
  v_stock numeric;
  v_hash text := encode(extensions.digest(convert_to(payload::text,'UTF8'),'sha256'),'hex');
  v_claim jsonb;
  v_response jsonb;
begin
  if coalesce((payload->>'contract_version')::integer,0) <> 2 or v_op is null or v_lodge is null or v_device is null then
    return jsonb_build_object('success',false,'code','OPERATION_ENVELOPE_INVALID','retryable',false);
  end if;
  perform public.app_reject_pwa_financial_mutation();
  perform public.app_require_capability(v_lodge,'inventory.purchase',null,v_device);
  v_claim := public.app_claim_operation_receipt(v_op,v_lodge,v_device,'inventory_purchase_v2',v_hash);
  if coalesce((v_claim->>'replay')::boolean,false) then return coalesce(v_claim->'response',v_claim); end if;
  if coalesce((v_claim->>'claimed')::boolean,false) = false then
    return jsonb_build_object('success',false,'code','OPERATION_IN_PROGRESS','retryable',true,'operation_id',v_op);
  end if;
  if v_item is null or v_qty is null or v_qty <= 0 or v_cost is null or v_cost < 0 then
    raise exception using errcode='22023', message='Purchase quantity and cost must be valid positive values.';
  end if;
  select current_stock into v_stock from public.inventory_items where id=v_item and lodge_id=v_lodge for update;
  if v_stock is null then raise exception using errcode='42501', message='Inventory item is outside the lodge scope.'; end if;
  v_unit := round(v_cost / nullif(v_qty,0), 6);
  insert into public.inventory_purchases(id,lodge_id,item_id,date,quantity_purchased,total_cost,unit_cost,notes,created_at,operation_id,device_id,operation_contract_version,accepted_at)
  values(v_purchase,v_lodge,v_item,coalesce(nullif(v_body->>'date','')::date,current_date),v_qty,v_cost,v_unit,nullif(v_body->>'notes',''),now(),v_op,v_device,2,now());
  update public.inventory_items set current_stock=current_stock+v_qty, latest_unit_cost=v_unit where id=v_item and lodge_id=v_lodge;
  insert into public.inventory_movements(lodge_id,item_id,movement_type,quantity,unit_cost,total_cost,notes,reference_type,reference_id,source,created_by)
  values(v_lodge,v_item,'purchase',v_qty,v_unit,v_cost,nullif(v_body->>'notes',''),'inventory_purchase',v_purchase,'inventory_purchase_v2',public.app_current_user_id());
  v_response := jsonb_build_object('success',true,'operation_id',v_op,'entity_id',v_purchase,'id',v_purchase,'accepted_at',now(),'new_stock',v_stock+v_qty,'idempotent',false);
  perform public.app_record_operation_receipt(v_op,v_lodge,v_device,'inventory_purchase_v2',v_purchase,v_hash,v_response);
  perform public.app_append_audit_event(v_lodge,'inventory_purchase_v2_completed','inventory_purchase',v_purchase,v_op,v_response);
  return v_response;
end;
$$;

create or replace function public.adjust_inventory_stock_v2(payload jsonb)
returns jsonb language plpgsql security definer set search_path to 'public'
as $$
declare
  v_op uuid := nullif(payload->>'operation_id','')::uuid;
  v_lodge uuid := nullif(payload->>'lodge_id','')::uuid;
  v_device text := nullif(btrim(payload->>'device_id'),'');
  v_body jsonb := coalesce(payload->'payload','{}'::jsonb);
  v_item uuid := nullif(v_body->>'item_id','')::uuid;
  v_delta numeric := nullif(v_body->>'delta','')::numeric;
  v_old numeric;
  v_new numeric;
  v_ref uuid := coalesce(nullif(v_body->>'id','')::uuid,v_op);
  v_hash text := encode(extensions.digest(convert_to(payload::text,'UTF8'),'sha256'),'hex');
  v_claim jsonb;
  v_response jsonb;
begin
  if coalesce((payload->>'contract_version')::integer,0) <> 2 or v_op is null or v_lodge is null or v_device is null then
    return jsonb_build_object('success',false,'code','OPERATION_ENVELOPE_INVALID','retryable',false);
  end if;
  perform public.app_reject_pwa_financial_mutation();
  perform public.app_require_capability(v_lodge,'inventory.adjust',null,v_device);
  v_claim := public.app_claim_operation_receipt(v_op,v_lodge,v_device,'inventory_adjustment_v2',v_hash);
  if coalesce((v_claim->>'replay')::boolean,false) then return coalesce(v_claim->'response',v_claim); end if;
  if coalesce((v_claim->>'claimed')::boolean,false) = false then return jsonb_build_object('success',false,'code','OPERATION_IN_PROGRESS','retryable',true,'operation_id',v_op); end if;
  if v_item is null or v_delta is null or v_delta = 0 then raise exception using errcode='22023', message='A non-zero stock delta is required.'; end if;
  select current_stock into v_old from public.inventory_items where id=v_item and lodge_id=v_lodge for update;
  if v_old is null then raise exception using errcode='42501', message='Inventory item is outside the lodge scope.'; end if;
  v_new := v_old + v_delta;
  if v_new < 0 then raise exception using errcode='40902', message='Inventory stock cannot become negative.'; end if;
  update public.inventory_items set current_stock=v_new where id=v_item and lodge_id=v_lodge;
  insert into public.inventory_movements(lodge_id,item_id,movement_type,quantity,unit_cost,total_cost,notes,reference_type,reference_id,source,created_by)
  select v_lodge,v_item,'adjustment',v_delta,coalesce(latest_unit_cost,0),v_delta*coalesce(latest_unit_cost,0),nullif(v_body->>'notes',''),'inventory_adjustment',v_ref,'inventory_adjust_v2',public.app_current_user_id()
  from public.inventory_items where id=v_item and lodge_id=v_lodge;
  v_response := jsonb_build_object('success',true,'operation_id',v_op,'entity_id',v_ref,'id',v_ref,'accepted_at',now(),'old_stock',v_old,'new_stock',v_new,'applied_delta',v_delta,'idempotent',false);
  perform public.app_record_operation_receipt(v_op,v_lodge,v_device,'inventory_adjustment_v2',v_ref,v_hash,v_response);
  perform public.app_append_audit_event(v_lodge,'inventory_adjustment_v2_completed','inventory_item',v_item,v_op,v_response);
  return v_response;
end;
$$;

create or replace function public.set_pos_menu_item_availability_v2(payload jsonb)
returns jsonb language plpgsql security definer set search_path to 'public'
as $$
declare
  v_op uuid := nullif(payload->>'operation_id','')::uuid;
  v_lodge uuid := nullif(payload->>'lodge_id','')::uuid;
  v_device text := nullif(btrim(payload->>'device_id'),'');
  v_body jsonb := coalesce(payload->'payload','{}'::jsonb);
  v_item uuid := nullif(v_body->>'menu_item_id','')::uuid;
  v_available boolean := coalesce((v_body->>'is_available')::boolean,false);
  v_hash text := encode(extensions.digest(convert_to(payload::text,'UTF8'),'sha256'),'hex');
  v_claim jsonb;
  v_response jsonb;
begin
  if coalesce((payload->>'contract_version')::integer,0) <> 2 or v_op is null or v_lodge is null or v_device is null then return jsonb_build_object('success',false,'code','OPERATION_ENVELOPE_INVALID','retryable',false); end if;
  perform public.app_reject_pwa_financial_mutation();
  perform public.app_require_capability(v_lodge,'pos.catalog',null,v_device);
  v_claim := public.app_claim_operation_receipt(v_op,v_lodge,v_device,'pos_menu_availability_v2',v_hash);
  if coalesce((v_claim->>'replay')::boolean,false) then return coalesce(v_claim->'response',v_claim); end if;
  if coalesce((v_claim->>'claimed')::boolean,false) = false then return jsonb_build_object('success',false,'code','OPERATION_IN_PROGRESS','retryable',true,'operation_id',v_op); end if;
  update public.pos_menu_items set is_available=v_available where id=v_item and lodge_id=v_lodge;
  if not found then raise exception using errcode='42501', message='Menu item is outside the lodge scope.'; end if;
  v_response := jsonb_build_object('success',true,'operation_id',v_op,'entity_id',v_item,'id',v_item,'is_available',v_available,'accepted_at',now(),'idempotent',false);
  perform public.app_record_operation_receipt(v_op,v_lodge,v_device,'pos_menu_availability_v2',v_item,v_hash,v_response);
  perform public.app_append_audit_event(v_lodge,'pos_menu_availability_v2_completed','pos_menu_item',v_item,v_op,v_response);
  return v_response;
end;
$$;

revoke all on function public.record_inventory_purchase_v2(jsonb), public.adjust_inventory_stock_v2(jsonb), public.set_pos_menu_item_availability_v2(jsonb) from public;
grant execute on function public.record_inventory_purchase_v2(jsonb), public.adjust_inventory_stock_v2(jsonb), public.set_pos_menu_item_availability_v2(jsonb) to anon, authenticated, service_role;

create or replace function public.create_inventory_stocktake_v2(payload jsonb)
returns jsonb language plpgsql security definer set search_path to 'public' as $$
declare v_op uuid:=nullif(payload->>'operation_id','')::uuid; v_lodge uuid:=nullif(payload->>'lodge_id','')::uuid; v_device text:=nullif(btrim(payload->>'device_id'),''); v_body jsonb:=coalesce(payload->'payload','{}'::jsonb); v_id uuid:=coalesce(nullif(v_body->>'id','')::uuid,v_op); v_row public.inventory_stocktakes%rowtype; v_hash text:=encode(extensions.digest(convert_to(payload::text,'UTF8'),'sha256'),'hex'); v_claim jsonb; v_response jsonb;
begin
  perform public.app_reject_pwa_financial_mutation(); perform public.app_require_capability(v_lodge,'inventory.stocktake',null,v_device); v_claim:=public.app_claim_operation_receipt(v_op,v_lodge,v_device,'inventory_stocktake_create_v2',v_hash); if coalesce((v_claim->>'replay')::boolean,false) then return coalesce(v_claim->'response',v_claim); end if; select * into v_row from public.inventory_stocktakes where id=v_id and lodge_id=v_lodge for update; if v_row.id is null then insert into public.inventory_stocktakes(id,lodge_id,outlet_id,title,notes,status,created_by,operation_id,device_id,operation_contract_version,reconciliation_state) values(v_id,v_lodge,nullif(v_body->>'outlet_id','')::uuid,v_body->>'title',v_body->>'notes','open',public.app_current_user_id(),v_op,v_device,2,'pending_server_confirmation') returning * into v_row; insert into public.inventory_stocktake_lines(stocktake_id,lodge_id,item_id,expected_qty,unit_cost,expected_version) select v_id,v_lodge,ii.id,ii.current_stock,coalesce(ii.latest_unit_cost,0),ii.updated_at from public.inventory_items ii where ii.lodge_id=v_lodge and (nullif(v_body->>'outlet_id','')::uuid is null or ii.outlet_id is not distinct from nullif(v_body->>'outlet_id','')::uuid); end if; v_response:=jsonb_build_object('success',true,'operation_id',v_op,'entity_id',v_id,'id',v_id,'status',v_row.status,'accepted_at',now(),'idempotent',false); perform public.app_record_operation_receipt(v_op,v_lodge,v_device,'inventory_stocktake_create_v2',v_id,v_hash,v_response); return v_response; end; $$;

create or replace function public.save_inventory_stocktake_count_v2(payload jsonb)
returns jsonb language plpgsql security definer set search_path to 'public' as $$
declare v_op uuid:=nullif(payload->>'operation_id','')::uuid; v_lodge uuid:=nullif(payload->>'lodge_id','')::uuid; v_device text:=nullif(btrim(payload->>'device_id'),''); v_body jsonb:=coalesce(payload->'payload','{}'::jsonb); v_line uuid:=nullif(v_body->>'line_id','')::uuid; v_count numeric:=nullif(v_body->>'counted_qty','')::numeric; v_hash text:=encode(extensions.digest(convert_to(payload::text,'UTF8'),'sha256'),'hex'); v_claim jsonb; v_response jsonb;
begin perform public.app_reject_pwa_financial_mutation(); perform public.app_require_capability(v_lodge,'inventory.stocktake',null,v_device); v_claim:=public.app_claim_operation_receipt(v_op,v_lodge,v_device,'inventory_stocktake_count_v2',v_hash); if coalesce((v_claim->>'replay')::boolean,false) then return coalesce(v_claim->'response',v_claim); end if; if v_line is null or v_count is null or v_count<0 then raise exception using errcode='22023',message='A non-negative count is required.'; end if; update public.inventory_stocktake_lines set counted_qty=v_count,counted_at=now(),count_operation_id=v_op,updated_at=now() where id=v_line and lodge_id=v_lodge; if not found then raise exception using errcode='42501',message='Stocktake line is outside the lodge scope.'; end if; v_response:=jsonb_build_object('success',true,'operation_id',v_op,'entity_id',v_line,'id',v_line,'counted_qty',v_count,'accepted_at',now(),'idempotent',false); perform public.app_record_operation_receipt(v_op,v_lodge,v_device,'inventory_stocktake_count_v2',v_line,v_hash,v_response); return v_response; end; $$;

create or replace function public.post_inventory_stocktake_v2(payload jsonb)
returns jsonb language plpgsql security definer set search_path to 'public' as $$
declare v_op uuid:=nullif(payload->>'operation_id','')::uuid; v_lodge uuid:=nullif(payload->>'lodge_id','')::uuid; v_device text:=nullif(btrim(payload->>'device_id'),''); v_body jsonb:=coalesce(payload->'payload','{}'::jsonb); v_id uuid:=nullif(v_body->>'stocktake_id','')::uuid; v_row public.inventory_stocktakes%rowtype; v_hash text:=encode(extensions.digest(convert_to(payload::text,'UTF8'),'sha256'),'hex'); v_claim jsonb; v_response jsonb; v_line record; v_new numeric;
begin perform public.app_reject_pwa_financial_mutation(); perform public.app_require_capability(v_lodge,'inventory.stocktake',null,v_device); v_claim:=public.app_claim_operation_receipt(v_op,v_lodge,v_device,'inventory_stocktake_post_v2',v_hash); if coalesce((v_claim->>'replay')::boolean,false) then return coalesce(v_claim->'response',v_claim); end if; select * into v_row from public.inventory_stocktakes where id=v_id and lodge_id=v_lodge for update; if v_row.id is null or v_row.status<>'open' then raise exception using errcode='40901',message='Stocktake is not open.'; end if; for v_line in select * from public.inventory_stocktake_lines where stocktake_id=v_id and lodge_id=v_lodge for update loop if v_line.counted_qty is null then raise exception using errcode='40901',message='Every stocktake line must be counted.'; end if; v_new:=v_line.counted_qty-v_line.expected_qty; if v_new<>0 then update public.inventory_items set current_stock=current_stock+v_new where id=v_line.item_id and lodge_id=v_lodge; insert into public.inventory_movements(lodge_id,item_id,movement_type,quantity,unit_cost,total_cost,notes,reference_type,reference_id,source,created_by) values(v_lodge,v_line.item_id,'stocktake',v_new,coalesce(v_line.unit_cost,0),v_new*coalesce(v_line.unit_cost,0),'Stocktake adjustment','inventory_stocktake',v_id,'inventory_stocktake_v2',public.app_current_user_id()); end if; end loop; update public.inventory_stocktakes set status='posted',posted_at=now(),reconciliation_state='authoritative',updated_at=now() where id=v_id; v_response:=jsonb_build_object('success',true,'operation_id',v_op,'entity_id',v_id,'id',v_id,'status','posted','accepted_at',now(),'idempotent',false); perform public.app_record_operation_receipt(v_op,v_lodge,v_device,'inventory_stocktake_post_v2',v_id,v_hash,v_response); return v_response; end; $$;

revoke all on function public.create_inventory_stocktake_v2(jsonb),public.save_inventory_stocktake_count_v2(jsonb),public.post_inventory_stocktake_v2(jsonb) from public;
grant execute on function public.create_inventory_stocktake_v2(jsonb),public.save_inventory_stocktake_count_v2(jsonb),public.post_inventory_stocktake_v2(jsonb) to anon,authenticated,service_role;
