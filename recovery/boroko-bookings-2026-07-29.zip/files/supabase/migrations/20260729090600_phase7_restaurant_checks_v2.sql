-- Phase 7: offline-first restaurant checks and table ledger.

create table if not exists public.pos_checks (
  id uuid primary key default gen_random_uuid(),
  lodge_id uuid not null,
  outlet_id uuid not null references public.outlets(id) on delete restrict,
  table_id uuid,
  table_name text,
  waiter_id uuid,
  shift_id uuid,
  status text not null default 'open' check (status in ('open','settled','voided','requires_review')),
  version integer not null default 1,
  operation_id uuid not null,
  device_id text not null,
  opened_at timestamptz not null default now(),
  settled_at timestamptz,
  created_by uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (operation_id)
);

create unique index if not exists pos_checks_active_table_uidx
  on public.pos_checks(lodge_id,outlet_id,table_id) where status='open' and table_id is not null;

create table if not exists public.pos_check_rounds (
  id uuid primary key default gen_random_uuid(),
  lodge_id uuid not null,
  check_id uuid not null references public.pos_checks(id) on delete restrict,
  round_number integer not null,
  status text not null default 'submitted' check (status in ('draft','submitted','preparing','ready','served','cancelled')),
  items jsonb not null default '[]'::jsonb,
  operation_id uuid not null unique,
  submitted_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  unique(check_id,round_number)
);

create table if not exists public.pos_check_items (
  id uuid primary key default gen_random_uuid(),
  lodge_id uuid not null,
  check_id uuid not null references public.pos_checks(id) on delete restrict,
  round_id uuid not null references public.pos_check_rounds(id) on delete restrict,
  menu_item_id uuid,
  item_name text not null,
  quantity integer not null check(quantity > 0),
  returned_quantity integer not null default 0 check(returned_quantity >= 0),
  voided_quantity integer not null default 0 check(voided_quantity >= 0),
  unit_price numeric not null check(unit_price >= 0),
  price_history_id uuid,
  catalog_version text,
  modifiers jsonb not null default '[]'::jsonb,
  item_notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.pos_check_events (
  id uuid primary key default gen_random_uuid(),
  lodge_id uuid not null,
  check_id uuid not null references public.pos_checks(id) on delete restrict,
  event_type text not null,
  operation_id uuid not null unique,
  actor_id uuid,
  device_id text,
  payload jsonb not null default '{}'::jsonb,
  sequence integer not null,
  created_at timestamptz not null default now(),
  unique(check_id,sequence)
);

create index if not exists pos_checks_scope_idx on public.pos_checks(lodge_id,outlet_id,status,updated_at desc);
create index if not exists pos_check_items_check_idx on public.pos_check_items(check_id,round_id);
alter table public.pos_checks enable row level security;
alter table public.pos_check_rounds enable row level security;
alter table public.pos_check_items enable row level security;
alter table public.pos_check_events enable row level security;
drop policy if exists pos_checks_lodge_select on public.pos_checks;
create policy pos_checks_lodge_select on public.pos_checks for select using(public.app_lodge_access(lodge_id));
drop policy if exists pos_check_rounds_lodge_select on public.pos_check_rounds;
create policy pos_check_rounds_lodge_select on public.pos_check_rounds for select using(public.app_lodge_access(lodge_id));
drop policy if exists pos_check_items_lodge_select on public.pos_check_items;
create policy pos_check_items_lodge_select on public.pos_check_items for select using(public.app_lodge_access(lodge_id));
drop policy if exists pos_check_events_lodge_select on public.pos_check_events;
create policy pos_check_events_lodge_select on public.pos_check_events for select using(public.app_lodge_access(lodge_id));
revoke all on public.pos_checks,public.pos_check_rounds,public.pos_check_items,public.pos_check_events from anon,authenticated;
grant select on public.pos_checks,public.pos_check_rounds,public.pos_check_items,public.pos_check_events to anon,authenticated;

create or replace function public.open_pos_check_v2(payload jsonb)
returns jsonb language plpgsql security definer set search_path to 'public' as $$
declare
  v_op uuid:=nullif(payload->>'operation_id','')::uuid; v_lodge uuid:=nullif(payload->>'lodge_id','')::uuid; v_device text:=nullif(btrim(payload->>'device_id'),'');
  v_body jsonb:=coalesce(payload->'payload','{}'::jsonb); v_id uuid:=coalesce(nullif(v_body->>'id','')::uuid,v_op); v_check public.pos_checks%rowtype;
  v_hash text:=encode(extensions.digest(convert_to(payload::text,'UTF8'),'sha256'),'hex'); v_claim jsonb; v_response jsonb;
begin
  if coalesce((payload->>'contract_version')::integer,0)<>2 or v_op is null or v_lodge is null or v_device is null then return jsonb_build_object('success',false,'code','OPERATION_ENVELOPE_INVALID'); end if;
  perform public.app_reject_pwa_financial_mutation(); perform public.app_require_capability(v_lodge,'pos.sale',null,v_device);
  v_claim:=public.app_claim_operation_receipt(v_op,v_lodge,v_device,'pos_check_open_v2',v_hash);
  if coalesce((v_claim->>'replay')::boolean,false) then return coalesce(v_claim->'response',v_claim); end if;
  if coalesce((v_claim->>'claimed')::boolean,false)=false then return jsonb_build_object('success',false,'code','OPERATION_IN_PROGRESS','retryable',true); end if;
  insert into public.pos_checks(id,lodge_id,outlet_id,table_id,table_name,waiter_id,shift_id,operation_id,device_id,created_by)
  values(v_id,v_lodge,nullif(v_body->>'outlet_id','')::uuid,nullif(v_body->>'table_id','')::uuid,nullif(v_body->>'table_name',''),nullif(v_body->>'waiter_id','')::uuid,nullif(v_body->>'shift_id','')::uuid,v_op,v_device,public.app_current_user_id()) returning * into v_check;
  insert into public.pos_check_events(lodge_id,check_id,event_type,operation_id,actor_id,device_id,payload,sequence)
  values(v_lodge,v_check.id,'open',v_op,public.app_current_user_id(),v_device,v_body,1);
  v_response:=jsonb_build_object('success',true,'operation_id',v_op,'entity_id',v_check.id,'id',v_check.id,'version',v_check.version,'status',v_check.status,'accepted_at',now(),'idempotent',false);
  perform public.app_record_operation_receipt(v_op,v_lodge,v_device,'pos_check_open_v2',v_check.id,v_hash,v_response); perform public.app_append_audit_event(v_lodge,'pos_check_opened','pos_check',v_check.id,v_op,v_response); return v_response;
exception when unique_violation then return jsonb_build_object('success',false,'code','CHECK_TABLE_CONFLICT','review_required',true,'retryable',false); end; $$;

create or replace function public.add_pos_check_round_v2(payload jsonb)
returns jsonb language plpgsql security definer set search_path to 'public' as $$
declare
  v_op uuid:=nullif(payload->>'operation_id','')::uuid; v_lodge uuid:=nullif(payload->>'lodge_id','')::uuid; v_device text:=nullif(btrim(payload->>'device_id'),'');
  v_body jsonb:=coalesce(payload->'payload','{}'::jsonb); v_check public.pos_checks%rowtype; v_round uuid:=coalesce(nullif(v_body->>'round_id','')::uuid,v_op); v_num integer;
  v_hash text:=encode(extensions.digest(convert_to(payload::text,'UTF8'),'sha256'),'hex'); v_claim jsonb; v_response jsonb; v_item jsonb;
begin
  if coalesce((payload->>'contract_version')::integer,0)<>2 or v_op is null or v_lodge is null or v_device is null then return jsonb_build_object('success',false,'code','OPERATION_ENVELOPE_INVALID'); end if;
  perform public.app_reject_pwa_financial_mutation(); perform public.app_require_capability(v_lodge,'pos.sale',null,v_device);
  v_claim:=public.app_claim_operation_receipt(v_op,v_lodge,v_device,'pos_check_round_v2',v_hash); if coalesce((v_claim->>'replay')::boolean,false) then return coalesce(v_claim->'response',v_claim); end if;
  if coalesce((v_claim->>'claimed')::boolean,false)=false then return jsonb_build_object('success',false,'code','OPERATION_IN_PROGRESS','retryable',true); end if;
  select * into v_check from public.pos_checks where id=nullif(v_body->>'check_id','')::uuid and lodge_id=v_lodge for update;
  if v_check.id is null or v_check.status<>'open' then raise exception using errcode='40901',message='Check is not open.'; end if;
  select coalesce(max(round_number),0)+1 into v_num from public.pos_check_rounds where check_id=v_check.id;
  insert into public.pos_check_rounds(id,lodge_id,check_id,round_number,items,operation_id) values(v_round,v_lodge,v_check.id,v_num,coalesce(v_body->'items','[]'::jsonb),v_op);
  for v_item in select value from jsonb_array_elements(coalesce(v_body->'items','[]'::jsonb)) loop
    if coalesce((v_item->>'quantity')::integer,0)<=0 then raise exception using errcode='22023',message='Check round quantities must be positive.'; end if;
    insert into public.pos_check_items(lodge_id,check_id,round_id,menu_item_id,item_name,quantity,unit_price,price_history_id,catalog_version,modifiers,item_notes)
    values(v_lodge,v_check.id,v_round,nullif(v_item->>'menu_item_id','')::uuid,coalesce(v_item->>'item_name','Item'),(v_item->>'quantity')::integer,coalesce((v_item->>'unit_price')::numeric,0),nullif(v_item->>'price_history_id','')::uuid,v_item->>'catalog_version',coalesce(v_item->'modifiers','[]'::jsonb),v_item->>'item_notes');
  end loop;
  update public.pos_checks set version=version+1,updated_at=now() where id=v_check.id;
  insert into public.pos_check_events(lodge_id,check_id,event_type,operation_id,actor_id,device_id,payload,sequence) values(v_lodge,v_check.id,'add_round',v_op,public.app_current_user_id(),v_device,v_body,v_check.version+1);
  v_response:=jsonb_build_object('success',true,'operation_id',v_op,'entity_id',v_round,'id',v_round,'check_id',v_check.id,'round_number',v_num,'status','submitted','accepted_at',now(),'idempotent',false);
  perform public.app_record_operation_receipt(v_op,v_lodge,v_device,'pos_check_round_v2',v_round,v_hash,v_response); return v_response;
end; $$;

create or replace function public.transfer_pos_check_v2(payload jsonb) returns jsonb language plpgsql security definer set search_path to 'public' as $$
declare v_op uuid:=nullif(payload->>'operation_id','')::uuid; v_lodge uuid:=nullif(payload->>'lodge_id','')::uuid; v_device text:=nullif(btrim(payload->>'device_id'),''); v_body jsonb:=coalesce(payload->'payload','{}'::jsonb); v_check public.pos_checks%rowtype; v_hash text:=encode(extensions.digest(convert_to(payload::text,'UTF8'),'sha256'),'hex'); v_claim jsonb; v_response jsonb;
begin perform public.app_reject_pwa_financial_mutation(); perform public.app_require_capability(v_lodge,'pos.sale',null,v_device); v_claim:=public.app_claim_operation_receipt(v_op,v_lodge,v_device,'pos_check_transfer_v2',v_hash); if coalesce((v_claim->>'replay')::boolean,false) then return coalesce(v_claim->'response',v_claim); end if; select * into v_check from public.pos_checks where id=nullif(v_body->>'check_id','')::uuid and lodge_id=v_lodge for update; if v_check.id is null or v_check.status<>'open' then raise exception using errcode='40901',message='Check is not open.'; end if; update public.pos_checks set table_id=nullif(v_body->>'table_id','')::uuid,table_name=nullif(v_body->>'table_name',''),version=version+1,updated_at=now() where id=v_check.id; v_response:=jsonb_build_object('success',true,'operation_id',v_op,'entity_id',v_check.id,'id',v_check.id,'version',v_check.version+1,'accepted_at',now(),'idempotent',false); perform public.app_record_operation_receipt(v_op,v_lodge,v_device,'pos_check_transfer_v2',v_check.id,v_hash,v_response); return v_response; end; $$;

create or replace function public.settle_pos_check_v2(payload jsonb) returns jsonb language plpgsql security definer set search_path to 'public' as $$
declare v_op uuid:=nullif(payload->>'operation_id','')::uuid; v_lodge uuid:=nullif(payload->>'lodge_id','')::uuid; v_device text:=nullif(btrim(payload->>'device_id'),''); v_body jsonb:=coalesce(payload->'payload','{}'::jsonb); v_check public.pos_checks%rowtype; v_sale jsonb; v_sale_envelope jsonb; v_hash text:=encode(extensions.digest(convert_to(payload::text,'UTF8'),'sha256'),'hex'); v_claim jsonb; v_response jsonb;
begin perform public.app_reject_pwa_financial_mutation(); perform public.app_require_capability(v_lodge,'pos.sale',null,v_device); v_claim:=public.app_claim_operation_receipt(v_op,v_lodge,v_device,'pos_check_settle_v2',v_hash); if coalesce((v_claim->>'replay')::boolean,false) then return coalesce(v_claim->'response',v_claim); end if; select * into v_check from public.pos_checks where id=nullif(v_body->>'check_id','')::uuid and lodge_id=v_lodge for update; if v_check.id is null or v_check.status<>'open' then raise exception using errcode='40901',message='Check is not open.'; end if; v_sale_envelope:=jsonb_build_object('contract_version',2,'operation_id',gen_random_uuid(),'device_id',v_device,'device_event_at',now(),'lodge_id',v_lodge,'outlet_id',v_check.outlet_id,'payload',jsonb_build_object('id',v_check.id,'outlet_id',v_check.outlet_id,'items',coalesce(v_body->'items','[]'::jsonb),'tenders',coalesce(v_body->'tenders','[]'::jsonb),'payment_method',coalesce(v_body->>'payment_method','cash'))); v_sale:=public.create_pos_order_v2(v_sale_envelope); if coalesce((v_sale->>'success')::boolean,false)=false then return v_sale; end if; update public.pos_checks set status='settled',settled_at=now(),version=version+1,updated_at=now() where id=v_check.id; v_response:=jsonb_build_object('success',true,'operation_id',v_op,'entity_id',v_check.id,'id',v_check.id,'order_id',v_sale->>'entity_id','receipt_number',v_sale->>'receipt_number','total',v_sale->>'total','accepted_at',now(),'idempotent',false); perform public.app_record_operation_receipt(v_op,v_lodge,v_device,'pos_check_settle_v2',v_check.id,v_hash,v_response); return v_response; end; $$;

revoke all on function public.open_pos_check_v2(jsonb),public.add_pos_check_round_v2(jsonb),public.transfer_pos_check_v2(jsonb),public.settle_pos_check_v2(jsonb) from public;
grant execute on function public.open_pos_check_v2(jsonb),public.add_pos_check_round_v2(jsonb),public.transfer_pos_check_v2(jsonb),public.settle_pos_check_v2(jsonb) to anon,authenticated,service_role;
