-- Phase 8: shared Restaurant/Bar configuration and read-only Manager oversight.

create table if not exists public.pos_config_revisions (
  id uuid primary key default gen_random_uuid(), lodge_id uuid not null, outlet_id uuid,
  config_type text not null, config_key text not null, version integer not null default 1,
  value jsonb not null default '{}'::jsonb, operation_id uuid not null unique,
  updated_by uuid, updated_at timestamptz not null default now(),
  unique(lodge_id,outlet_id,config_type,config_key)
);
create index if not exists pos_config_revisions_scope_idx on public.pos_config_revisions(lodge_id,outlet_id,config_type);
alter table public.pos_config_revisions enable row level security;
drop policy if exists pos_config_revisions_lodge_select on public.pos_config_revisions;
create policy pos_config_revisions_lodge_select on public.pos_config_revisions for select using(public.app_lodge_access(lodge_id));
revoke all on public.pos_config_revisions from anon,authenticated;
grant select on public.pos_config_revisions to anon,authenticated;

create or replace function public.upsert_pos_config_v2(payload jsonb)
returns jsonb language plpgsql security definer set search_path to 'public' as $$
declare
  v_op uuid:=nullif(payload->>'operation_id','')::uuid; v_lodge uuid:=nullif(payload->>'lodge_id','')::uuid; v_device text:=nullif(btrim(payload->>'device_id'),'');
  v_body jsonb:=coalesce(payload->'payload','{}'::jsonb); v_type text:=nullif(btrim(v_body->>'config_type'),''); v_key text:=nullif(btrim(v_body->>'config_key'),''); v_expected integer:=nullif(v_body->>'expected_version','')::integer; v_row public.pos_config_revisions%rowtype;
  v_hash text:=encode(extensions.digest(convert_to(payload::text,'UTF8'),'sha256'),'hex'); v_claim jsonb; v_response jsonb;
begin
  if coalesce((payload->>'contract_version')::integer,0)<>2 or v_op is null or v_lodge is null or v_device is null or v_type is null or v_key is null then return jsonb_build_object('success',false,'code','OPERATION_ENVELOPE_INVALID'); end if;
  perform public.app_reject_pwa_financial_mutation(); perform public.app_require_capability(v_lodge,'pos.catalog',null,v_device);
  v_claim:=public.app_claim_operation_receipt(v_op,v_lodge,v_device,'pos_config_v2',v_hash); if coalesce((v_claim->>'replay')::boolean,false) then return coalesce(v_claim->'response',v_claim); end if;
  if coalesce((v_claim->>'claimed')::boolean,false)=false then return jsonb_build_object('success',false,'code','OPERATION_IN_PROGRESS','retryable',true); end if;
  select * into v_row from public.pos_config_revisions where lodge_id=v_lodge and outlet_id is not distinct from nullif(v_body->>'outlet_id','')::uuid and config_type=v_type and config_key=v_key for update;
  if v_row.id is not null and v_expected is not null and v_row.version<>v_expected then return jsonb_build_object('success',false,'code','CONFIG_VERSION_CONFLICT','review_required',true,'current_version',v_row.version); end if;
  insert into public.pos_config_revisions(id,lodge_id,outlet_id,config_type,config_key,version,value,operation_id,updated_by,updated_at)
  values(coalesce(v_row.id,gen_random_uuid()),v_lodge,nullif(v_body->>'outlet_id','')::uuid,v_type,v_key,coalesce(v_row.version,0)+1,coalesce(v_body->'value','{}'::jsonb),v_op,public.app_current_user_id(),now())
  on conflict(lodge_id,outlet_id,config_type,config_key) do update set version=excluded.version,value=excluded.value,operation_id=excluded.operation_id,updated_by=excluded.updated_by,updated_at=excluded.updated_at
  returning * into v_row;
  v_response:=jsonb_build_object('success',true,'operation_id',v_op,'entity_id',v_row.id,'id',v_row.id,'version',v_row.version,'accepted_at',now(),'idempotent',false);
  perform public.app_record_operation_receipt(v_op,v_lodge,v_device,'pos_config_v2',v_row.id,v_hash,v_response); perform public.app_append_audit_event(v_lodge,'pos_config_v2_updated','pos_config_revision',v_row.id,v_op,v_response); return v_response;
end; $$;

create or replace function public.get_manager_pos_oversight(p_lodge_id uuid,p_outlet_id uuid default null)
returns jsonb language sql security definer set search_path to 'public' as $$
  select jsonb_build_object(
    'success',true,
    'lodge_id',p_lodge_id,
    'open_shifts',(select count(*) from public.pos_shifts s where s.lodge_id=p_lodge_id and s.status='open' and (p_outlet_id is null or s.outlet_id=p_outlet_id)),
    'open_checks',(select count(*) from public.pos_checks c where c.lodge_id=p_lodge_id and c.status='open' and (p_outlet_id is null or c.outlet_id=p_outlet_id)),
    'pending_returns',(select count(*) from public.pos_returns r where r.lodge_id=p_lodge_id and r.refund_status='pending_external_refund' and (p_outlet_id is null or r.outlet_id=p_outlet_id)),
    'kds_aging',(select count(*) from public.pos_prep_tickets t where t.lodge_id=p_lodge_id and t.status in ('new','preparing') and (p_outlet_id is null or t.outlet_id=p_outlet_id)),
    'sync_health',jsonb_build_object('generated_at',now())
  );
$$;
revoke all on function public.upsert_pos_config_v2(jsonb) from public;
grant execute on function public.upsert_pos_config_v2(jsonb) to anon,authenticated,service_role;
revoke all on function public.get_manager_pos_oversight(uuid,uuid) from public;
grant execute on function public.get_manager_pos_oversight(uuid,uuid) to anon,authenticated,service_role;
