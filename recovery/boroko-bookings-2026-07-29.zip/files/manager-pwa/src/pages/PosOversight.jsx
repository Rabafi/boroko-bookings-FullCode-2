import { useEffect, useState } from 'react'
import { Activity, ChefHat, Clock3, RefreshCw, Table2 } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import { getManagerPosOversight } from '../lib/api'

function Metric({ icon: Icon, label, value }) {
  return <div className="rounded-2xl bg-gray-800 p-4"><Icon size={18} className="text-green-300" /><p className="mt-3 text-2xl font-bold text-white">{value ?? '—'}</p><p className="mt-1 text-xs text-gray-400">{label}</p></div>
}

export default function PosOversight() {
  const { user } = useAuth()
  const [data, setData] = useState(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(true)
  const load = async () => {
    setLoading(true); setError('')
    try { setData(await getManagerPosOversight(user?.lodge_id)) } catch (e) { setError(e?.message || 'Could not load POS oversight.') } finally { setLoading(false) }
  }
  useEffect(() => { load() }, [user?.lodge_id])
  return <main className="space-y-4 p-4">
    <div className="flex items-center justify-between"><div><p className="text-xs uppercase tracking-[0.18em] text-green-300">Manager oversight</p><h1 className="mt-1 text-2xl font-bold text-white">Restaurant &amp; Bar</h1></div><button type="button" onClick={load} className="rounded-xl bg-gray-800 p-3 text-gray-300" aria-label="Refresh oversight"><RefreshCw size={18} className={loading ? 'animate-spin' : ''} /></button></div>
    {error && <div className="rounded-xl border border-amber-700 bg-amber-950/40 p-3 text-sm text-amber-200">{error}</div>}
    <div className="grid grid-cols-2 gap-3"><Metric icon={Clock3} label="Open shifts" value={data?.open_shifts} /><Metric icon={Table2} label="Open restaurant checks" value={data?.open_checks} /><Metric icon={Activity} label="Pending refunds" value={data?.pending_returns} /><Metric icon={ChefHat} label="KDS items aging" value={data?.kds_aging} /></div>
    <p className="text-xs text-gray-500">Read-only server snapshot. POS sales, returns, voids, inventory, and cash-up mutations remain desktop-only.</p>
  </main>
}
