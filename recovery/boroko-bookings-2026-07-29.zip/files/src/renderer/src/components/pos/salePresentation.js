/**
 * Renderer-only helpers for the v2 POS sale contract.
 *
 * These helpers intentionally never calculate authoritative financial values.
 * They only describe the cashier's provisional intent and present the state
 * returned by the Electron adapter/server.
 */

export function buildSemanticDiscount({
  allowed = true,
  subtotal = 0,
  mode = 'amount',
  value = 0,
  reason = ''
} = {}) {
  const gross = Number(subtotal)
  const requested = Number(value)
  if (!allowed || !Number.isFinite(gross) || gross <= 0 || !Number.isFinite(requested) || requested <= 0) {
    return null
  }

  const normalizedMode = mode === 'percent' ? 'percent' : 'amount'
  const amount = normalizedMode === 'percent'
    ? Math.min(gross, gross * Math.min(requested, 100) / 100)
    : Math.min(gross, requested)

  if (!(amount > 0)) return null
  return {
    type: 'manual',
    mode: normalizedMode,
    value: requested,
    amount: Math.round(amount * 100) / 100,
    reason: String(reason || '').trim() || null
  }
}

export function getSaleSyncPresentation(order = {}) {
  const state = String(order?._sync_state || order?.sync_state || '').toLowerCase()
  const review = order?.review_required === true
    || state === 'manual_review_required'
    || state === 'review'
    || state === 'needs_attention'
  const failed = state === 'failed' || order?.sync_failed === true
  const pending = order?._pending_sync === true || order?.pending === true || state === 'pending'
  const reconciled = order?.reconciled === true || state === 'reconciled'
    || (Boolean(order?.receipt_number) && !pending && !review && !failed)

  if (review) {
    return {
      state: 'review',
      label: 'Needs Review',
      detail: order?._sync_error || order?.review_reason || 'Server rejected this sale. Review the conflict before retrying.',
      tone: 'amber',
      authoritative: false
    }
  }
  if (failed) {
    return {
      state: 'failed',
      label: 'Sync Failed',
      detail: order?._sync_error || 'The sale could not be reconciled with the server.',
      tone: 'red',
      authoritative: false
    }
  }
  if (pending) {
    return {
      state: 'pending',
      label: 'Pending Sync',
      detail: 'Sale is recorded locally. Receipt becomes authoritative after replay.',
      tone: 'amber',
      authoritative: false
    }
  }
  if (reconciled) {
    return {
      state: 'reconciled',
      label: 'Reconciled',
      detail: 'Server-confirmed sale and receipt.',
      tone: 'green',
      authoritative: true
    }
  }
  return {
    state: 'synced',
    label: 'Synced',
    detail: 'Server-confirmed sale.',
    tone: 'green',
    authoritative: true
  }
}

export function mergeAuthoritativeSaleResult(result = {}, provisional = {}) {
  const authoritativeTotals = result?.authoritative_totals || result?.totals || {}
  const total = Number(
    result?.authoritative_total
      ?? authoritativeTotals.total
      ?? result?.total
      ?? provisional.total
  )
  const merged = {
    ...provisional,
    ...(Number.isFinite(total) ? { total } : {}),
    gross_total: Number(authoritativeTotals.gross_total ?? result?.gross_total ?? provisional.gross_total),
    discount_total: Number(authoritativeTotals.discount_total ?? result?.discount_total ?? provisional.discount_total),
    tax_total: Number(authoritativeTotals.tax_total ?? result?.tax_total ?? provisional.tax_total),
    tip_total: Number(authoritativeTotals.tip_total ?? result?.tip_total ?? provisional.tip_total),
    receipt_number: result?.receipt_number || provisional.receipt_number || null,
    accepted_at: result?.accepted_at || provisional.accepted_at || null,
    operation_id: result?.operation_id || provisional.operation_id || null,
    reconciliation_note: result?.reconciliation_note || null,
    _provisional_total: provisional._provisional_total ?? provisional.total
  }
  const review = result?.review_required === true || result?.status === 'review'
  const pending = result?.offline === true || result?.pending === true || result?._pending_sync === true
  merged.review_required = review
  merged._pending_sync = pending
  merged._sync_state = review ? 'manual_review_required' : pending ? 'pending' : 'reconciled'
  merged._is_authoritative = !review && !pending
  return merged
}

export function isTenderTotalBalanced(tenders = [], total = 0, tolerance = 0.005) {
  const expected = Number(total)
  if (!Number.isFinite(expected) || expected < 0) return false
  const received = (Array.isArray(tenders) ? tenders : []).reduce((sum, tender) => {
    const amount = Number(tender?.amount)
    return sum + (Number.isFinite(amount) && amount > 0 ? amount : 0)
  }, 0)
  return Math.abs(Math.round((expected - received) * 100) / 100) <= tolerance
}
