/**
 * Renderer-only helpers for the Phase 3 return/void contract.
 *
 * These helpers describe an operator's intent and present the response from
 * the authoritative return/void RPC.  They deliberately do not calculate a
 * refund amount, mutate stock, or decide whether a return is allowed.
 */

export const RETURN_CONTRACT_VERSION = 2

const SECRET_KEYS = new Set(['pin', 'password', 'passcode', 'secret', 'pin_hash'])

function finiteNumber(value, fallback = 0) {
  const number = Number(value)
  return Number.isFinite(number) ? number : fallback
}

function getLineReturnedQuantity(line = {}) {
  return Math.max(0, finiteNumber(
    line.returned_quantity
      ?? line.returned_qty
      ?? line.quantity_returned
      ?? line.returned,
    0
  ))
}

/** Return the remaining quantity for each original sale line. */
export function getReturnableLines(order = {}) {
  const lines = Array.isArray(order?.pos_order_items)
    ? order.pos_order_items
    : Array.isArray(order?.items)
      ? order.items
      : []

  return lines.map((line) => {
    const soldQuantity = Math.max(0, finiteNumber(line?.quantity, 0))
    const returnedQuantity = Math.min(soldQuantity, getLineReturnedQuantity(line))
    return {
      ...line,
      sold_quantity: soldQuantity,
      returned_quantity: returnedQuantity,
      remaining_quantity: Math.max(0, soldQuantity - returnedQuantity)
    }
  }).filter((line) => line.remaining_quantity > 0)
}

/**
 * Convert editable quantities into a positive-only return intent.  The server
 * still re-locks the source order and enforces the remaining quantity.
 */
export function buildReturnItems(order = {}, quantities = {}) {
  return getReturnableLines(order).map((line) => {
    const requested = Math.max(0, finiteNumber(quantities?.[line.id], 0))
    const quantity = Math.min(requested, line.remaining_quantity)
    return quantity > 0
      ? { line_id: line.id, quantity }
      : null
  }).filter(Boolean)
}

export function getReturnSyncPresentation(result = {}) {
  const state = String(
    result?._sync_state
      || result?.sync_state
      || result?.refund_status
      || result?.status
      || ''
  ).toLowerCase()
  const pendingExternalRefund = result?.pending_external_refund === true
    || state === 'pending_external_refund'
    || state === 'refund_pending'
  const review = result?.review_required === true
    || state === 'manual_review_required'
    || state === 'review'
    || state === 'needs_attention'
  const pending = result?.offline === true
    || result?._pending_sync === true
    || state === 'pending'
  const failed = state === 'failed' || result?.sync_failed === true
  const authoritative = result?.authoritative === true
    || result?.reconciled === true
    || Boolean(result?.receipt_number || result?.return_receipt_number)

  if (review) {
    return {
      state: 'review',
      label: 'Needs Review',
      detail: result?.review_reason || result?._sync_error || 'Return rejected or needs an operator decision.',
      authoritative: false,
      releaseExternalCash: false
    }
  }
  if (pendingExternalRefund) {
    return {
      state: 'pending_external_refund',
      label: 'Refund Pending',
      detail: 'Record the terminal or mobile-money reversal reference before releasing cash.',
      authoritative,
      releaseExternalCash: false
    }
  }
  if (failed) {
    return {
      state: 'failed',
      label: 'Sync Failed',
      detail: result?._sync_error || 'Return could not be reconciled with the server.',
      authoritative: false,
      releaseExternalCash: false
    }
  }
  if (pending) {
    return {
      state: 'pending',
      label: 'Pending Sync',
      detail: 'Return is stored locally. Do not release external cash until replay succeeds.',
      authoritative: false,
      releaseExternalCash: false
    }
  }
  if (authoritative) {
    return {
      state: 'reconciled',
      label: 'Reconciled',
      detail: 'Server-confirmed return receipt and allocation.',
      authoritative: true,
      releaseExternalCash: pendingExternalRefund ? false : true
    }
  }
  return {
    state: 'awaiting_confirmation',
    label: 'Awaiting Confirmation',
    detail: 'The authoritative return receipt has not been received.',
    authoritative: false,
    releaseExternalCash: false
  }
}

export function getVoidSyncPresentation(result = {}) {
  const state = String(result?._sync_state || result?.sync_state || result?.status || '').toLowerCase()
  const review = result?.review_required === true || state === 'manual_review_required' || state === 'review'
  const pending = result?.offline === true || result?._pending_sync === true || state === 'pending'
  const authoritative = result?.authoritative === true || result?.reconciled === true || Boolean(result?.void_receipt_number)
  if (review) return { state: 'review', label: 'Needs Review', detail: result?.review_reason || result?._sync_error || 'Void needs manual review.', authoritative: false, releaseExternalCash: false }
  if (pending) return { state: 'pending', label: 'Pending Sync', detail: 'Void is queued. The sale remains pending until server confirmation.', authoritative: false, releaseExternalCash: false }
  if (authoritative) return { state: 'reconciled', label: 'Reconciled', detail: 'Server-confirmed void and stock restoration.', authoritative: true, releaseExternalCash: false }
  return { state: 'awaiting_confirmation', label: 'Awaiting Confirmation', detail: 'The authoritative void receipt has not been received.', authoritative: false, releaseExternalCash: false }
}

/**
 * Build the mutation request without a plaintext approval secret.  The
 * approval assertion is produced by the trusted desktop approval adapter.
 */
export function buildApprovalMutationRequest({
  operation = 'return',
  operationId,
  orderId,
  outletId,
  reason,
  approvalAssertion,
  items = [],
  paymentMethod = null
} = {}) {
  const request = {
    contract_version: RETURN_CONTRACT_VERSION,
    operation,
    operation_id: operationId || null,
    order_id: orderId || null,
    outlet_id: outletId || null,
    reason: String(reason || '').trim(),
    approval_assertion: approvalAssertion || null
  }
  if (operation === 'return') {
    request.items = items
    request.payment_method = paymentMethod || null
  }
  return request
}

/** Static safety helper used by contract tests and support-bundle filters. */
export function containsPlaintextApprovalSecret(value) {
  if (Array.isArray(value)) return value.some(containsPlaintextApprovalSecret)
  if (!value || typeof value !== 'object') return false
  return Object.entries(value).some(([key, entry]) => {
    if (SECRET_KEYS.has(String(key).toLowerCase())) return true
    return containsPlaintextApprovalSecret(entry)
  })
}

