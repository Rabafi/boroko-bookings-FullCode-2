/**
 * Pure helpers for the v2 operation envelope.
 *
 * This module deliberately has no Electron, filesystem, Supabase, or actor
 * dependencies.  Callers create the envelope before doing a local mutation and
 * persist/replay the resulting object unchanged.  The database remains the
 * authority for the actor, capability, outlet scope, and accepted server time.
 */

export const OPERATION_CONTRACT_VERSION = 2;

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const DEVICE_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{7,127}$/;
const ISO_TIMESTAMP_PATTERN = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?(?:Z|[+-]\d{2}:?\d{2})$/;

/** Fields that must be derived from the authenticated server session. */
export const CALLER_AUTHORITY_FIELDS = Object.freeze([
  'actor_id',
  'actor_name',
  'actor_role',
  'approved_by',
  'approver_id',
  'approval_pin',
  'cashier_id',
  'cashier_name',
  'created_by',
  'created_by_name',
  'password',
  'pin',
  'recorded_by',
  'recorded_by_name',
  'requested_by',
  'role',
  'staff_id',
  'staff_name',
  'user_id',
  'user_name',
  'waiter_id',
  'waiter_name'
]);

const CALLER_AUTHORITY_FIELD_SET = new Set(CALLER_AUTHORITY_FIELDS);
const ENVELOPE_FIELDS = Object.freeze([
  'contract_version',
  'operation_id',
  'device_id',
  'device_event_at',
  'lodge_id',
  'outlet_id',
  'payload'
]);

function defaultOperationId() {
  if (typeof globalThis.crypto?.randomUUID === 'function') return globalThis.crypto.randomUUID();
  throw new Error('A cryptographically secure randomUUID implementation is required.');
}

function defaultNow() {
  return new Date().toISOString();
}

function normalizeUuid(value) {
  return typeof value === 'string' ? value.trim().toLowerCase() : value;
}

function normalizeDeviceId(value) {
  return typeof value === 'string' ? value.trim() : value;
}

function isPlainObject(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

function cloneValue(value) {
  if (Array.isArray(value)) return value.map(cloneValue);
  if (isPlainObject(value)) {
    return Object.fromEntries(Object.entries(value).map(([key, child]) => [key, cloneValue(child)]));
  }
  return value;
}

function freezeDeep(value) {
  if (!value || typeof value !== 'object' || Object.isFrozen(value)) return value;
  for (const child of Object.values(value)) freezeDeep(child);
  return Object.freeze(value);
}

function clonePayload(payload) {
  if (payload === undefined) return {};
  if (!isPlainObject(payload)) {
    throw new OperationEnvelopeError('PAYLOAD_INVALID', 'Operation payload must be a plain object.');
  }
  // Deep-clone and freeze so a caller cannot alter the exact request that will
  // later be replayed after a restart or dead-letter retry.
  return freezeDeep(cloneValue(payload));
}

function findCallerAuthorityFields(value, prefix = '') {
  if (!isPlainObject(value)) return [];
  return Object.keys(value)
    .filter((key) => CALLER_AUTHORITY_FIELD_SET.has(key.toLowerCase()))
    .map((key) => `${prefix}${key}`);
}

export class OperationEnvelopeError extends Error {
  constructor(code, message, details = {}) {
    super(message);
    this.name = 'OperationEnvelopeError';
    this.code = code;
    this.details = details;
  }
}

export function isUuid(value) {
  return typeof value === 'string' && UUID_PATTERN.test(value.trim());
}

export function isDeviceId(value) {
  return typeof value === 'string' && DEVICE_ID_PATTERN.test(value.trim());
}

export function isIsoTimestamp(value) {
  if (typeof value !== 'string' || !ISO_TIMESTAMP_PATTERN.test(value.trim())) return false;
  return Number.isFinite(Date.parse(value));
}

export function normalizeDeviceEventAt(value) {
  if (!isIsoTimestamp(value)) {
    throw new OperationEnvelopeError('DEVICE_EVENT_AT_INVALID', 'device_event_at must be an ISO-8601 timestamp.');
  }
  return new Date(value).toISOString();
}

/**
 * Create a v2 envelope.  `operation_id` is optional only for the first attempt;
 * once generated it is part of the returned value and must be passed back on
 * every retry/replay.  Injecting `generateOperationId` and `now` keeps this
 * function deterministic in tests without weakening production randomness.
 */
export function createOperationEnvelope(input = {}, options = {}) {
  const generateOperationId = options.generateOperationId || defaultOperationId;
  const now = options.now || defaultNow;
  const operationId = input.operation_id || input.operationId || generateOperationId();
  const contractVersion = input.contract_version ?? input.contractVersion ?? OPERATION_CONTRACT_VERSION;
  const deviceId = normalizeDeviceId(input.device_id ?? input.deviceId);
  const lodgeId = normalizeUuid(input.lodge_id ?? input.lodgeId);
  const outletValue = input.outlet_id ?? input.outletId ?? null;
  const outletId = outletValue === null || outletValue === undefined ? null : normalizeUuid(outletValue);
  const payload = clonePayload(input.payload);

  if (contractVersion !== OPERATION_CONTRACT_VERSION) {
    throw new OperationEnvelopeError('CONTRACT_VERSION_UNSUPPORTED', `Only operation contract version ${OPERATION_CONTRACT_VERSION} is supported.`);
  }
  if (!isUuid(operationId)) {
    throw new OperationEnvelopeError('OPERATION_ID_INVALID', 'operation_id must be a UUID.', { operation_id: operationId });
  }
  if (!isDeviceId(deviceId)) {
    throw new OperationEnvelopeError('DEVICE_ID_INVALID', 'device_id must be a stable non-empty identifier.', { device_id: deviceId });
  }
  if (!isUuid(lodgeId)) {
    throw new OperationEnvelopeError('LODGE_ID_INVALID', 'lodge_id must be a UUID.', { lodge_id: lodgeId });
  }
  if (outletId !== null && !isUuid(outletId)) {
    throw new OperationEnvelopeError('OUTLET_ID_INVALID', 'outlet_id must be null or a UUID.', { outlet_id: outletId });
  }

  const deviceEventAt = input.device_event_at ?? input.deviceEventAt ?? now();
  const normalizedDeviceEventAt = normalizeDeviceEventAt(deviceEventAt);
  const actorFields = [
    ...findCallerAuthorityFields(input),
    ...findCallerAuthorityFields(payload, 'payload.')
  ];
  if (actorFields.length > 0) {
    throw new OperationEnvelopeError(
      'CALLER_AUTHORITY_FIELD_FORBIDDEN',
      'Actor, role, approval, PIN, and credential fields must be derived by the server and cannot be sent in a v2 operation payload.',
      { fields: actorFields }
    );
  }

  return Object.freeze({
    contract_version: OPERATION_CONTRACT_VERSION,
    operation_id: operationId.toLowerCase(),
    device_id: deviceId,
    device_event_at: normalizedDeviceEventAt,
    lodge_id: lodgeId,
    outlet_id: outletId,
    payload
  });
}

/** Build the exact same request for a retry without allowing immutable drift. */
export function reuseOperationEnvelope(envelope, overrides = {}, options = {}) {
  const source = assertValidOperationEnvelope(envelope);
  const forbidden = ['contract_version', 'operation_id', 'device_id', 'device_event_at', 'lodge_id', 'outlet_id', 'payload']
    .filter((key) => Object.prototype.hasOwnProperty.call(overrides, key));
  if (forbidden.length > 0) {
    throw new OperationEnvelopeError('OPERATION_REUSE_IMMUTABLE', 'A replay must reuse the original operation envelope unchanged.', { fields: forbidden });
  }
  // `overrides` is accepted for forward-compatible non-authoritative metadata,
  // but no currently frozen envelope field may be changed.
  return createOperationEnvelope({
    contract_version: source.contract_version,
    operation_id: source.operation_id,
    device_id: source.device_id,
    device_event_at: source.device_event_at,
    lodge_id: source.lodge_id,
    outlet_id: source.outlet_id,
    payload: source.payload
  }, options);
}

export function validateOperationEnvelope(value) {
  const errors = [];
  if (!isPlainObject(value)) return { valid: false, errors: ['envelope must be a plain object'] };
  for (const key of Object.keys(value)) {
    if (!ENVELOPE_FIELDS.includes(key)) errors.push(`unknown field: ${key}`);
  }
  if (value.contract_version !== OPERATION_CONTRACT_VERSION) errors.push('contract_version must be 2');
  if (!isUuid(value.operation_id)) errors.push('operation_id must be a UUID');
  if (!isDeviceId(value.device_id)) errors.push('device_id is invalid');
  if (!isIsoTimestamp(value.device_event_at)) errors.push('device_event_at must be an ISO-8601 timestamp');
  if (!isUuid(value.lodge_id)) errors.push('lodge_id must be a UUID');
  if (value.outlet_id !== null && !isUuid(value.outlet_id)) errors.push('outlet_id must be null or a UUID');
  if (!isPlainObject(value.payload)) errors.push('payload must be a plain object');
  const actorFields = [
    ...findCallerAuthorityFields(value),
    ...findCallerAuthorityFields(value.payload, 'payload.')
  ];
  if (actorFields.length > 0) errors.push(`caller authority fields are forbidden: ${actorFields.join(', ')}`);
  return { valid: errors.length === 0, errors };
}

export function isOperationEnvelope(value) {
  return validateOperationEnvelope(value).valid;
}

export function assertValidOperationEnvelope(value) {
  const result = validateOperationEnvelope(value);
  if (!result.valid) {
    throw new OperationEnvelopeError('INVALID_OPERATION_ENVELOPE', result.errors.join('; '), { errors: result.errors });
  }
  return value;
}
