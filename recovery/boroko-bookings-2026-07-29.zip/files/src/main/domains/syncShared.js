import { randomUUID } from 'crypto';

export const DEAD_LETTER_AUTO_RETRY_AFTER_MS = 30 * 60 * 1000;

function createQueueOperationId(prefix = 'op') {
  return `${prefix}-${randomUUID()}`;
}

export function ensureQueuedItem(item = {}, fallbackType = 'op') {
  return {
    ...item,
    _queue_id: item._queue_id || createQueueOperationId(fallbackType)
  };
}

export function isPosCreateOrderQueueItem(item) {
  return item?.type === 'rpc' && ['create_pos_order', 'create_pos_order_v2'].includes(item?.table);
}

export function isPosSaleV2QueueItem(item) {
  return item?.type === 'rpc' && item?.table === 'create_pos_order_v2';
}

export function isPosVoidQueueItem(item) {
  return item?.type === 'rpc' && item?.table === 'approve_pos_void_with_pin';
}

export function isInventoryItemQueueItem(item) {
  return item?.type === 'rpc' && item?.table === 'create_inventory_item';
}

export function isInventoryAdjustmentQueueItem(item) {
  return item?.type === 'rpc' && ['adjust_inventory_stock', 'adjust_inventory_stock_v2'].includes(item?.table);
}

export function isInventoryPurchaseQueueItem(item) {
  return item?.type === 'rpc' && ['add_inventory_purchase', 'record_inventory_purchase_v2'].includes(item?.table);
}

export function isPosShiftQueueItem(item) {
  return item?.type === 'rpc' && ['open_pos_shift_v2', 'close_pos_shift_and_cashup_v2'].includes(item?.table);
}

export function isPosTicketQueueItem(item) {
  return item?.type === 'rpc' && ['create_pos_tickets_v2', 'status_pos_ticket_v2'].includes(item?.table);
}

export function getQueuedInventoryItemId(item) {
  const payloadId = String(item?.data?.payload?.id || '').trim();
  if (payloadId) return payloadId;

  const queueId = String(item?._queue_id || '').trim();
  if (queueId.startsWith('inventory-item-')) {
    const parsedId = queueId.slice('inventory-item-'.length).trim();
    if (parsedId) return parsedId;
  }

  console.warn('[INVENTORY SYNC] Missing item id for queue item', {
    queueId: item?._queue_id || null,
    table: item?.table || null
  });
  return null;
}

export function getQueuedDayUseEntryId(item) {
  const payloadId = String(item?.data?.payload?.id || item?.data?.p_id || '').trim();
  if (payloadId) return payloadId;

  const queueId = String(item?._queue_id || '').trim();
  for (const prefix of ['dayuse-status-', 'dayuse-']) {
    if (queueId.startsWith(prefix)) {
      const remainder = queueId.slice(prefix.length).trim();
      const parsedId = remainder.split('-status-')[0].trim();
      if (parsedId) return parsedId;
    }
  }

  return null;
}

export function getQueuedPosOrderId(item) {
  const payloadId = String(item?.data?.payload?.id || item?.data?.payload?.order_id || '').trim();
  if (payloadId) return payloadId;

  const queueId = String(item?._queue_id || '').trim();
  if (queueId.startsWith('pos-order-')) {
    const parsedId = queueId.slice('pos-order-'.length).trim();
    if (parsedId) return parsedId;
  }
  if (queueId.startsWith('pos-void-')) {
    const parsedId = queueId.slice('pos-void-'.length).trim();
    if (parsedId) return parsedId;
  }

  console.error('[POS SYNC] Missing staged order id for queue item', {
    queueId: item?._queue_id || null,
    table: item?.table || null
  });
  return null;
}

export function getSyncItemBookingId(item) {
  return item?.data?.p_booking_id ||
  item?.data?.payload?.booking_id ||
  item?.data?.payload?.id ||
  item?.data?.p_id ||
  null;
}

export function getSyncItemScope(item) {
  const bookingId = getSyncItemBookingId(item);
  if (bookingId) return `booking:${bookingId}`;
  const posOrderId = getQueuedPosOrderId(item);
  if (posOrderId) return `pos-order:${posOrderId}`;
  const dayUseEntryId = getQueuedDayUseEntryId(item);
  if (dayUseEntryId && (/pool_day_use/i.test(String(item?.table || '')) || item?._queue_id?.startsWith?.('dayuse-'))) {
    return `day-use-entry:${dayUseEntryId}`;
  }
  if (isInventoryItemQueueItem(item)) {
    const itemId = getQueuedInventoryItemId(item);
    if (itemId) return `inventory-item:${itemId}`;
  }
  if (isInventoryAdjustmentQueueItem(item)) {
    const itemId = String(item?.data?.p_item_id || '').trim();
    if (itemId) return `inventory-item:${itemId}`;
  }
  return item?.table || 'unknown';
}

export function normalizeQueuedSyncItemForReplay(item = {}) {
  if (!item) return item;
  const next = { ...item, data: { ...(item.data || {}) } };

  if (next.type === 'rpc' && ['update_booking', 'update_customer', 'update_room', 'update_quotation'].includes(next.table) && !('p_expected_updated_at' in next.data)) {
    next.data.p_expected_updated_at = null;
  }

  if (next.type === 'rpc' &&
  next.table === 'update_booking_status' &&
  String(next._depends_on || '').startsWith('booking-')) {
    next.data.p_expected_updated_at = null;
  }

  return next;
}
