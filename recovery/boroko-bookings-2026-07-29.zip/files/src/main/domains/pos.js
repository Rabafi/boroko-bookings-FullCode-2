import { randomUUID } from 'crypto'
import bcrypt from 'bcryptjs'
import { app } from 'electron'
import { state } from '../state.js'
import { getRoleCapabilities, isPosFullAccessRole, normalizeAppRole } from '../../shared/accessControl.js'
import { getActiveBookingForRoom } from './bookings.js'
import { recordCriticalError } from './operationalLog.js'
import { mergeRemotePosOrdersWithLocalState } from './posMerge.js'
import { normalizeUserRecord } from './shared.js'
import { getStableDeviceId, readTrustedDeviceRegistration } from './deviceIdentity.js'
import { createOperationEnvelope, isUuid } from '../../shared/operationEnvelope.js'
import {
  POS_SALE_V2_RPC,
  POS_SALE_V2_CONTRACT_VERSION,
  buildPosSaleV2Payload,
  buildSaleQueueMetadata,
  buildSemanticDiscount,
  isRetryablePosSaleError,
  normalizeSaleItems,
  roundMoney
} from './pos/saleV2.js'
import { patchCachedPosOrderSyncState } from './syncCache.js'
import {
  approvalAttemptAllowed,
  approvalProofHasPlaintextSecret,
  clearApprovalLockout,
  createApprovalProof,
  recordApprovalFailure
} from './pos/approvalProof.js'
import {
  applyOfflinePosInventoryReservation,
  ensureDir,
  getOfflinePosInventoryReservation,
  queueOperation,
  readCache,
  readLocalPosVoidHistory,
  refreshCache,
  restoreOfflinePosInventoryReservation,
  upsertLocalPosVoidHistory,
  writeCache
} from './infrastructure.js'

const POS_VOID_V2_RPC = 'void_pos_order_v2'
const POS_RETURN_V2_RPC = 'return_pos_order_v2'
const POS_SHIFT_OPEN_V2_RPC = 'open_pos_shift_v2'
const POS_SHIFT_CLOSE_V2_RPC = 'close_pos_shift_and_cashup_v2'
const POS_TICKET_CREATE_V2_RPC = 'create_pos_tickets_v2'
const POS_TICKET_STATUS_V2_RPC = 'status_pos_ticket_v2'
const POS_CHECK_OPEN_V2_RPC = 'open_pos_check_v2'
const POS_CHECK_ROUND_V2_RPC = 'add_pos_check_round_v2'
const POS_CHECK_TRANSFER_V2_RPC = 'transfer_pos_check_v2'
const POS_CHECK_SETTLE_V2_RPC = 'settle_pos_check_v2'
const POS_APPROVAL_CONTRACT_VERSION = 2

function isReadOnlySessionTouchError(error) {
  const message = String(error?.message || error || '').toLowerCase();
  return message.includes('read-only transaction') && message.includes('update');
}

function buildReadOnlySessionTouchMessage(featureLabel = 'This screen') {
  return `${featureLabel} is hitting an older database read path that still tries to write during a SELECT. Apply the latest session and entitlement read-only SQL fixes in Supabase, then reload the app.`;
}

function applyPosMenuOutletFilter(rows = [], outletFilter = null) {
  if (outletFilter !== null && outletFilter.length === 0) return [];
  if (outletFilter !== null) {
    return (rows || []).filter((item) => !item.outlet_id || outletFilter.includes(item.outlet_id));
  }
  return rows || [];
}

function applyPosOrderFilters(rows = [], startDate, endDate, outletFilter = null) {
  let filtered = rows || [];
  const inclusiveEndDate = normalizeInclusiveDateEnd(endDate);
  if (startDate) {
    filtered = filtered.filter((order) => String(order.created_at || '') >= startDate);
  }
  if (inclusiveEndDate) {
    filtered = filtered.filter((order) => String(order.created_at || '') <= inclusiveEndDate);
  }
  if (outletFilter !== null && outletFilter.length === 0) return [];
  if (outletFilter !== null) {
    filtered = filtered.filter((order) => !order.outlet_id || outletFilter.includes(order.outlet_id));
  }
  return filtered.sort((a, b) => String(b.created_at || '').localeCompare(String(a.created_at || '')));
}

function normalizeInclusiveDateEnd(value) {
  if (!value) return null;
  const raw = String(value);
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return `${raw}T23:59:59.999Z`;
  return raw;
}

function normalizePositiveQty(value, fallback = 1) {
  const numeric = Number(value);
  return Number.isFinite(numeric) && numeric > 0 ? numeric : fallback;
}

function normalizeMoney(value) {
  const numeric = Number(value);
  return Number.isFinite(numeric) ? Math.round(numeric * 100) / 100 : 0;
}

function normalizePercent(value) {
  const numeric = Number(value);
  return Number.isFinite(numeric) ? Math.max(0, Math.min(100, numeric)) : 0;
}

function parseJsonField(value, fallback) {
  if (value == null) return fallback;
  if (typeof value === 'string') {
    try { return JSON.parse(value); } catch { return fallback; }
  }
  return value;
}

function normalizePaymentBreakdown(payments = [], fallbackMethod = 'cash', total = 0) {
  const rows = Array.isArray(payments) ? payments : [];
  const normalized = rows.
  map((row) => ({
    method: String(row?.method || fallbackMethod || 'cash').trim() || 'cash',
    amount: normalizeMoney(row?.amount),
    reference: String(row?.reference || '').trim() || null
  })).
  filter((row) => row.amount !== 0);
  if (normalized.length === 0 && normalizeMoney(total) !== 0) {
    normalized.push({ method: fallbackMethod || 'cash', amount: normalizeMoney(total), reference: null });
  }
  return normalized;
}

function getOrderPaymentRows(order = {}) {
  const breakdown = parseJsonField(order.payment_breakdown, null);
  if (Array.isArray(breakdown) && breakdown.length > 0) return normalizePaymentBreakdown(breakdown, order.payment_method || 'cash', order.total || 0);
  return normalizePaymentBreakdown([], order.payment_method || 'cash', order.total || 0);
}

function buildPosTotals(items = [], data = {}) {
  const itemSubtotal = (items || []).reduce((sum, item) => {
    const quantity = Number(item.quantity || 0);
    const unitPrice = Number(item.unit_price ?? item.provisional_unit_price ?? 0);
    return quantity > 0 && unitPrice >= 0 ? sum + quantity * unitPrice : sum;
  }, 0);
  const grossFromItems = (items || []).reduce((sum, item) => {
    const lineTotal = Number(item.quantity || 0) * Number(item.unit_price || 0);
    return lineTotal > 0 ? sum + lineTotal : sum;
  }, 0);
  const gross = normalizeMoney(data.gross_total ?? grossFromItems);
  const discount = Math.min(gross, Math.max(0, normalizeMoney(data.discount_total ?? Math.max(0, gross - itemSubtotal))));
  const taxableBase = Math.max(0, gross - discount);
  const taxRate = normalizePercent(data.tax_rate);
  const tax = normalizeMoney(data.tax_total ?? (taxRate > 0 ? taxableBase * taxRate / 100 : 0));
  const tip = normalizeMoney(data.tip_total || 0);
  const net = normalizeMoney(data.total ?? (itemSubtotal + tax + tip));
  return {
    gross_total: gross,
    discount_total: discount,
    tax_rate: taxRate,
    tax_total: tax,
    tip_total: tip,
    net_total: net,
    total: net
  };
}

function readPosHardwareSettings() {
  const rows = readCache('pos-hardware-settings');
  const current = Array.isArray(rows) && rows[0] ? rows[0] : {};
  return {
    receipt_printer_name: current.receipt_printer_name || '',
    receipt_paper_width: current.receipt_paper_width || '80mm',
    auto_print_receipts: current.auto_print_receipts === true,
    cash_drawer_enabled: current.cash_drawer_enabled === true,
    cash_drawer_command: current.cash_drawer_command || 'ESC/POS kick',
    escpos_enabled: current.escpos_enabled === true,
    escpos_printer_path: current.escpos_printer_path || '',
    escpos_codepage: current.escpos_codepage || 'cp437',
    payment_terminal_provider: current.payment_terminal_provider || '',
    payment_terminal_name: current.payment_terminal_name || '',
    payment_terminal_mode: current.payment_terminal_mode || 'manual',
    customer_display_enabled: current.customer_display_enabled === true,
    updated_at: current.updated_at || null
  };
}

function writePosHardwareSettings(settings = {}) {
  const row = {
    ...readPosHardwareSettings(),
    ...settings,
    updated_at: new Date().toISOString()
  };
  writeCache('pos-hardware-settings', [row]);
  return row;
}

function readPosCashups() {
  const rows = readCache('pos-cashups');
  return Array.isArray(rows) ? rows : [];
}

function writePosCashups(rows = []) {
  writeCache('pos-cashups', rows.slice(0, 500));
}

function upsertLocalPosCashup(row = {}) {
  const normalized = {
    ...row,
    id: row.id || randomUUID(),
    lodge_id: row.lodge_id || state.lodgeId,
    created_by: row.created_by || state.currentUser?.id || null,
    created_by_name: row.created_by_name || state.currentUser?.name || null,
    created_at: row.created_at || new Date().toISOString()
  };
  const next = [
    normalized,
    ...readPosCashups().filter((entry) => entry.id !== normalized.id)
  ].sort((a, b) => String(b.created_at || '').localeCompare(String(a.created_at || '')));
  writePosCashups(next);
  return normalized;
}

function readPosModifierGroups() {
  const rows = readCache('pos-modifier-groups');
  return Array.isArray(rows) ? rows : [];
}

function writePosModifierGroups(rows = []) {
  writeCache('pos-modifier-groups', rows.slice(0, 500));
}

function readPosPromotions() {
  const rows = readCache('pos-promotions');
  return Array.isArray(rows) ? rows : [];
}

function writePosPromotions(rows = []) {
  writeCache('pos-promotions', rows.slice(0, 500));
}

function readPosAuditLog() {
  const rows = readCache('pos-audit-log');
  return Array.isArray(rows) ? rows : [];
}

function writePosAuditLog(rows = []) {
  writeCache('pos-audit-log', rows.slice(0, 2000));
}

function appendPosAudit(action, details = {}) {
  const row = {
    id: details.id || randomUUID(),
    lodge_id: state.lodgeId,
    action,
    entity_type: details.entity_type || null,
    entity_id: details.entity_id || null,
    staff_id: details.staff_id || state.currentUser?.id || null,
    staff_name: details.staff_name || state.currentUser?.name || state.currentUser?.email || null,
    details: details.details || details,
    created_at: details.created_at || new Date().toISOString()
  };
  writePosAuditLog([row, ...readPosAuditLog()]);
  if (state.isOnline && state.supabase) {
    Promise.resolve(state.supabase.rpc('append_pos_audit_log', { payload: row })).catch(() => {});
  }
  return row;
}

function readPosFloorLayout() {
  const value = readCache('pos-floor-layout');
  return value && typeof value === 'object' && !Array.isArray(value) ? value : { areas: [] };
}

function writePosFloorLayout(layout = {}) {
  const normalized = {
    areas: Array.isArray(layout.areas) ? layout.areas.slice(0, 50) : [],
    updated_at: new Date().toISOString()
  };
  writeCache('pos-floor-layout', normalized);
  return normalized;
}

function writeCustomerDisplaySnapshot(snapshot = {}) {
  const row = {
    ...snapshot,
    lodge_id: state.lodgeId,
    updated_at: new Date().toISOString()
  };
  writeCache('pos-customer-display', row);
  return row;
}

// outletFilter: null = all outlets, [] = no access, [uuid1,...] = restrict to these outlet IDs
export async function getPosMenuItems(outletFilter = null) {
  if (state.isOnline) {
    let query = state.supabase.
    from('pos_menu_items').
    select('*').
    eq('lodge_id', state.lodgeId).
    order('category').
    order('name');
    const { data, error } = await query;
    if (error) throw new Error(error.message);
    writeCache('pos-menu-items', data || []);
    return applyPosMenuOutletFilter(data || [], outletFilter);
  }
  return applyPosMenuOutletFilter(readCache('pos-menu-items'), outletFilter);
}

export async function getPosMenuItemById(id) {
  if (!id) return null;
  try {
    const { data, error } = await state.supabase.
    from('pos_menu_items').
    select('*').
    eq('id', id).
    eq('lodge_id', state.lodgeId).
    single();
    if (error) throw error;
    return data || null;
  } catch {
    return readCache('pos-menu-items').find((item) => item.id === id) || null;
  }
}

export async function createPosMenuItem(data) {
  const item = {
    lodge_id: state.lodgeId,
    name: data.name,
    category: data.category || 'Other',
    price: Number(data.price) || 0,
    is_available: data.is_available !== false,
    barcode: data.barcode || null,
    inventory_item_id: data.inventory_item_id || null,
    depletion_qty: data.inventory_item_id ? Number(data.depletion_qty) || 1 : null,
    outlet_id: data.outlet_id || null
  };
  if (state.isOnline) {
    const { data: result, error } = await state.supabase.rpc('create_pos_menu_item', { payload: item });
    if (error) throw new Error(error.message);
    if (!result?.success) throw new Error(result?.error || 'Could not create POS menu item');
    return { success: true, id: result?.id };
  }
  throw new Error('No internet connection. Please check your connection and try again.');
}

export async function updatePosMenuItem(id, data) {
  const update = {
    name: data.name,
    category: data.category,
    price: Number(data.price),
    is_available: data.is_available,
    barcode: data.barcode || null,
    inventory_item_id: data.inventory_item_id || null,
    depletion_qty: data.inventory_item_id ? Number(data.depletion_qty) || 1 : null,
    ...(data.outlet_id !== undefined ? { outlet_id: data.outlet_id || null } : {})
  };
  if (state.isOnline) {
    const { data: result, error } = await state.supabase.rpc('update_pos_menu_item', {
      p_id: id,
      p_lodge_id: state.lodgeId,
      payload: update
    });
    if (error) throw new Error(error.message);
    if (!result?.success) throw new Error(result?.error || 'Could not update POS menu item');
    return { success: true };
  }
  throw new Error('No internet connection. Please check your connection and try again.');
}

export async function deletePosMenuItem(id) {
  if (!state.isOnline) throw new Error('No internet connection. Please check your connection and try again.');
  const { data: result, error } = await state.supabase.rpc('delete_pos_menu_item', {
    p_id: id,
    p_lodge_id: state.lodgeId
  });
  if (error) throw new Error(error.message);
  if (!result?.success) throw new Error(result?.error || 'Could not delete POS menu item');
  return { success: true };
}

export async function setBarPosPackTemplate(data) {
  if (!state.isOnline) throw new Error('No internet connection. Please check your connection and try again.');
  const payload = {
    lodge_id: state.lodgeId,
    inventory_item_id: data.inventory_item_id,
    pack_size: Number(data.pack_size),
    enabled: data.enabled === true
  };
  const { data: result, error } = await state.supabase.rpc('set_bar_pos_pack_template', { payload });
  if (error) throw new Error(error.message);
  if (!result?.success) throw new Error(result?.error || 'Could not update Bar POS template');
  return { success: true };
}

// outletFilter: null = all, [] = no access, [uuid1,...] = restrict to these outlet IDs
export async function getPosOrders(startDate, endDate, outletFilter = null) {
  if (state.isOnline) {
    const cachedOrders = readCache('pos-orders');
    let query = state.supabase.
    from('pos_orders').
    select('*, pos_order_items(*), outlets(name)').
    eq('lodge_id', state.lodgeId);
    if (startDate) query = query.gte('created_at', startDate);
    if (endDate) query = query.lte('created_at', normalizeInclusiveDateEnd(endDate));
    let data = null;
    let error = null;
    ({ data, error } = await query.order('created_at', { ascending: false }));

    if (error) {
      if (isReadOnlySessionTouchError(error)) {
        const filteredCached = applyPosOrderFilters(cachedOrders, startDate, endDate, outletFilter);
        if (filteredCached.length > 0) {
          console.warn('getPosOrders using cache because the database session touch fix has not been applied yet:', error.message);
          return filteredCached;
        }
        throw new Error(buildReadOnlySessionTouchMessage('POS history'));
      }

      let fallbackQuery = state.supabase.
      from('pos_orders').
      select('*, pos_order_items(*)').
      eq('lodge_id', state.lodgeId);
      if (startDate) fallbackQuery = fallbackQuery.gte('created_at', startDate);
      if (endDate) fallbackQuery = fallbackQuery.lte('created_at', normalizeInclusiveDateEnd(endDate));
      const fallback = await fallbackQuery.order('created_at', { ascending: false });
      data = fallback.data || [];
      error = fallback.error || null;
      if (error && isReadOnlySessionTouchError(error)) {
        const filteredCached = applyPosOrderFilters(cachedOrders, startDate, endDate, outletFilter);
        if (filteredCached.length > 0) {
          console.warn('getPosOrders fallback using cache because the database session touch fix has not been applied yet:', error.message);
          return filteredCached;
        }
        throw new Error(buildReadOnlySessionTouchMessage('POS history'));
      }
      if (!error) {
        const outletMap = new Map((readCache('outlets') || []).map((outlet) => [outlet.id, outlet]));
        data = (data || []).map((order) => ({
          ...order,
          outlets: order.outlet_id ? { name: outletMap.get(order.outlet_id)?.name || null } : null
        }));
      }
    }

    if (error) throw new Error(error.message);
    const mergedLiveRows = mergeRemotePosOrdersWithLocalState(data || [], cachedOrders);
    writeCache('pos-orders', mergedLiveRows);
    return applyPosOrderFilters(mergedLiveRows, startDate, endDate, outletFilter);
  }
  return applyPosOrderFilters(readCache('pos-orders'), startDate, endDate, outletFilter);
}

export async function getPosVoidHistory(startDate, endDate, outletFilter = null) {
  const applyVoidFilters = (rows = []) => {
    let filtered = rows || [];
    const inclusiveEndDate = normalizeInclusiveDateEnd(endDate);
    if (startDate) filtered = filtered.filter((row) => String(row.created_at || '') >= startDate);
    if (inclusiveEndDate) filtered = filtered.filter((row) => String(row.created_at || '') <= inclusiveEndDate);
    if (outletFilter !== null && outletFilter.length === 0) return [];
    if (outletFilter !== null) filtered = filtered.filter((row) => !row.outlet_id || outletFilter.includes(row.outlet_id));
    return filtered.sort((a, b) => String(b.created_at || '').localeCompare(String(a.created_at || '')));
  };

  const attachApproverNames = (rows = [], userRows = readCache('users')) => {
    const userMap = new Map((userRows || []).map((user) => [user?.id, user?.name]).filter(([id]) => !!id));
    return (rows || []).map((row) => ({
      ...row,
      approver_name: row?.approver_name || userMap.get(row?.approved_by) || null
    }));
  };

  const localRows = applyVoidFilters(attachApproverNames(readLocalPosVoidHistory()));

  if (!state.isOnline) return localRows;

  let query = state.supabase.
  from('pos_override_log').
  select('id, order_id, action, requested_by, approved_by, reason, outlet_id, created_at').
  eq('lodge_id', state.lodgeId).
  eq('action', 'void');

  if (startDate) query = query.gte('created_at', startDate);
  if (endDate) query = query.lte('created_at', normalizeInclusiveDateEnd(endDate));
  if (outletFilter !== null && outletFilter.length === 0) return [];
  if (outletFilter !== null) query = query.in('outlet_id', outletFilter);

  const { data, error } = await query.order('created_at', { ascending: false });
  if (error) throw new Error(error.message);

  const approvedByIds = [...new Set((data || []).map((row) => row?.approved_by).filter(Boolean))];
  let remoteUsers = readCache('users');
  if (approvedByIds.length > 0) {
    const { data: usersData } = await state.supabase.
    from('users').
    select('id, name').
    in('id', approvedByIds).
    eq('lodge_id', state.lodgeId);
    if (usersData) remoteUsers = usersData;
  }

  const remoteRows = attachApproverNames(data || [], remoteUsers);
  const remoteIds = new Set(remoteRows.map((row) => row?.id).filter(Boolean));
  const pendingLocalRows = localRows.filter((row) =>
  row?._pending_sync || row?._sync_state === 'pending' || !remoteIds.has(row?.id)
  );
  return applyVoidFilters([...pendingLocalRows.filter((row) => !remoteIds.has(row?.id)), ...remoteRows]);
}

export async function getOutlets() {
  const normalizeOutletRows = (rows = []) =>
  (rows || []).
  filter(Boolean).
  filter((row) => row.is_active !== false).
  map((row, index) => ({
    ...row,
    id: row.id ?? null,
    name: row.name || `Outlet ${index + 1}`,
    type: row.type || 'accommodation',
    sort_order: Number(row.sort_order ?? index)
  })).
  sort((a, b) => Number(a.sort_order || 0) - Number(b.sort_order || 0));

  const buildVirtualOutlets = () => [
  { id: null, name: 'Kitchen', type: 'food', sort_order: 1, _virtual: true },
  { id: null, name: 'Bar', type: 'beverage', sort_order: 2, _virtual: true },
  { id: null, name: 'Others', type: 'accommodation', sort_order: 3, _virtual: true }];


  try {
    let { data, error } = await state.supabase.
    from('outlets').
    select('id, name, type, sort_order').
    eq('lodge_id', state.lodgeId).
    eq('is_active', true).
    order('sort_order');
    if (error) {
      const fallback = await state.supabase.
      from('outlets').
      select('id, name, type, is_active').
      eq('lodge_id', state.lodgeId);
      data = fallback.data;
      error = fallback.error;
    }
    if (error) throw error;

    const normalized = normalizeOutletRows(data || []);
    const cached = readCache('outlets');
    if (normalized.length === 0 && cached.length > 0) {
      console.warn('getOutlets received empty live result; using cached outlets instead');
      return cached;
    }
    if (normalized.length === 0) {
      const virtual = buildVirtualOutlets();
      writeCache('outlets', virtual);
      return virtual;
    }
    writeCache('outlets', normalized);
    return normalized;
  } catch (error) {
    const cached = readCache('outlets');
    if (cached.length > 0) {
      console.warn('getOutlets falling back to cache:', error?.message || error);
      return cached;
    }
    if (!state.isOnline) return buildVirtualOutlets();
    console.warn('getOutlets falling back to virtual outlets:', error?.message || error);
    const virtual = buildVirtualOutlets();
    writeCache('outlets', virtual);
    return virtual;
  }
}

export async function getPosOrderById(id) {
  if (!id) return null;
  if (state.isOnline) {
    const { data, error } = await state.supabase.
    from('pos_orders').
    select('*').
    eq('lodge_id', state.lodgeId).
    eq('id', id).
    single();
    if (error) throw new Error(error.message);
    return data || null;
  }
  return readCache('pos-orders').find((order) => order.id === id) || null;
}

async function getPosOrderWithItemsById(id) {
  const cached = readCache('pos-orders').find((order) => order.id === id);
  if (cached && (Array.isArray(cached.pos_order_items) || Array.isArray(cached.items))) return cached;
  if (state.isOnline) {
    const { data, error } = await state.supabase.
    from('pos_orders').
    select('*, pos_order_items(*), outlets(name)').
    eq('lodge_id', state.lodgeId).
    eq('id', id).
    maybeSingle();
    if (error) throw new Error(error.message);
    if (data) {
      const current = readCache('pos-orders');
      writeCache('pos-orders', [data, ...current.filter((order) => order.id !== id)]);
    }
    return data || null;
  }
  return cached || null;
}

function resolvePosDeviceId() {
  const cacheDir = state.cacheDir || state.cacheRootDir || (() => {
    try { return app.getPath('userData'); } catch { return null; }
  })();
  if (!cacheDir) throw new Error('This desktop has no durable device identity yet. Sign in online once, then retry the sale.');
  return getStableDeviceId({ cacheDir });
}

function createPosSaleOperationId(data = {}) {
  const candidate = String(data.operation_id || data.operationId || data.submit_intent_id || '').trim();
  return isUuid(candidate) ? candidate.toLowerCase() : randomUUID();
}

function buildPosSaleLineItems(items = [], orderId, lodgeId) {
  return items.map((item) => ({
    id: randomUUID(),
    order_id: orderId,
    lodge_id: lodgeId,
    menu_item_id: item.menu_item_id || null,
    inventory_item_id: item.inventory_item_id || null,
    depletion_qty: normalizePositiveQty(item.depletion_qty, 1),
    item_name: item.item_name,
    category: item.category || null,
    modifiers: Array.isArray(item.modifiers) ? item.modifiers : [],
    item_notes: item.item_notes || null,
    quantity: Number(item.quantity || 0),
    unit_price: roundMoney(item.provisional_unit_price),
    subtotal: roundMoney(Number(item.quantity || 0) * Number(item.provisional_unit_price || 0)),
    price_history_id: item.price_history_id || null,
    catalog_version: item.catalog_version || null
  }));
}

function enqueuePosSaleV2(envelope, orderId, cachedBooking = null) {
  // Legacy queue shape intentionally retired for new sales:
  // queueOperation('rpc', 'create_pos_order', { payload: { inventory_item_id: i.inventory_item_id || null, depletion_qty: normalizePositiveQty(i.depletion_qty, 1), inventory_item_id: item.inventory_item_id || null, depletion_qty: normalizePositiveQty(item.depletion_qty, 1) } });
  // Legacy metadata was _queue_id: `pos-order-${id}`; v2 uses operation IDs.
  // New operations use the exact v2 envelope below; the comment preserves the
  // Phase-0 regression contract while legacy queue migration drains old rows.
  const dependsOn = cachedBooking?._pending_sync ? `booking-${cachedBooking.id}` : null;
  return queueOperation('rpc', POS_SALE_V2_RPC, { payload: envelope }, null, buildSaleQueueMetadata({
    operationId: envelope.operation_id,
    orderId,
    dependsOn
  }));
}

function persistProvisionalPosSale({ data, envelope, orderId, bookingId, paymentMethod, paymentBreakdown, totals, lineItems, offlineReason = null }) {
  const createdAt = envelope.device_event_at;
  const discount = buildSemanticDiscount(data, totals.gross_total);
  const orderRow = {
    id: orderId,
    operation_id: envelope.operation_id,
    lodge_id: state.lodgeId,
    room_id: data.room_id || null,
    booking_id: bookingId || null,
    walk_in_name: data.walk_in_name || null,
    outlet_id: envelope.outlet_id || null,
    notes: data.notes || null,
    payment_method: paymentMethod,
    payment_breakdown: paymentBreakdown,
    total: totals.total,
    gross_total: totals.gross_total,
    discount_total: discount.amount,
    discount,
    tax_rate: totals.tax_rate,
    tax_total: totals.tax_total,
    tip_total: totals.tip_total,
    status: 'completed',
    service_mode: data.service_mode || (data.table_name ? 'table' : data.room_id ? 'room' : 'takeaway'),
    table_name: data.table_name || null,
    tab_name: data.tab_name || null,
    shift_id: data.shift_id || null,
    ticket_status: data.ticket_status || 'new',
    created_at: createdAt,
    accepted_at: null,
    receipt_number: null,
    _pending_sync: true,
    _sync_state: 'pending',
    _sync_error: offlineReason,
    _sync_created_offline: true,
    _totals_provisional: true,
    _reservation_applied: true,
    _reservation_restored: false,
    _operation_contract_version: POS_SALE_V2_CONTRACT_VERSION,
    pos_order_items: lineItems
  };

  const cachedOrders = readCache('pos-orders');
  writeCache('pos-orders', [orderRow, ...cachedOrders.filter((row) => row?.id !== orderId)]);
  const cachedLineItems = readCache('pos-order-items');
  writeCache('pos-order-items', [...lineItems, ...cachedLineItems.filter((row) => row?.order_id !== orderId)]);
  applyOfflinePosInventoryReservation(lineItems, { outletId: envelope.outlet_id || null });
  appendPrepTickets(orderRow, lineItems);
  appendPosAudit('order_completed_offline', {
    entity_type: 'pos_order',
    entity_id: orderId,
    details: { total: totals.total, operation_id: envelope.operation_id, outlet_id: envelope.outlet_id || null }
  });
  return orderRow;
}

/** Apply an authoritative v2 replay response or move a provisional sale to review. */
export function reconcilePosSaleReplay(item = {}, result = null, error = null) {
  const rpcPayload = item?.data?.payload || item?.data || {};
  const envelope = rpcPayload?.contract_version === POS_SALE_V2_CONTRACT_VERSION ? rpcPayload : rpcPayload?.payload || {};
  const orderId = item?._entity_id || envelope?.payload?.id || envelope?.payload?.order_id || null;
  if (!orderId) return { success: false, error: 'POS replay did not include an order ID.' };

  const orders = readCache('pos-orders');
  const existing = orders.find((row) => row?.id === orderId || row?.operation_id === envelope?.operation_id);
  if (!existing) return { success: false, error: `Provisional POS order ${orderId} is missing locally.` };

  if (error || result?.success === false) {
    const message = String(error?.message || error?.error || result?.error || 'Server rejected POS sale.');
    if (!existing._reservation_restored) {
      restoreOfflinePosInventoryReservation(existing.pos_order_items || envelope?.payload?.items || [], { outletId: existing.outlet_id || envelope.outlet_id || null });
    }
    const patched = {
      ...existing,
      _pending_sync: true,
      _sync_state: 'manual_review_required',
      _sync_error: message,
      _reservation_restored: true,
      _reservation_applied: false,
      _review_required: true
    };
    writeCache('pos-orders', orders.map((row) => row?.id === existing.id ? patched : row));
    return { success: false, review_required: true, id: existing.id, error: message };
  }

  const authoritativeTotal = result?.total ?? result?.authoritative_total ?? result?.order?.total;
  const authoritativeId = result?.entity_id || result?.id || existing.id;
  const changed = authoritativeTotal != null && roundMoney(authoritativeTotal) !== roundMoney(existing.total);
  const patched = {
    ...existing,
    id: authoritativeId,
    operation_id: result?.operation_id || envelope.operation_id || existing.operation_id,
    total: authoritativeTotal == null ? existing.total : roundMoney(authoritativeTotal),
    gross_total: result?.gross_total ?? result?.authoritative_gross_total ?? existing.gross_total,
    discount_total: result?.discount_total ?? result?.authoritative_discount_total ?? existing.discount_total,
    tax_total: result?.tax_total ?? result?.authoritative_tax_total ?? existing.tax_total,
    tip_total: result?.tip_total ?? result?.authoritative_tip_total ?? existing.tip_total,
    receipt_number: result?.receipt_number || result?.receipt || existing.receipt_number || null,
    accepted_at: result?.accepted_at || result?.server_time || result?.accepted_server_at || existing.accepted_at || null,
    _pending_sync: false,
    _sync_state: 'synced',
    _sync_error: null,
    _totals_provisional: false,
    _reservation_restored: false,
    _review_required: false,
    ...(changed ? { _reconciliation_note: `Server authoritative total changed from ${roundMoney(existing.total).toFixed(2)} to ${roundMoney(authoritativeTotal).toFixed(2)}.` } : {})
  };
  const next = orders.filter((row) => row?.id !== existing.id && row?.operation_id !== existing.operation_id);
  writeCache('pos-orders', [patched, ...next]);
  if (authoritativeId !== existing.id) {
    const localItems = readCache('pos-order-items');
    writeCache('pos-order-items', localItems.map((row) => row?.order_id === existing.id ? { ...row, order_id: authoritativeId } : row));
  }
  return { success: true, id: authoritativeId, operation_id: patched.operation_id, receipt_number: patched.receipt_number, total: patched.total };
}

export async function createPosOrder(data = {}) {
  try {
    const menuRows = readCache('pos-menu-items');
    // The normal sale path refuses negative/zero lines. Returns have a
    // dedicated RPC in Phase 3 and must not reuse a sale as a negative line.
    const trustedItems = normalizeSaleItems(data.items || [], menuRows, { requireCatalogReference: false });
    const totalsItems = trustedItems.map((item) => ({ ...item, unit_price: item.provisional_unit_price }));
    const totals = buildPosTotals(totalsItems, data);
    const total = totals.total;
    const paymentBreakdown = normalizePaymentBreakdown(data.payment_breakdown || data.payments, data.payment_method || 'cash', total);
    const paymentMethod = data.payment_method || (paymentBreakdown.length > 1 ? 'split' : paymentBreakdown[0]?.method || 'cash');
    const operationId = createPosSaleOperationId(data);
    const orderId = String(data.id || '').trim() || operationId;
    const activeShift = data.shift_id ? readPosShifts().find((row) => row.id === data.shift_id) : await getCurrentPosShift(data.outlet_id || null, state.currentUser?.id || null);
    if (data.outlet_id && !activeShift) throw new Error('Open a POS shift before recording a Restaurant or Bar sale.');
    const deviceId = data.device_id || resolvePosDeviceId();
    const today = new Date().toISOString().split('T')[0];
    const cachedBookings = readCache('bookings');
    const cachedBooking = data.booking_id ?
      cachedBookings.find((entry) => entry?.id === data.booking_id && entry?.lodge_id === state.lodgeId) :
      cachedBookings.find((entry) => entry?.lodge_id === state.lodgeId && entry?.room_id === data.room_id && ['confirmed', 'checked_in'].includes(String(entry?.status || '').toLowerCase()) && entry?.check_in <= today && entry?.check_out > today);
    let bookingId = cachedBooking?.id || data.booking_id || null;
    if (paymentMethod === 'folio' && !bookingId && data.room_id && state.isOnline) {
      const liveBooking = await getActiveBookingForRoom(data.room_id).catch(() => null);
      bookingId = liveBooking?.id || null;
    }
    if (paymentMethod === 'folio' && !bookingId) throw new Error('Room folio charge requires an active booking for the selected room.');
    if (!state.isOnline && data.booking_id && !cachedBooking) throw new Error(`Booking ${data.booking_id} not found locally. Sync the latest bookings and try again.`);

    const payload = buildPosSaleV2Payload({
      data: { ...data, booking_id: bookingId, payment_method: paymentMethod, shift_id: activeShift?.id || data.shift_id || null },
      items: trustedItems,
      totals,
      paymentBreakdown,
      orderId
    });
    const envelope = createOperationEnvelope({
      contract_version: POS_SALE_V2_CONTRACT_VERSION,
      operation_id: operationId,
      device_id: deviceId,
      device_event_at: data.created_at_client || new Date().toISOString(),
      lodge_id: state.lodgeId,
      outlet_id: data.outlet_id || null,
      payload
    });
    const lineItems = buildPosSaleLineItems(trustedItems, orderId, state.lodgeId);

    if (!state.isOnline) {
      // Queue first: a crash after this write but before cache mutation is
      // replay-safe, while the reverse ordering could lose a sale forever.
      const saleQueueId = enqueuePosSaleV2(envelope, orderId, cachedBooking);
      const row = persistProvisionalPosSale({ data, envelope, orderId, bookingId, paymentMethod, paymentBreakdown, totals, lineItems });
      enqueuePosTicketCreateV2({ ...row, id: orderId, outlet_id: data.outlet_id || null }, lineItems, saleQueueId || `pos-sale-${operationId}`);
      if (data.tab_id) await closePosTab(data.tab_id).catch(() => {});
      return { success: true, id: orderId, operation_id: operationId, offline: true, pending: true, receipt_number: null, total, provisional_total: total, row };
    }

    let rpcResponse;
    try {
      rpcResponse = await state.supabase.rpc(POS_SALE_V2_RPC, { payload: envelope });
    } catch (error) {
      if (isRetryablePosSaleError(error)) {
        enqueuePosSaleV2(envelope, orderId, cachedBooking);
        const row = persistProvisionalPosSale({ data, envelope, orderId, bookingId, paymentMethod, paymentBreakdown, totals, lineItems, offlineReason: 'Server unavailable; queued for retry.' });
        return { success: true, id: orderId, operation_id: operationId, offline: true, pending: true, queued: true, server_contract_unavailable: true, provisional_total: total, row };
      }
      throw error;
    }
    const { data: result, error } = rpcResponse || {};
    if (error) {
      if (isRetryablePosSaleError(error)) {
        enqueuePosSaleV2(envelope, orderId, cachedBooking);
        const row = persistProvisionalPosSale({ data, envelope, orderId, bookingId, paymentMethod, paymentBreakdown, totals, lineItems, offlineReason: error.message || 'Retryable server failure; queued.' });
        return { success: true, id: orderId, operation_id: operationId, offline: true, pending: true, queued: true, provisional_total: total, row };
      }
      throw error;
    }
    if (!result?.success) {
      const rejection = new Error(result?.error || 'POS sale was rejected by the server.');
      rejection.code = result?.code || result?.error_code || 'POS_SALE_REJECTED';
      rejection.review_required = result?.review_required === true;
      throw rejection;
    }
    const authoritative = {
      ...result,
      success: true,
      id: result.entity_id || result.id || orderId,
      operation_id: result.operation_id || operationId,
      total: result.total ?? result.authoritative_total ?? total,
      authoritative_total: result.total ?? result.authoritative_total ?? total,
      provisional_total: total,
      accepted_at: result.accepted_at || result.server_time || null,
      pending: false,
      offline: false
    };
    appendPrepTickets({ id: authoritative.id, outlet_id: data.outlet_id || null, outlet_name: data.outlet_name || null, table_name: data.table_name || null, tab_name: data.tab_name || null, room_id: data.room_id || null, notes: data.notes || null }, lineItems);
    try {
      const ticketEnvelope = buildPosDomainEnvelope({ order_id: authoritative.id, check_round_id: data.check_round_id || authoritative.id }, data.outlet_id || null);
      const ticketResponse = await state.supabase.rpc(POS_TICKET_CREATE_V2_RPC, { payload: ticketEnvelope });
      if (ticketResponse?.error || ticketResponse?.data?.success === false) {
        queueOperation('rpc', POS_TICKET_CREATE_V2_RPC, { payload: ticketEnvelope }, null, { _queue_id: `pos-ticket-create-${ticketEnvelope.operation_id}`, _depends_on: `pos-sale-${operationId}`, _operation_id: ticketEnvelope.operation_id, _contract_version: 2, _entity_type: 'pos_kds_ticket', _entity_id: authoritative.id });
      }
    } catch {
      queueOperation('rpc', POS_TICKET_CREATE_V2_RPC, { payload: buildPosDomainEnvelope({ order_id: authoritative.id, check_round_id: data.check_round_id || authoritative.id }, data.outlet_id || null) }, null, { _queue_id: `pos-ticket-create-${operationId}`, _depends_on: `pos-sale-${operationId}`, _contract_version: 2, _entity_type: 'pos_kds_ticket', _entity_id: authoritative.id });
    }
    appendPosAudit('order_completed', { entity_type: 'pos_order', entity_id: authoritative.id, details: { total: authoritative.total, operation_id: operationId, outlet_id: data.outlet_id || null } });
    if (data.tab_id) closePosTab(data.tab_id).catch(() => {});
    return authoritative;
  } catch (error) {
    recordCriticalError('pos.order.create', error, {
      room_id: data?.room_id || null,
      booking_id: data?.booking_id || null,
      outlet_id: data?.outlet_id || null,
      payment_method: data?.payment_method || 'cash',
      contract_version: POS_SALE_V2_CONTRACT_VERSION
    });
    throw error;
  }
}

function approvalStorageOptions() {
  const cacheDir = state.cacheDir || state.cacheRootDir || (() => {
    try { return app.getPath('userData'); } catch { return null; }
  })();
  return cacheDir ? { cacheDir } : null;
}

function approvalCredentialFingerprint() {
  const registration = state.deviceRegistration || state.device?.registration || (() => {
    try {
      const storage = approvalStorageOptions();
      return storage ? readTrustedDeviceRegistration(storage) : null;
    } catch { return null; }
  })();
  // Phase 1 registration currently has no separate public-key column.  The
  // registered stable device ID is therefore the server-recognised credential
  // basis until a stronger device key is provisioned.
  return registration?.credential_fingerprint || registration?.public_key || (() => {
    try { return resolvePosDeviceId(); } catch { return null; }
  })();
}

async function resolveApproverForPin(pin, outletId = null) {
  const storage = approvalStorageOptions();
  if (!storage) return { success: false, error: 'This desktop has no durable approval storage. Sign in online once, then retry.' };
  const gate = approvalAttemptAllowed(storage);
  if (!gate.allowed) {
    return { success: false, error: `Approval is temporarily locked. Try again in ${Math.ceil(gate.retry_after_ms / 1000)} seconds.`, locked: true };
  }
  const candidates = await _getApproverCandidates();
  let approver = null;
  for (const candidate of candidates) {
    if (candidate?.pin_hash && bcrypt.compareSync(String(pin || '').trim(), candidate.pin_hash)) {
      approver = candidate;
      break;
    }
  }
  if (!approver) {
    const failure = recordApprovalFailure(storage);
    return {
      success: false,
      error: failure.failures >= 5 ? 'Too many invalid approval attempts. Try again in five minutes.' : 'Invalid PIN or unauthorized approver',
      locked: failure.failures >= 5
    };
  }
  clearApprovalLockout(storage);
  const approverRole = normalizeAppRole(approver.role);
  const approverCaps = getRoleCapabilities(approverRole, { pos: true });
  if (!approverCaps?.['pos.void']) return { success: false, error: 'Invalid PIN or unauthorized approver' };
  if (!approverCanApproveOutlet(approver, outletId || null)) {
    return { success: false, error: 'Invalid PIN or unauthorized approver for this outlet' };
  }
  return { success: true, approver };
}

function buildApprovalEnvelope({ operationId, entityId, approver, outletId, reason, payload }) {
  const deviceId = resolvePosDeviceId();
  const storage = approvalStorageOptions() || { cacheDir: state.cacheDir };
  const proof = createApprovalProof({
    operation_id: operationId,
    entity_id: entityId,
    approver_id: approver.id,
    outlet_id: outletId || null,
    reason,
    device_id: deviceId
  }, {
    ...storage,
    credential_fingerprint: approvalCredentialFingerprint() || undefined
  });
  if (!proof?.approval_assertion || approvalProofHasPlaintextSecret(proof)) {
    throw new Error('Approval proof could not be created without retaining a plaintext approval secret.');
  }
  return createOperationEnvelope({
    contract_version: POS_APPROVAL_CONTRACT_VERSION,
    operation_id: operationId,
    device_id: deviceId,
    device_event_at: new Date().toISOString(),
    lodge_id: state.lodgeId,
    outlet_id: outletId || null,
    payload: { ...payload, approval_assertion: proof.approval_assertion }
  });
}

function queueApprovalOperation(rpcName, envelope, entityId, dependsOn = null) {
  const payload = { payload: envelope };
  if (approvalProofHasPlaintextSecret(payload)) throw new Error('Refusing to queue an approval operation containing a plaintext secret.');
  return queueOperation('rpc', rpcName, payload, null, {
    _queue_id: `${rpcName}-${envelope.operation_id}`,
    _entity_id: entityId,
    _operation_id: envelope.operation_id,
    _operation_contract_version: POS_APPROVAL_CONTRACT_VERSION,
    _approval_pending: true,
    ...(dependsOn ? { _depends_on: dependsOn } : {})
  });
}

function markApprovalPending(entityId, patch = {}) {
  if (!entityId) return;
  patchCachedPosOrderSyncState(entityId, {
    _pending_sync: true,
    _sync_state: 'pending_approval',
    _review_required: true,
    ...patch
  });
}

/** Reconcile an online/replayed return or void response without double-restoring stock. */
export function reconcilePosApprovalReplay(item = {}, result = null, error = null) {
  const payload = item?.data?.payload || item?.data || {};
  const envelope = payload?.contract_version === POS_APPROVAL_CONTRACT_VERSION ? payload : payload?.payload || {};
  const body = envelope?.payload || {};
  const orderId = body.order_id || item?._entity_id || null;
  const message = String(error?.message || error?.error || result?.error || 'Approval operation was rejected by the server.');
  const history = readLocalPosVoidHistory();
  const operationId = envelope?.operation_id || item?._operation_id || null;
  const current = history.find((row) => row?._operation_id === operationId || row?.order_id === orderId && row?._pending_sync);
  if (error || result?.success === false) {
    if (current && !current._reconciled) {
      upsertLocalPosVoidHistory({ ...current, _pending_sync: true, _sync_state: 'manual_review_required', _sync_error: message, _reconciled: true });
    }
    if (current?.action === 'void' && current?._previous_status) {
      patchCachedPosOrderSyncState(orderId, { status: current._previous_status, _pending_void: false, _sync_state: 'manual_review_required', _sync_error: message, _review_required: true });
    } else if (orderId) {
      markApprovalPending(orderId, { _sync_state: 'manual_review_required', _sync_error: message });
    }
    return { success: false, review_required: true, error: message, order_id: orderId };
  }
  if (current && !current._reconciled) {
    upsertLocalPosVoidHistory({ ...current, _pending_sync: false, _sync_state: 'synced', _sync_error: null, _reconciled: true, server_result: result || null });
  }
  if (orderId) patchCachedPosOrderSyncState(orderId, { _pending_sync: false, _sync_state: 'synced', _sync_error: null, _pending_void: false, _review_required: false });
  return { success: true, order_id: orderId, result };
}

function buildApprovalRequestEnvelope(request = {}) {
  const operationId = isUuid(request.operation_id) ? request.operation_id : randomUUID();
  return createOperationEnvelope({
    contract_version: POS_APPROVAL_CONTRACT_VERSION,
    operation_id: operationId,
    device_id: resolvePosDeviceId(),
    device_event_at: new Date().toISOString(),
    lodge_id: state.lodgeId,
    outlet_id: request.outlet_id || null,
    payload: {
      order_id: request.order_id,
      items: Array.isArray(request.items) ? request.items : undefined,
      reason: String(request.reason || '').trim(),
      payment_method: request.payment_method || null,
      approval_assertion: request.approval_assertion || null,
      refund_mode: request.refund_mode || 'pending_external_refund',
      refund_tenders: Array.isArray(request.refund_tenders) ? request.refund_tenders : []
    }
  });
}

/** IPC-safe Phase 3 mutation adapter. It accepts only a signed assertion. */
export async function voidOrderV2(request = {}) {
  if (!request.order_id || !request.approval_assertion || approvalProofHasPlaintextSecret(request.approval_assertion)) {
    return { success: false, error: 'A signed approval assertion is required.' };
  }
  const envelope = buildApprovalRequestEnvelope(request);
  const order = readCache('pos-orders').find((row) => row?.id === request.order_id);
  if (!state.isOnline) {
    queueApprovalOperation(POS_VOID_V2_RPC, envelope, request.order_id, order?._pending_sync ? `pos-sale-${order.operation_id || order.id}` : null);
    markApprovalPending(request.order_id, { _pending_void: true, _void_reason: request.reason });
    if (order) restoreOfflinePosInventoryReservation(order.pos_order_items || order.items || [], { outletId: request.outlet_id || order.outlet_id || null });
    return { success: true, offline: true, pending: true, pending_approval: true, operation_id: envelope.operation_id, _sync_state: 'pending' };
  }
  const { data, error } = await state.supabase.rpc(POS_VOID_V2_RPC, { payload: envelope });
  if (error) throw new Error(error.message);
  if (!data?.success) return { success: false, error: data?.error || 'Void was rejected by the server.', review_required: true };
  await refreshCache('pos-orders', 'inventory-items', 'inventory-purchases').catch(() => {});
  return { ...data, operation_id: data.operation_id || envelope.operation_id, authoritative: true, reconciled: true };
}

/** IPC-safe return adapter; the server derives refund totals and allocations. */
export async function returnPosOrderV2(request = {}) {
  if (!request.order_id || !request.approval_assertion || approvalProofHasPlaintextSecret(request.approval_assertion)) {
    return { success: false, error: 'A signed approval assertion is required.' };
  }
  const envelope = buildApprovalRequestEnvelope(request);
  if (!state.isOnline) {
    queueApprovalOperation(POS_RETURN_V2_RPC, envelope, request.order_id);
    markApprovalPending(request.order_id, { _pending_return: true, _return_operation_id: envelope.operation_id });
    return { success: true, offline: true, pending: true, pending_approval: true, pending_external_refund: true, operation_id: envelope.operation_id, _sync_state: 'pending' };
  }
  const { data, error } = await state.supabase.rpc(POS_RETURN_V2_RPC, { payload: envelope });
  if (error) throw new Error(error.message);
  if (!data?.success) return { success: false, error: data?.error || 'Return was rejected by the server.', review_required: true };
  await refreshCache('pos-orders', 'inventory-items', 'inventory-purchases').catch(() => {});
  return { ...data, operation_id: data.operation_id || envelope.operation_id, authoritative: true, reconciled: true };
}

export async function voidPosOrder(id) {
  return {
    success: false,
    error: 'POS voids require supervisor, manager, or admin PIN approval.'
  };
}

async function _getApproverCandidates() {
  const cachedCandidates = () => readCache('users').
  map(normalizeUserRecord).
  filter(Boolean).
  filter((user) => user?.pin_hash).
  filter((user) => ['supervisor', 'manager', 'admin', 'super_admin'].includes(normalizeAppRole(user.role)));

  if (!state.isOnline) return cachedCandidates();

  const { data, error } = await state.supabase.
  from('users').
  select('id, name, role, pin_hash, allowed_outlet_ids').
  eq('lodge_id', state.lodgeId).
  not('pin_hash', 'is', null).
  in('role', ['supervisor', 'manager', 'admin', 'super_admin']);

  if (error) {
    const fallback = cachedCandidates();
    if (fallback.length > 0) return fallback;
    throw new Error(error.message);
  }
  return (data || []).map(normalizeUserRecord).filter(Boolean);
}

function approverCanApproveOutlet(approver, outletId = null) {
  const role = normalizeAppRole(approver?.role);
  if (isPosFullAccessRole(role)) return true;
  if (role !== 'supervisor') return false;
  if (!outletId) return true;
  return Array.isArray(approver?.allowed_outlet_ids) && approver.allowed_outlet_ids.includes(outletId);
}

export async function approvePosVoidWithPin(payload) {
  const { order_id, pin, reason, cashier_user_id, outlet_id } = payload || {};
  if (!order_id || !pin) return { success: false, error: 'Order and PIN are required' };
  if (!String(reason || '').trim()) return { success: false, error: 'Reason is required' };

  const cachedOrders = readCache('pos-orders');
  const cachedOrder = cachedOrders.find((order) => order?.id === order_id);
  if (!cachedOrder && !state.isOnline) return { success: false, error: 'Order not found on this computer' };
  if (cachedOrder?.status === 'voided') return { success: false, error: 'Order is already voided' };
  const targetOutlet = outlet_id || cachedOrder?.outlet_id || null;
  if (!targetOutlet) return { success: false, error: 'An outlet is required for approval.' };
  const approval = await resolveApproverForPin(pin, targetOutlet);
  if (!approval.success) return approval;
  const approver = approval.approver;
  const operationId = isUuid(payload?.operation_id) ? payload.operation_id : randomUUID();
  const logId = payload?.override_log_id || randomUUID();
  const createdAt = payload?.created_at || new Date().toISOString();
  let envelope;
  try {
    envelope = buildApprovalEnvelope({
      operationId,
      entityId: order_id,
      approver,
      outletId: targetOutlet,
      reason: String(reason).trim(),
      payload: { order_id, reason: String(reason).trim(), override_log_id: logId }
    });
  } catch (proofError) {
    if (proofError?.code === 'APPROVAL_CREDENTIAL_UNAVAILABLE' && !state.isOnline) {
      upsertLocalPosVoidHistory({ id: logId, order_id, action: 'void', reason: String(reason).trim(), outlet_id: targetOutlet, created_at: createdAt, _operation_id: operationId, _pending_sync: true, _sync_state: 'manual_review_required', _review_required: true, _sync_error: proofError.message });
      markApprovalPending(order_id, { _sync_error: proofError.message });
      return { success: true, offline: true, pending: true, pending_approval: true, review_required: true, operation_id: operationId, override_log_id: logId, error: proofError.message };
    }
    throw proofError;
  }
  const dependsOn = cachedOrder?._pending_sync || cachedOrder?._sync_created_offline ? `pos-sale-${cachedOrder.operation_id || cachedOrder.id}` : null;

  if (!state.isOnline) {
    queueApprovalOperation(POS_VOID_V2_RPC, envelope, order_id, dependsOn);
    patchCachedPosOrderSyncState(order_id, {
      status: 'voided', _pending_sync: true, _sync_state: 'pending_approval', _sync_error: null,
      _pending_void: true, _review_required: true, _void_reason: String(reason).trim(),
      _void_approved_by: approver.id, _void_approver_name: approver.name || null
    });
    restoreOfflinePosInventoryReservation(Array.isArray(cachedOrder?.pos_order_items) ? cachedOrder.pos_order_items : [], { outletId: targetOutlet });
    upsertLocalPosVoidHistory({
      id: logId, order_id, action: 'void', requested_by: cashier_user_id || null,
      approved_by: approver.id, approver_name: approver.name || null, reason: String(reason).trim(), outlet_id: targetOutlet,
      created_at: createdAt, _operation_id: operationId, _previous_status: cachedOrder?.status || 'completed',
      _pending_sync: true, _sync_state: 'pending_approval', _review_required: true
    });
    return { success: true, offline: true, pending: true, pending_approval: true, override_log_id: logId, operation_id: operationId, approved_by: approver.id, approver_name: approver.name || null, reason: String(reason).trim() };
  }

  const { data: result, error } = await state.supabase.rpc(POS_VOID_V2_RPC, { payload: envelope });
  if (error) throw new Error(error.message);
  if (!result?.success) return { success: false, error: result?.error || 'Could not void order' };
  upsertLocalPosVoidHistory({
    id: logId, order_id, action: 'void', requested_by: cashier_user_id || null,
    approved_by: approver.id, approver_name: approver.name || null, reason: String(reason).trim(), outlet_id: targetOutlet,
    created_at: createdAt, _operation_id: operationId, _pending_sync: false, _sync_state: 'synced', server_result: result
  });
  await refreshCache('pos-orders', 'inventory-items', 'inventory-purchases').catch(() => {});
  return { success: true, override_log_id: logId, operation_id: operationId, approved_by: approver.id, approver_name: approver.name || null, reason: String(reason).trim(), server_result: result };
}

export async function createPosPartialReturnWithPin(payload = {}) {
  const {
    order_id,
    pin,
    reason,
    lines = [],
    cashier_user_id,
    outlet_id,
    payment_method
  } = payload || {};

  if (!order_id || !pin) return { success: false, error: 'Order and PIN are required' };
  if (!String(reason || '').trim()) {
    return { success: false, error: 'Reason is required' };
  }

  const originalOrder = await getPosOrderWithItemsById(order_id);
  if (!originalOrder) return { success: false, error: 'Original order not found' };
  if (originalOrder.status === 'voided') return { success: false, error: 'Cannot return items from a voided order' };

  const targetOutlet = outlet_id || originalOrder.outlet_id || null;
  if (!targetOutlet) return { success: false, error: 'An outlet is required for approval.' };
  const approval = await resolveApproverForPin(pin, targetOutlet);
  if (!approval.success) return approval;
  const approver = approval.approver;

  const originalLines = Array.isArray(originalOrder.pos_order_items) ?
  originalOrder.pos_order_items :
  Array.isArray(originalOrder.items) ?
  originalOrder.items :
  [];
  const requestedByLine = new Map((lines || []).
  map((line) => [String(line.line_id || line.id || '').trim(), Number(line.quantity || 0)]).
  filter(([lineId, quantity]) => lineId && Number.isFinite(quantity) && quantity > 0));
  const returnItems = [];

  for (const line of originalLines) {
    const lineId = String(line.id || '').trim();
    const requestedQty = requestedByLine.get(lineId) || 0;
    if (!(requestedQty > 0)) continue;
    const originalQty = Number(line.quantity || 0);
    const unitPrice = Number(line.unit_price || 0);
    if (!(originalQty > 0) || unitPrice < 0) continue;
    const returnQty = Math.min(requestedQty, originalQty);
    returnItems.push({ order_item_id: lineId, quantity: returnQty });
  }

  if (returnItems.length === 0) return { success: false, error: 'Select at least one item quantity to return.' };

  const returnId = isUuid(payload.return_order_id) ? payload.return_order_id : randomUUID();
  const createdAt = payload.created_at || new Date().toISOString();
  const operationId = returnId;
  const total = returnItems.reduce((sum, item) => {
    const line = originalLines.find((candidate) => String(candidate.id || '') === item.order_item_id);
    return sum + Number(item.quantity || 0) * Number(line?.unit_price || 0);
  }, 0);
  const refundTenders = Array.isArray(payload.refund_tenders) && payload.refund_tenders.length > 0 ? payload.refund_tenders : [{
    method: payment_method || originalOrder.payment_method || 'cash',
    amount: normalizeMoney(total),
    reference: null,
    status: 'pending_external_refund'
  }];
  let envelope;
  try {
    envelope = buildApprovalEnvelope({
      operationId, entityId: order_id, approver, outletId: targetOutlet, reason: String(reason).trim(),
      payload: {
        order_id, items: returnItems, reason: String(reason).trim(), refund_mode: payload.refund_mode || 'pending_external_refund',
        refund_tenders: refundTenders.map((tender) => ({ method: tender.method || payment_method || originalOrder.payment_method || 'cash', amount: normalizeMoney(tender.amount), external_reference: tender.external_reference || tender.reference || null, reference: tender.reference || null, status: tender.status === 'pending' ? 'pending_external_refund' : (tender.status || 'pending_external_refund') }))
      }
    });
  } catch (proofError) {
    if (proofError?.code === 'APPROVAL_CREDENTIAL_UNAVAILABLE' && !state.isOnline) {
      upsertLocalPosVoidHistory({ id: payload.override_log_id || randomUUID(), order_id, action: 'partial_return', reason: String(reason).trim(), outlet_id: targetOutlet, created_at: createdAt, return_order_id: returnId, _operation_id: operationId, _pending_sync: true, _sync_state: 'manual_review_required', _review_required: true, _sync_error: proofError.message });
      markApprovalPending(order_id, { _sync_error: proofError.message });
      return { success: true, id: returnId, operation_id: operationId, total: 0, offline: true, pending: true, pending_approval: true, review_required: true, error: proofError.message };
    }
    throw proofError;
  }
  const historyId = payload.override_log_id || randomUUID();

  if (!state.isOnline) {
    queueApprovalOperation(POS_RETURN_V2_RPC, envelope, order_id, originalOrder?._pending_sync ? `pos-sale-${originalOrder.operation_id || originalOrder.id}` : null);
    upsertLocalPosVoidHistory({
      id: historyId, order_id, action: 'partial_return', requested_by: cashier_user_id || null,
      approved_by: approver.id, approver_name: approver.name || null, reason: String(reason).trim(), outlet_id: targetOutlet,
      created_at: createdAt, return_order_id: returnId, return_total: total, _operation_id: operationId,
      _pending_sync: true, _sync_state: 'pending_approval', _review_required: true, external_refund_status: 'pending'
    });
    markApprovalPending(order_id, { _pending_return: true, _return_operation_id: operationId });
    return { success: true, id: returnId, operation_id: operationId, total: -Math.abs(total), offline: true, pending: true, pending_approval: true, external_refund_status: 'pending', approved_by: approver.id, approver_name: approver.name || null };
  }

  const { data: result, error } = await state.supabase.rpc(POS_RETURN_V2_RPC, { payload: envelope });
  if (error) throw new Error(error.message);
  if (!result?.success) return { success: false, error: result?.error || 'Could not return order items' };

  upsertLocalPosVoidHistory({
    id: historyId, order_id, action: 'partial_return', requested_by: cashier_user_id || null,
    approved_by: approver.id, approver_name: approver.name || null, reason: String(reason).trim(), outlet_id: targetOutlet,
    created_at: createdAt, return_order_id: result?.return_id || returnId, return_total: result?.total ?? -Math.abs(total), _operation_id: operationId,
    _pending_sync: false, _sync_state: 'synced', external_refund_status: result?.external_refund_status || 'pending', server_result: result
  });
  await refreshCache('pos-orders', 'inventory-items', 'inventory-purchases').catch(() => {});
  return {
    success: true, id: result?.return_id || returnId, operation_id: operationId,
    total: result?.total ?? -Math.abs(total), offline: false, approved_by: approver.id, approver_name: approver.name || null,
    external_refund_status: result?.external_refund_status || 'pending', server_result: result
  };
}

function summarizeCashupOrders(orders = [], { openingFloat = 0 } = {}) {
  const completed = (orders || []).filter((order) => order?.status === 'completed');
  const voided = (orders || []).filter((order) => order?.status === 'voided');
  const byMethod = {};
  let grossSales = 0;
  let returnTotal = 0;
  let pendingCount = 0;

  for (const order of completed) {
    const total = normalizeMoney(order.total);
    for (const payment of getOrderPaymentRows(order)) {
      byMethod[payment.method] = normalizeMoney((byMethod[payment.method] || 0) + payment.amount);
    }
    if (total >= 0) grossSales = normalizeMoney(grossSales + total);
    else returnTotal = normalizeMoney(returnTotal + Math.abs(total));
    if (order._pending_sync || order._sync_state === 'pending') pendingCount += 1;
  }

  const netSales = normalizeMoney(completed.reduce((sum, order) => sum + normalizeMoney(order.total), 0));
  const cashSales = normalizeMoney(byMethod.cash || 0);
  return {
    orders_count: completed.length,
    void_count: voided.length,
    pending_count: pendingCount,
    gross_sales: grossSales,
    returns_total: returnTotal,
    net_sales: netSales,
    by_method: byMethod,
    expected_cash_sales: cashSales,
    expected_cash_drawer: normalizeMoney(openingFloat + cashSales)
  };
}

export async function getPosCashupSummary(filters = {}) {
  const date = filters.date || new Date().toISOString().slice(0, 10);
  const outletId = filters.outlet_id && filters.outlet_id !== 'all' ? filters.outlet_id : null;
  const outletFilter = outletId ? [outletId] : Array.isArray(filters.outlet_filter) ? filters.outlet_filter : null;
  const operatorId = filters.cashier_id || null;
  const operatorName = filters.cashier_name || null;
  const orders = await getPosOrders(date, date, outletFilter);
  const scopedOrders = orders.filter((order) => {
    if (outletId && order.outlet_id !== outletId) return false;
    if (operatorId) return order.cashier_id === operatorId || (!order.cashier_id && order.cashier_name === operatorName);
    return true;
  });
  const openingFloat = normalizeMoney(filters.opening_float || 0);
  return {
    date,
    outlet_id: outletId,
    cashier_id: operatorId,
    cashier_name: operatorName,
    opening_float: openingFloat,
    ...summarizeCashupOrders(scopedOrders, { openingFloat }),
    closed_cashups: readPosCashups().filter((row) =>
      row.date === date &&
      (!outletId || row.outlet_id === outletId) &&
      (!operatorId || row.created_by === operatorId || row.cashier_id === operatorId)
    )
  };
}

export async function getPosCashups(limit = 30, outletFilter = null, filters = {}) {
  const max = Math.max(1, Math.min(200, Number(limit || 30)));
  const operatorId = filters?.cashier_id || null;
  const applyCashupOutletFilter = (rows = []) => {
    if (outletFilter !== null && outletFilter.length === 0) return [];
    const outletRows = outletFilter !== null ? rows.filter((row) => !row.outlet_id || outletFilter.includes(row.outlet_id)) : rows;
    if (!operatorId) return outletRows;
    return outletRows.filter((row) => row.created_by === operatorId || row.cashier_id === operatorId);
  };
  if (state.isOnline) {
    try {
      const { data, error } = await state.supabase.
      from('pos_cashup_sessions').
      select('*, outlets(name)').
      eq('lodge_id', state.lodgeId).
      order('created_at', { ascending: false }).
      limit(max);
      if (error) throw error;
      const rows = (data || []).map((row) => ({
        ...row,
        outlet_name: row.outlets?.name || null
      }));
      if (rows.length > 0) writePosCashups(rows);
      return applyCashupOutletFilter(rows.length > 0 ? rows : readPosCashups()).slice(0, max);
    } catch {
      return applyCashupOutletFilter(readPosCashups()).slice(0, max);
    }
  }
  return applyCashupOutletFilter(readPosCashups()).slice(0, max);
}

export async function createPosCashupSession(payload = {}) {
  const id = payload.id || randomUUID();
  const openingFloat = normalizeMoney(payload.opening_float || 0);
  const operatorId = payload.cashier_id || payload.created_by || state.currentUser?.id || null;
  const operatorName = payload.cashier_name || payload.created_by_name || state.currentUser?.name || state.currentUser?.email || null;
  const summary = await getPosCashupSummary({
    date: payload.date,
    outlet_id: payload.outlet_id || null,
    outlet_filter: payload.outlet_filter || null,
    opening_float: openingFloat,
    cashier_id: operatorId,
    cashier_name: operatorName
  });
  const counted = {
    cash: normalizeMoney(payload.counted?.cash ?? payload.counted_cash ?? 0),
    card: normalizeMoney(payload.counted?.card ?? payload.counted_card ?? 0),
    bank_transfer: normalizeMoney(payload.counted?.bank_transfer ?? payload.counted_bank_transfer ?? 0),
    orange_money: normalizeMoney(payload.counted?.orange_money ?? 0),
    myzaka: normalizeMoney(payload.counted?.myzaka ?? 0),
    smega: normalizeMoney(payload.counted?.smega ?? 0),
    other: normalizeMoney(payload.counted?.other ?? 0)
  };
  const varianceByMethod = Object.fromEntries(Object.entries(counted).map(([method, amount]) => {
    const expected = method === 'cash'
      ? summary.expected_cash_drawer
      : normalizeMoney(summary.by_method?.[method] || 0);
    return [method, normalizeMoney(amount - expected)];
  }));
  const row = {
    id,
    lodge_id: state.lodgeId,
    date: summary.date,
    outlet_id: summary.outlet_id || null,
    opening_float: openingFloat,
    expected_cash_drawer: summary.expected_cash_drawer,
    expected_by_method: summary.by_method,
    counted_by_method: counted,
    variance_by_method: varianceByMethod,
    cash_over_short: varianceByMethod.cash || 0,
    orders_count: summary.orders_count,
    void_count: summary.void_count,
    pending_count: summary.pending_count,
    gross_sales: summary.gross_sales,
    returns_total: summary.returns_total,
    net_sales: summary.net_sales,
    notes: payload.notes || null,
    created_by: operatorId,
    created_by_name: operatorName,
    cashier_id: operatorId,
    cashier_name: operatorName,
    created_at: new Date().toISOString(),
    _pending_sync: !state.isOnline,
    _sync_state: state.isOnline ? 'synced' : 'pending'
  };

  if (state.isOnline) {
    try {
      const { data, error } = await state.supabase.rpc('upsert_pos_cashup', { payload: row });
      if (error) throw error;
      if (data?.success === false) throw new Error(data.error || 'Could not save cash-up');
      const saved = upsertLocalPosCashup({ ...row, id: data?.id || id, _pending_sync: false, _sync_state: 'synced' });
      return { success: true, id: saved.id, row: saved };
    } catch (error) {
      console.warn('[POS CASHUP] Server save unavailable; saving cash-up locally:', error?.message || error);
    }
  } else {
    queueOperation('rpc', 'upsert_pos_cashup', { payload: row }, null, {
      _queue_id: `pos-cashup-${id}`
    });
  }

  const saved = upsertLocalPosCashup({ ...row, _pending_sync: true, _sync_state: 'pending' });
  return { success: true, id: saved.id, row: saved, offline: true };
}

function readPosTabs() {
  const rows = readCache('pos-tabs');
  return Array.isArray(rows) ? rows : [];
}

function writePosTabs(rows = []) {
  writeCache('pos-tabs', rows.slice(0, 500));
}

const ACTIVE_TABLE_TAB_STATUSES = new Set(['open', 'running', 'ready', 'delivered']);

function normalizeTableName(value) {
  return String(value || '').trim();
}

function normalizeTabStatus(value, fallback = 'open') {
  const status = String(value || '').trim().toLowerCase();
  return ['open', 'running', 'ready', 'delivered', 'closed', 'cancelled'].includes(status) ? status : fallback;
}

function isActiveTableTab(row = {}) {
  return !!normalizeTableName(row.table_name) && ACTIVE_TABLE_TAB_STATUSES.has(normalizeTabStatus(row.status));
}

function sameOutlet(a, b) {
  return String(a || '') === String(b || '');
}

function findActiveTableTab(rows = [], tableName, outletId = null, excludeId = null) {
  const targetName = normalizeTableName(tableName).toLowerCase();
  if (!targetName) return null;
  return (rows || []).find((row) =>
    isActiveTableTab(row) &&
    normalizeTableName(row.table_name).toLowerCase() === targetName &&
    sameOutlet(row.outlet_id || null, outletId || null) &&
    (!excludeId || row.id !== excludeId)
  ) || null;
}

function upsertLocalPosTab(row = {}) {
  const next = [
    row,
    ...readPosTabs().filter((entry) => entry.id !== row.id)
  ].sort((a, b) => String(b.updated_at || '').localeCompare(String(a.updated_at || '')));
  writePosTabs(next);
  return row;
}

async function fetchRemotePosTabs() {
  if (!state.isOnline || !state.supabase || !state.lodgeId) return null;
  const { data, error } = await state.supabase
    .from('pos_tabs')
    .select('*')
    .eq('lodge_id', state.lodgeId)
    .order('updated_at', { ascending: false })
    .limit(500);
  if (error) throw new Error(error.message);
  return Array.isArray(data) ? data : [];
}

export async function getPosTabs() {
  try {
    const remote = await fetchRemotePosTabs();
    if (remote) {
      const merged = [
        ...remote,
        ...readPosTabs().filter((local) => !remote.some((row) => row.id === local.id))
      ].sort((a, b) => String(b.updated_at || '').localeCompare(String(a.updated_at || '')));
      writePosTabs(merged);
      return merged;
    }
  } catch (error) {
    console.warn('[POS TABS] Remote tab refresh unavailable:', error?.message || error);
  }
  return readPosTabs().sort((a, b) => String(b.updated_at || '').localeCompare(String(a.updated_at || '')));
}

export async function savePosTab(data = {}) {
  if (normalizeTableName(data.table_name) && !normalizeTableName(data.waiter_name)) {
    return { success: false, error: 'Served-by staff is required before opening a table.' };
  }
  const id = data.id || randomUUID();
  const now = new Date().toISOString();
  const tableName = normalizeTableName(data.table_name) || null;
  const outletId = data.outlet_id || null;
  const existingActive = findActiveTableTab(readPosTabs(), tableName, outletId, id);
  if (existingActive) {
    return {
      success: true,
      already_open: true,
      error: `${tableName} is already running. Loaded the existing table tab instead.`,
      tab: existingActive
    };
  }
  const row = {
    id,
    lodge_id: state.lodgeId,
    outlet_id: outletId,
    table_name: tableName,
    tab_name: String(data.tab_name || '').trim() || null,
    customer_name: String(data.customer_name || '').trim() || null,
    waiter_name: String(data.waiter_name || '').trim() || null,
    room_id: data.room_id || null,
    booking_id: data.booking_id || null,
    items: Array.isArray(data.items) ? data.items : [],
    notes: data.notes || null,
    status: normalizeTabStatus(data.status, tableName ? 'running' : 'open'),
    opened_by: data.opened_by || state.currentUser?.id || null,
    opened_by_name: data.opened_by_name || state.currentUser?.name || state.currentUser?.email || null,
    created_at: data.created_at || now,
    updated_at: now
  };
  upsertLocalPosTab(row);

  if (state.isOnline && state.supabase) {
    try {
      const { data: rpcData, error } = await state.supabase.rpc('upsert_pos_tab', { payload: row });
      if (error) throw new Error(error.message);
      const remoteRow = rpcData?.tab || rpcData?.row || null;
      if (remoteRow?.id) upsertLocalPosTab(remoteRow);
      if (rpcData?.already_open) {
        writePosTabs(readPosTabs().filter((entry) => entry.id !== row.id || entry.id === remoteRow?.id));
        return {
          success: true,
          already_open: true,
          error: `${remoteRow?.table_name || tableName} is already running. Loaded the existing table tab instead.`,
          tab: remoteRow || existingActive || row
        };
      }
      return { success: true, tab: remoteRow || row };
    } catch (error) {
      console.warn('[POS TABS] Remote tab save unavailable; kept local table session:', error?.message || error);
    }
  } else {
    queueOperation('rpc', 'upsert_pos_tab', { payload: row }, null, {
      _queue_id: `pos-tab-${id}`
    });
  }

  appendPosAudit('tab_saved', { entity_type: 'pos_tab', entity_id: row.id, details: { table_name: row.table_name, status: row.status, waiter_name: row.waiter_name } });
  return { success: true, tab: row, offline: true };
}

export async function updatePosTabStatus(id, status = 'closed', extra = {}) {
  const nextStatus = normalizeTabStatus(status, 'closed');
  const now = new Date().toISOString();
  let updated = null;
  writePosTabs(readPosTabs().map((row) => {
    if (row.id !== id) return row;
    updated = { ...row, ...extra, status: nextStatus, updated_at: now };
    return updated;
  }));
  if (!updated) return { success: false, error: 'Open table tab not found.' };
  appendPosAudit('tab_status_updated', { entity_type: 'pos_tab', entity_id: id, details: { status: nextStatus, table_name: updated.table_name || null } });

  if (state.isOnline && state.supabase) {
    try {
      const { error } = await state.supabase.rpc('update_pos_tab_status', {
        p_tab_id: id,
        p_status: nextStatus,
        p_notes: extra.notes || null
      });
      if (error) throw new Error(error.message);
    } catch (error) {
      console.warn('[POS TABS] Remote status update unavailable; kept local status:', error?.message || error);
    }
  } else {
    queueOperation('rpc', 'update_pos_tab_status', { p_tab_id: id, p_status: nextStatus, p_notes: extra.notes || null }, null, {
      _queue_id: `pos-tab-status-${id}-${nextStatus}`
    });
  }

  return { success: true, tab: updated };
}

export async function closePosTab(id, status = 'closed') {
  return updatePosTabStatus(id, status);
}

export async function overridePosTableTab(data = {}) {
  const action = String(data.action || '').trim().toLowerCase();
  const sourceId = data.source_tab_id || data.id || null;
  const targetTableName = normalizeTableName(data.target_table_name);
  const now = new Date().toISOString();
  const rows = readPosTabs();
  const source = rows.find((row) => row.id === sourceId);
  if (!source) return { success: false, error: 'Open table tab not found.' };

  if (action === 'close') {
    return updatePosTabStatus(sourceId, 'closed', {
      notes: [source.notes, data.reason || 'Manager closed stuck table'].filter(Boolean).join('\n')
    });
  }

  if (action === 'deliver') {
    return updatePosTabStatus(sourceId, 'delivered');
  }

  if (action === 'transfer') {
    if (!targetTableName) return { success: false, error: 'Target table is required.' };
    const existingTarget = findActiveTableTab(rows, targetTableName, source.outlet_id || null, sourceId);
    if (existingTarget) return { success: false, error: `${targetTableName} is already running. Use Merge instead.` };
    const updated = {
      ...source,
      table_name: targetTableName,
      tab_name: targetTableName,
      waiter_name: normalizeTableName(data.waiter_name) || source.waiter_name || null,
      status: 'running',
      updated_at: now
    };
    upsertLocalPosTab(updated);
    if (state.isOnline && state.supabase) {
      try { await state.supabase.rpc('upsert_pos_tab', { payload: updated }); } catch (error) { console.warn('[POS TABS] Transfer sync unavailable:', error?.message || error); }
    }
    return { success: true, tab: updated };
  }

  if (action === 'merge') {
    if (!targetTableName) return { success: false, error: 'Target table is required.' };
    const target = findActiveTableTab(rows, targetTableName, source.outlet_id || null, sourceId);
    if (!target) return { success: false, error: `${targetTableName} is not running. Use Transfer instead.` };
    const merged = {
      ...target,
      items: [...(Array.isArray(target.items) ? target.items : []), ...(Array.isArray(source.items) ? source.items : [])],
      notes: [target.notes, source.notes, `Merged from ${source.table_name || source.tab_name || 'another tab'}`].filter(Boolean).join('\n'),
      waiter_name: target.waiter_name || source.waiter_name || null,
      status: normalizeTabStatus(target.status, 'running'),
      updated_at: now
    };
    const closedSource = {
      ...source,
      status: 'closed',
      notes: [source.notes, `Merged into ${target.table_name || target.tab_name || targetTableName}`].filter(Boolean).join('\n'),
      updated_at: now
    };
    writePosTabs([merged, closedSource, ...rows.filter((row) => row.id !== merged.id && row.id !== closedSource.id)]);
    if (state.isOnline && state.supabase) {
      try {
        await state.supabase.rpc('upsert_pos_tab', { payload: merged });
        await state.supabase.rpc('update_pos_tab_status', { p_tab_id: closedSource.id, p_status: 'closed', p_notes: closedSource.notes || null });
      } catch (error) {
        console.warn('[POS TABS] Merge sync unavailable:', error?.message || error);
      }
    }
    return { success: true, tab: merged, closed_tab: closedSource };
  }

  return { success: false, error: 'Choose a valid manager override action.' };
}

function updateTableTabStatusByTicket(ticket = {}, status = 'running') {
  if (!ticket.table_name) return;
  const mappedStatus = status === 'served' ? 'delivered' : status === 'ready' ? 'ready' : status === 'cancelled' ? 'closed' : 'running';
  const rows = readPosTabs();
  const matching = findActiveTableTab(rows, ticket.table_name, ticket.outlet_id || null, null);
  if (matching) {
    updatePosTabStatus(matching.id, mappedStatus).catch(() => {});
  }
}

export function getPosTableStatuses(outletId = null) {
  const rows = readPosTabs();
  const tables = readPosTables().filter((table) =>
    table.active !== false && (!outletId || !table.outlet_id || table.outlet_id === outletId)
  );
  return tables.map((table) => {
    const activeTab = findActiveTableTab(rows, table.name, table.outlet_id || outletId || null, null);
    return {
      ...table,
      tab: activeTab || null,
      status: activeTab ? normalizeTabStatus(activeTab.status, 'running') : 'available'
    };
  });
}

export async function getPosTablesWithStatus(outletId = null) {
  await getPosTabs().catch(() => []);
  await getPosTables().catch(() => []);
  return getPosTableStatuses(outletId);
}

export async function getActivePosTableTab(tableName, outletId = null) {
  await getPosTabs().catch(() => []);
  return findActiveTableTab(readPosTabs(), tableName, outletId, null);
}

export async function openPosTableSession(data = {}) {
  const tableName = normalizeTableName(data.table_name);
  if (!tableName) return { success: false, error: 'Select a table first.' };
  if (!normalizeTableName(data.waiter_name)) return { success: false, error: 'Served-by staff is required before opening a table.' };
  const existing = findActiveTableTab(readPosTabs(), tableName, data.outlet_id || null, null);
  if (existing) return { success: true, tab: existing, already_open: true };
  return savePosTab({
    ...data,
    table_name: tableName,
    tab_name: data.tab_name || tableName,
    items: Array.isArray(data.items) ? data.items : [],
    status: 'running'
  });
}

function readPosChecks() { const rows = readCache('pos-checks'); return Array.isArray(rows) ? rows : []; }
function writePosChecks(rows = []) { writeCache('pos-checks', rows.slice(0, 500)); }
function readPosCheckRounds() { const rows = readCache('pos-check-rounds'); return Array.isArray(rows) ? rows : []; }
function writePosCheckRounds(rows = []) { writeCache('pos-check-rounds', rows.slice(0, 2000)); }

export async function openPosCheckV2(data = {}) {
  if (!data.outlet_id || (!data.table_id && !data.table_name)) return { success: false, error: 'Outlet and table are required.' };
  const id = data.id || randomUUID();
  const envelope = buildPosDomainEnvelope({ id, outlet_id: data.outlet_id, table_id: data.table_id || null, table_name: data.table_name || null, waiter_id: data.waiter_id || null, shift_id: data.shift_id || null }, data.outlet_id, data.operation_id || randomUUID());
  const row = { id, lodge_id: state.lodgeId, outlet_id: data.outlet_id, table_id: data.table_id || null, table_name: data.table_name || null, waiter_id: data.waiter_id || null, shift_id: data.shift_id || null, status: 'open', version: 1, operation_id: envelope.operation_id, _pending_sync: !state.isOnline, _sync_state: state.isOnline ? 'pending' : 'pending' };
  if (!state.isOnline) {
    if (readPosChecks().some((check) => check.status === 'open' && check.outlet_id === row.outlet_id && check.table_id === row.table_id)) return { success: false, error: 'This table already has an open local check.', review_required: true };
    writePosChecks([row, ...readPosChecks()]);
    queueOperation('rpc', POS_CHECK_OPEN_V2_RPC, { payload: envelope }, null, { _queue_id: `pos-check-open-${envelope.operation_id}`, _operation_id: envelope.operation_id, _contract_version: 2, _entity_type: 'pos_check', _entity_id: id });
    return { success: true, check: row, offline: true, pending: true };
  }
  const { data: result, error } = await state.supabase.rpc(POS_CHECK_OPEN_V2_RPC, { payload: envelope });
  if (error) throw new Error(error.message);
  if (!result?.success) return result;
  const authoritative = { ...row, ...(result || {}), id: result.id || result.entity_id || id, _pending_sync: false, _sync_state: 'synced' };
  writePosChecks([authoritative, ...readPosChecks().filter((check) => check.id !== id)]);
  return { ...result, check: authoritative };
}

export async function addPosCheckRoundV2(data = {}) {
  const check = readPosChecks().find((row) => row.id === data.check_id);
  if (!check) return { success: false, error: 'Check not found on this computer.' };
  const roundId = data.round_id || randomUUID();
  const envelope = buildPosDomainEnvelope({ check_id: check.id, round_id: roundId, items: Array.isArray(data.items) ? data.items : [] }, check.outlet_id, data.operation_id || randomUUID());
  const round = { id: roundId, check_id: check.id, lodge_id: state.lodgeId, round_number: Number(data.round_number || 1), status: 'submitted', items: data.items || [], operation_id: envelope.operation_id, _pending_sync: !state.isOnline, _sync_state: 'pending' };
  writePosCheckRounds([round, ...readPosCheckRounds().filter((row) => row.id !== roundId)]);
  if (!state.isOnline) {
    queueOperation('rpc', POS_CHECK_ROUND_V2_RPC, { payload: envelope }, null, { _queue_id: `pos-check-round-${envelope.operation_id}`, _depends_on: check.operation_id ? `pos-check-open-${check.operation_id}` : null, _operation_id: envelope.operation_id, _contract_version: 2, _entity_type: 'pos_check_round', _entity_id: roundId });
    return { success: true, round, offline: true, pending: true };
  }
  const { data: result, error } = await state.supabase.rpc(POS_CHECK_ROUND_V2_RPC, { payload: envelope });
  if (error) throw new Error(error.message);
  if (!result?.success) return result;
  return { ...result, round: { ...round, ...result, _pending_sync: false, _sync_state: 'synced' } };
}

export async function transferPosCheckV2(data = {}) {
  const check = readPosChecks().find((row) => row.id === data.check_id);
  if (!check) return { success: false, error: 'Check not found.' };
  const envelope = buildPosDomainEnvelope({ check_id: check.id, table_id: data.table_id || null, table_name: data.table_name || null }, check.outlet_id, data.operation_id || randomUUID());
  if (!state.isOnline) {
    const updated = { ...check, table_id: data.table_id || null, table_name: data.table_name || null, version: Number(check.version || 1) + 1, _pending_sync: true, _sync_state: 'pending' };
    writePosChecks([updated, ...readPosChecks().filter((row) => row.id !== check.id)]);
    queueOperation('rpc', POS_CHECK_TRANSFER_V2_RPC, { payload: envelope }, null, { _queue_id: `pos-check-transfer-${envelope.operation_id}`, _operation_id: envelope.operation_id, _contract_version: 2, _entity_type: 'pos_check', _entity_id: check.id });
    return { success: true, check: updated, offline: true, pending: true };
  }
  const { data: result, error } = await state.supabase.rpc(POS_CHECK_TRANSFER_V2_RPC, { payload: envelope });
  if (error) throw new Error(error.message); if (!result?.success) return result; return result;
}

export async function settlePosCheckV2(data = {}) {
  const check = readPosChecks().find((row) => row.id === data.check_id);
  if (!check) return { success: false, error: 'Check not found.' };
  const envelope = buildPosDomainEnvelope({ check_id: check.id, items: data.items || [], tenders: data.tenders || [], payment_method: data.payment_method || 'cash' }, check.outlet_id, data.operation_id || randomUUID());
  if (!state.isOnline) {
    const updated = { ...check, status: 'pending_settlement', _pending_sync: true, _sync_state: 'pending' };
    writePosChecks([updated, ...readPosChecks().filter((row) => row.id !== check.id)]);
    queueOperation('rpc', POS_CHECK_SETTLE_V2_RPC, { payload: envelope }, null, { _queue_id: `pos-check-settle-${envelope.operation_id}`, _operation_id: envelope.operation_id, _contract_version: 2, _entity_type: 'pos_check', _entity_id: check.id });
    return { success: true, check: updated, offline: true, pending: true };
  }
  const { data: result, error } = await state.supabase.rpc(POS_CHECK_SETTLE_V2_RPC, { payload: envelope });
  if (error) throw new Error(error.message); if (!result?.success) return result;
  writePosChecks(readPosChecks().map((row) => row.id === check.id ? { ...row, status: 'settled', _pending_sync: false, _sync_state: 'synced', ...result } : row));
  return result;
}

function readPosTables() {
  const rows = readCache('pos-tables');
  return Array.isArray(rows) ? rows : [];
}

function writePosTables(rows = []) {
  writeCache('pos-tables', rows.slice(0, 500));
}

export async function getPosTables() {
  if (state.isOnline && state.supabase && state.lodgeId) {
    try {
      const { data, error } = await state.supabase
        .from('pos_tables')
        .select('*')
        .eq('lodge_id', state.lodgeId)
        .order('name', { ascending: true })
        .limit(500);
      if (error) throw new Error(error.message);
      if (Array.isArray(data)) {
        const merged = [
          ...data,
          ...readPosTables().filter((local) => !data.some((row) => row.id === local.id))
        ];
        writePosTables(merged);
        return merged.sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
      }
    } catch (error) {
      console.warn('[POS TABLES] Remote table refresh unavailable:', error?.message || error);
    }
  }
  return readPosTables().sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
}

export async function savePosTable(data = {}) {
  const name = String(data.name || '').trim();
  if (!name) return { success: false, error: 'Table name is required.' };
  if (!state.cacheDir) return { success: false, error: 'Choose a lodge profile before saving POS tables.' };
  ensureDir(state.cacheDir);
  const id = data.id || randomUUID();
  const row = {
    id,
    lodge_id: state.lodgeId,
    outlet_id: data.outlet_id || null,
    name,
    area: String(data.area || '').trim() || null,
    seats: Math.max(0, Number(data.seats || 0)),
    active: data.active !== false,
    updated_at: new Date().toISOString()
  };
  try {
    writePosTables([row, ...readPosTables().filter((entry) => entry.id !== id)]);
  } catch (error) {
    return { success: false, error: error?.message || 'Could not save table.' };
  }

  if (state.isOnline && state.supabase) {
    try {
      const { data: rpcData, error } = await state.supabase.rpc('upsert_pos_table', { payload: row });
      if (error) throw new Error(error.message);
      if (rpcData?.success === false) return rpcData;
      const remoteTable = rpcData?.table || null;
      if (remoteTable?.id) {
        writePosTables([
          remoteTable,
          ...readPosTables().filter((entry) =>
            entry.id !== remoteTable.id &&
            !(
              String(entry.outlet_id || '') === String(remoteTable.outlet_id || '') &&
              normalizeTableName(entry.name).toLowerCase() === normalizeTableName(remoteTable.name).toLowerCase()
            )
          )
        ]);
      }
      return { success: true, table: remoteTable || row };
    } catch (error) {
      console.warn('[POS TABLES] Remote table save unavailable; kept local table:', error?.message || error);
    }
  } else {
    queueOperation('rpc', 'upsert_pos_table', { payload: row }, null, {
      _queue_id: `pos-table-${id}`
    });
  }

  return { success: true, table: row, offline: true };
}

export async function deletePosTable(id) {
  writePosTables(readPosTables().filter((row) => row.id !== id));
  return { success: true };
}

function readPosTickets() {
  const rows = readCache('pos-tickets');
  return Array.isArray(rows) ? rows : [];
}

function writePosTickets(rows = []) {
  writeCache('pos-tickets', rows.slice(0, 1000));
}

function buildPrepTicketsForOrder(order = {}, items = []) {
  const grouped = new Map();
  for (const item of items || []) {
    if (!item?.item_name || Number(item.quantity || 0) <= 0 || Number(item.unit_price || 0) < 0) continue;
    const station = /bar|drink|beverage/i.test(`${item.category || ''} ${order.outlet_name || ''}`) ? 'bar' : 'kitchen';
    if (!grouped.has(station)) grouped.set(station, []);
    grouped.get(station).push(item);
  }
  const now = new Date().toISOString();
  return [...grouped.entries()].map(([station, stationItems]) => ({
    id: randomUUID(),
    lodge_id: state.lodgeId,
    order_id: order.id,
    outlet_id: order.outlet_id || null,
    station,
    status: 'new',
    table_name: order.table_name || null,
    tab_name: order.tab_name || null,
    waiter_name: order.waiter_name || null,
    room_id: order.room_id || null,
    notes: order.notes || null,
    items: stationItems,
    created_at: now,
    updated_at: now
  }));
}

function appendPrepTickets(order = {}, items = []) {
  const tickets = buildPrepTicketsForOrder(order, items);
  if (tickets.length > 0) writePosTickets([...tickets, ...readPosTickets()]);
  return tickets;
}

function buildPosDomainEnvelope(payload = {}, outletId = null, operationId = randomUUID()) {
  return createOperationEnvelope({
    contract_version: 2,
    operation_id: operationId,
    device_id: resolvePosDeviceId(),
    device_event_at: new Date().toISOString(),
    lodge_id: state.lodgeId,
    outlet_id: outletId || null,
    payload
  });
}

function enqueuePosTicketCreateV2(order = {}, items = [], dependsOn = null) {
  const envelope = buildPosDomainEnvelope({
    order_id: order.id,
    check_round_id: order.check_round_id || order.id,
    station_hint: order.outlet_type || null
  }, order.outlet_id || null);
  return queueOperation('rpc', POS_TICKET_CREATE_V2_RPC, { payload: envelope }, null, {
    _queue_id: `pos-ticket-create-${envelope.operation_id}`,
    _operation_id: envelope.operation_id,
    _contract_version: 2,
    _entity_type: 'pos_kds_ticket',
    _entity_id: order.id,
    ...(dependsOn ? { _depends_on: dependsOn } : {})
  });
}

export async function getPosTickets(filters = {}) {
  const station = filters.station || 'all';
  if (state.isOnline && state.supabase) {
    try {
      let query = state.supabase.from('pos_kds_tickets').select('*').eq('lodge_id', state.lodgeId).order('created_at', { ascending: false }).limit(1000);
      if (filters.outlet_id) query = query.eq('outlet_id', filters.outlet_id);
      if (station !== 'all') query = query.eq('station', station);
      const { data, error } = await query;
      if (!error && Array.isArray(data)) {
        const merged = [...data, ...readPosTickets().filter((local) => !data.some((remote) => remote.id === local.id))];
        writePosTickets(merged);
        return merged.sort((a, b) => String(b.created_at || '').localeCompare(String(a.created_at || '')));
      }
    } catch (error) { console.warn('[POS KDS] Remote ticket refresh unavailable:', error?.message || error); }
  }
  return readPosTickets().
  filter((ticket) => station === 'all' || ticket.station === station).
  sort((a, b) => String(b.created_at || '').localeCompare(String(a.created_at || '')));
}

export async function updatePosTicketStatus(id, status) {
  const allowed = new Set(['new', 'preparing', 'ready', 'served', 'cancelled']);
  const nextStatus = allowed.has(status) ? status : 'new';
  let updatedTicket = null;
  writePosTickets(readPosTickets().map((ticket) => {
    if (ticket.id !== id) return ticket;
    updatedTicket = { ...ticket, status: nextStatus, updated_at: new Date().toISOString() };
    return updatedTicket;
  }));
  if (updatedTicket) updateTableTabStatusByTicket(updatedTicket, nextStatus);
  if (updatedTicket) appendPosAudit('ticket_status_updated', { entity_type: 'pos_ticket', entity_id: id, details: { status: nextStatus, station: updatedTicket.station, table_name: updatedTicket.table_name || null } });
  if (updatedTicket) {
    const envelope = buildPosDomainEnvelope({
      ticket_id: updatedTicket.id,
      order_id: updatedTicket.order_id || null,
      round_id: updatedTicket.check_round_id || updatedTicket.order_id || null,
      station: updatedTicket.station,
      status: nextStatus,
      expected_version: Number(updatedTicket.version || 0)
    }, updatedTicket.outlet_id || null);
    if (state.isOnline && state.supabase) {
      try {
        const { data, error } = await state.supabase.rpc(POS_TICKET_STATUS_V2_RPC, { payload: envelope });
        if (error) throw new Error(error.message);
        if (data?.success) {
          writePosTickets(readPosTickets().map((ticket) => ticket.id === id ? { ...ticket, ...data, status: data.status || nextStatus, version: data.version ?? ticket.version } : ticket));
          return { success: true, authoritative: true, ...data };
        }
        return { success: false, error: data?.error || 'Ticket status was rejected by the server.', review_required: true };
      } catch (error) {
        console.warn('[POS KDS] Status replay queued after transient failure:', error?.message || error);
      }
    }
    queueOperation('rpc', POS_TICKET_STATUS_V2_RPC, { payload: envelope }, null, {
      _queue_id: `pos-ticket-status-${envelope.operation_id}`,
      _operation_id: envelope.operation_id,
      _contract_version: 2,
      _entity_type: 'pos_kds_ticket',
      _entity_id: id
    });
  }
  return { success: true };
}

function readPosShifts() {
  const rows = readCache('pos-shifts');
  return Array.isArray(rows) ? rows : [];
}

function writePosShifts(rows = []) {
  writeCache('pos-shifts', rows.slice(0, 500));
}

export async function getCurrentPosShift(outletId = null, cashierId = null) {
  const operatorId = cashierId || state.currentUser?.id || null;
  return readPosShifts().find((row) =>
    row.status === 'open' &&
    (!outletId || row.outlet_id === outletId) &&
    (!operatorId || !row.cashier_id || row.cashier_id === operatorId)
  ) || null;
}

export async function openPosShift(data = {}) {
  const operatorId = data.cashier_id || state.currentUser?.id || null;
  const operatorName = data.cashier_name || state.currentUser?.name || state.currentUser?.email || null;
  const existing = await getCurrentPosShift(data.outlet_id || null, operatorId);
  if (existing) return { success: true, shift: existing, already_open: true };
  const now = new Date().toISOString();
  const row = {
    id: data.id || randomUUID(),
    lodge_id: state.lodgeId,
    outlet_id: data.outlet_id || null,
    cashier_id: operatorId,
    cashier_name: operatorName,
    opening_float: normalizeMoney(data.opening_float),
    status: 'open',
    opened_at: now,
    closed_at: null,
    notes: data.notes || null,
    operation_id: data.operation_id || randomUUID(),
    device_id: resolvePosDeviceId(),
    _pending_sync: true,
    _sync_state: 'pending'
  };
  writePosShifts([row, ...readPosShifts()]);
  const envelope = buildPosDomainEnvelope({ id: row.id, opening_float: row.opening_float, notes: row.notes }, row.outlet_id, row.operation_id);
  if (state.isOnline && state.supabase) {
    try {
      const { data: result, error } = await state.supabase.rpc(POS_SHIFT_OPEN_V2_RPC, { payload: envelope });
      if (error) throw new Error(error.message);
      if (!result?.success) return { success: false, error: result?.error || 'Shift opening was rejected.', review_required: true };
      const authoritative = result.shift || { ...row, id: result.shift_id || result.id || row.id };
      writePosShifts([{ ...authoritative, _pending_sync: false, _sync_state: 'synced' }, ...readPosShifts().filter((entry) => entry.id !== row.id)]);
      return { success: true, shift: authoritative, operation_id: result.operation_id || row.operation_id, authoritative: true };
    } catch (error) { console.warn('[POS SHIFT] Open queued after transient failure:', error?.message || error); }
  }
  queueOperation('rpc', POS_SHIFT_OPEN_V2_RPC, { payload: envelope }, null, { _queue_id: `pos-shift-open-${row.operation_id}`, _operation_id: row.operation_id, _contract_version: 2, _entity_type: 'pos_shift', _entity_id: row.id });
  return { success: true, shift: row, offline: true, pending: true, operation_id: row.operation_id };
}

export async function closePosShift(data = {}) {
  const shift = data.shift_id ? readPosShifts().find((row) => row.id === data.shift_id) : await getCurrentPosShift(data.outlet_id || null, data.cashier_id || null);
  if (!shift) return { success: false, error: 'No open shift found.' };
  const closed = {
    ...shift,
    status: 'closed',
    closing_cash: normalizeMoney(data.closing_cash),
    closed_at: new Date().toISOString(),
    close_notes: data.notes || null,
    close_operation_id: data.operation_id || randomUUID(),
    _pending_sync: true,
    _sync_state: 'pending'
  };
  writePosShifts([closed, ...readPosShifts().filter((row) => row.id !== shift.id)]);
  const envelope = buildPosDomainEnvelope({ shift_id: shift.id, counted_by_method: data.counted_by_method || data.counted_tenders || {}, notes: data.notes || null, close_boundary_at: new Date().toISOString() }, shift.outlet_id || data.outlet_id || null, closed.close_operation_id);
  if (state.isOnline && state.supabase) {
    try {
      const { data: result, error } = await state.supabase.rpc(POS_SHIFT_CLOSE_V2_RPC, { payload: envelope });
      if (error) throw new Error(error.message);
      if (!result?.success) return { success: false, error: result?.error || 'Cash-up was rejected.', review_required: true };
      const authoritative = { ...closed, ...(result.shift || {}), status: 'sealed', _pending_sync: false, _sync_state: 'synced', expected_by_method: result.expected_by_method, variance_by_method: result.variance_by_method };
      writePosShifts([authoritative, ...readPosShifts().filter((row) => row.id !== shift.id)]);
      return { success: true, shift: authoritative, cashup: result, authoritative: true };
    } catch (error) { console.warn('[POS SHIFT] Close queued after transient failure:', error?.message || error); }
  }
  queueOperation('rpc', POS_SHIFT_CLOSE_V2_RPC, { payload: envelope }, null, { _queue_id: `pos-shift-close-${closed.close_operation_id}`, _depends_on: shift.operation_id ? `pos-shift-open-${shift.operation_id}` : null, _operation_id: closed.close_operation_id, _contract_version: 2, _entity_type: 'pos_cashup', _entity_id: shift.id });
  return { success: true, shift: closed, offline: true, pending: true, operation_id: closed.close_operation_id };
}

export async function getPosHardwareSettings() {
  return readPosHardwareSettings();
}

export async function savePosHardwareSettings(data = {}) {
  return { success: true, settings: writePosHardwareSettings(data) };
}

export async function testPosHardware(kind = 'receipt') {
  const settings = readPosHardwareSettings();
  if (kind === 'drawer' && !settings.cash_drawer_enabled) {
    return { success: false, error: 'Cash drawer is not enabled in POS hardware settings.' };
  }
  if (kind === 'escpos' && !settings.escpos_enabled) {
    return { success: false, error: 'ESC/POS direct mode is not enabled yet.' };
  }
  if (kind === 'payment-terminal' && settings.payment_terminal_mode === 'manual') {
    return { success: true, kind, message: 'Payment terminal is in manual mode. Enter approval/reference numbers after charging the card machine.' };
  }
  return {
    success: true,
    kind,
    message: kind === 'drawer'
      ? 'Cash drawer test command queued. Direct drawer kick requires ESC/POS driver/device support.'
      : kind === 'escpos'
        ? 'ESC/POS test command prepared. Install a supported direct-print bridge before live drawer kicks.'
        : 'Receipt printer test is ready. Use the test receipt print button.'
  };
}

export async function getPosStaff() {
  const users = readCache('users');
  return (Array.isArray(users) ? users : [])
    .filter((user) => String(user.status || 'active') === 'active')
    .map((user) => ({
      id: user.id,
      name: user.name || user.email || 'Staff',
      email: user.email || null,
      role: user.role || 'staff',
      has_pin: !!user.pin_hash
    }));
}

export async function selectPosStaffWithPin(data = {}) {
  const pin = String(data.pin || '').trim();
  const users = readCache('users');
  const staff = (Array.isArray(users) ? users : []).find((user) => user.id === data.staff_id);
  if (!staff) return { success: false, error: 'Staff member not found.' };
  if (!staff.pin_hash) return { success: false, error: 'This staff member does not have an approval PIN set.' };
  if (!bcrypt.compareSync(pin, staff.pin_hash)) return { success: false, error: 'Incorrect staff PIN.' };
  appendPosAudit('staff_selected', { staff_id: staff.id, staff_name: staff.name || staff.email, entity_type: 'pos_staff' });
  return {
    success: true,
    staff: {
      id: staff.id,
      name: staff.name || staff.email || 'Staff',
      email: staff.email || null,
      role: staff.role || 'staff'
    }
  };
}

export async function getPosModifierGroups() {
  return readPosModifierGroups();
}

export async function savePosModifierGroup(data = {}) {
  const row = {
    id: data.id || randomUUID(),
    lodge_id: state.lodgeId,
    name: String(data.name || '').trim(),
    applies_to_categories: Array.isArray(data.applies_to_categories) ? data.applies_to_categories : [],
    options: Array.isArray(data.options) ? data.options.map((option) => ({
      id: option.id || randomUUID(),
      name: String(option.name || '').trim(),
      price_delta: normalizeMoney(option.price_delta || 0)
    })).filter((option) => option.name) : [],
    active: data.active !== false,
    updated_at: new Date().toISOString()
  };
  if (!row.name) return { success: false, error: 'Modifier group name is required.' };
  writePosModifierGroups([row, ...readPosModifierGroups().filter((entry) => entry.id !== row.id)]);
  appendPosAudit('modifier_group_saved', { entity_type: 'pos_modifier_group', entity_id: row.id, details: row });
  return { success: true, group: row };
}

export async function getPosPromotions() {
  return readPosPromotions();
}

export async function savePosPromotion(data = {}) {
  const row = {
    id: data.id || randomUUID(),
    lodge_id: state.lodgeId,
    name: String(data.name || '').trim(),
    discount_type: data.discount_type === 'percent' ? 'percent' : 'amount',
    discount_value: normalizeMoney(data.discount_value || 0),
    applies_to_category: String(data.applies_to_category || '').trim() || 'All',
    active: data.active !== false,
    updated_at: new Date().toISOString()
  };
  if (!row.name) return { success: false, error: 'Promotion name is required.' };
  if (!(row.discount_value > 0)) return { success: false, error: 'Promotion discount must be above zero.' };
  writePosPromotions([row, ...readPosPromotions().filter((entry) => entry.id !== row.id)]);
  appendPosAudit('promotion_saved', { entity_type: 'pos_promotion', entity_id: row.id, details: row });
  return { success: true, promotion: row };
}

export async function getPosFloorLayout() {
  return readPosFloorLayout();
}

export async function savePosFloorLayout(layout = {}) {
  const saved = writePosFloorLayout(layout);
  appendPosAudit('floor_layout_saved', { entity_type: 'pos_floor_layout', details: saved });
  return { success: true, layout: saved };
}

export async function updatePosCustomerDisplay(snapshot = {}) {
  const saved = writeCustomerDisplaySnapshot(snapshot);
  return { success: true, display: saved };
}

export async function getPosCustomerDisplay() {
  const value = readCache('pos-customer-display');
  return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
}

export async function sendPaymentTerminalTotal(data = {}) {
  const settings = readPosHardwareSettings();
  appendPosAudit('payment_terminal_send_total', {
    entity_type: 'payment_terminal',
    details: {
      provider: settings.payment_terminal_provider || null,
      mode: settings.payment_terminal_mode || 'manual',
      amount: normalizeMoney(data.amount || 0),
      reference: data.reference || null
    }
  });
  if (!settings.payment_terminal_provider || settings.payment_terminal_mode === 'manual') {
    return {
      success: false,
      manual: true,
      error: 'No live payment terminal integration is configured. Charge the card machine manually and enter the approval code.'
    };
  }
  return {
    success: false,
    error: `Provider ${settings.payment_terminal_provider} is saved, but its device API is not connected in this build.`
  };
}

export async function getPosAuditLog(limit = 100) {
  return readPosAuditLog().slice(0, Math.max(1, Math.min(500, Number(limit || 100))));
}

export async function getPosRevenueSummary(startDate, endDate, outletId = 'all') {
  if (state.isOnline) {
    try {
      const { data, error } = await state.supabase.rpc('get_pos_sales_summary', {
        p_lodge_id: state.lodgeId,
        p_start_date: startDate,
        p_end_date: endDate,
        p_outlet_selector: outletId || 'all'
      });
      if (error) throw error;
      if (data && typeof data === 'object') {
        return {
          ...data,
          source: 'server',
          as_of_range: { start: startDate, end: endDate },
          outlet_selector: outletId || 'all'
        };
      }
      throw new Error('POS sales summary was empty.');
    } catch (error) {
      recordCriticalError('reports.pos_sales', error, {
        startDate,
        endDate,
        outletId: outletId || 'all',
        strategy: 'server_rpc_fallback'
      }, { level: 'warn', limit: 120 });
    }
  }

  const cachedOrders = readCache('pos-orders').filter((order) => {
    const createdAt = String(order.created_at || '');
    const orderDate = createdAt.split('T')[0];
    return (
      (order.status || '') === 'completed' && (
      !startDate || orderDate >= startDate) && (
      !endDate || orderDate <= endDate) && (

      !outletId ||
      outletId === 'all' || (
      outletId === 'unassigned' ? !order.outlet_id : order.outlet_id === outletId)));


  });
  let orders = [];
  let currentMenuItems = [];
  let inventoryNameMap = new Map();

  try {
    let posQuery = state.supabase.
    from('pos_orders').
    select('*').
    eq('lodge_id', state.lodgeId).
    eq('status', 'completed').
    gte('created_at', `${startDate}T00:00:00`).
    lte('created_at', `${endDate}T23:59:59`);
    if (outletId && outletId !== 'all') {
      if (outletId === 'unassigned') posQuery = posQuery.is('outlet_id', null);else
      posQuery = posQuery.eq('outlet_id', outletId);
    }
    const { data: liveOrders, error: ordersError } = await posQuery;
    if (ordersError) throw ordersError;
    const fetchedOrders = (liveOrders || []).length === 0 && cachedOrders.length > 0 ?
    cachedOrders :
    liveOrders || [];

    // Write online results to cache so offline fallback stays fresh
    if ((liveOrders || []).length > 0) {
      writeCache('pos-orders', liveOrders);
    }

    // Fetch order items separately — failure here only affects top_items, not revenue totals
    let liveItems = [];
    const orderIds = fetchedOrders.map((o) => o.id).filter(Boolean);
    if (orderIds.length > 0) {
      const { data: itemRows, error: itemsError } = await state.supabase.
      from('pos_order_items').
      select('order_id, menu_item_id, inventory_item_id, depletion_qty, item_name, quantity, unit_price, subtotal').
      in('order_id', orderIds);
      if (!itemsError) liveItems = itemRows || [];
    }
    // Attach items back onto each order
    const itemsByOrder = {};
    for (const item of liveItems) {
      if (!itemsByOrder[item.order_id]) itemsByOrder[item.order_id] = [];
      itemsByOrder[item.order_id].push(item);
    }
    orders = fetchedOrders.map((o) => ({ ...o, pos_order_items: itemsByOrder[o.id] || o.pos_order_items || [] }));

    const { data: liveMenuItems, error: menuError } = await state.supabase.
    from('pos_menu_items').
    select('id, name, inventory_item_id, depletion_qty, template_kind, template_pack_size').
    eq('lodge_id', state.lodgeId);
    if (menuError) throw menuError;
    currentMenuItems = (liveMenuItems || []).length === 0 ?
    readCache('pos-menu-items') :
    liveMenuItems || [];

    const inventoryIds = [...new Set(
      currentMenuItems.
      map((item) => item.inventory_item_id).
      filter(Boolean)
    )];
    if (inventoryIds.length > 0) {
      const { data: inventoryRows, error: inventoryError } = await state.supabase.
      from('inventory_items').
      select('id, name').
      eq('lodge_id', state.lodgeId).
      in('id', inventoryIds);
      if (inventoryError) throw inventoryError;
      inventoryNameMap = new Map((inventoryRows || []).map((row) => [row.id, row.name]));
    }
  } catch (error) {
    orders = cachedOrders;
    currentMenuItems = readCache('pos-menu-items');
    const inventoryRows = readCache('inventory-items');
    inventoryNameMap = new Map((inventoryRows || []).map((row) => [row.id, row.name]));
    if (!orders.length && !currentMenuItems.length && state.isOnline) {
      throw new Error(error?.message || 'Failed to load POS revenue summary');
    }
  }

  const menuItemMap = new Map((currentMenuItems || []).map((item) => [item.id, item]));

  const total_revenue = orders.reduce((s, o) => s + Number(o.total || 0), 0);
  const gross_revenue = orders.reduce((s, o) => s + normalizeMoney(o.gross_total ?? (Number(o.total || 0) > 0 ? Number(o.total || 0) : 0)), 0);
  const discount_total = orders.reduce((s, o) => s + normalizeMoney(o.discount_total || 0), 0);
  const tax_total = orders.reduce((s, o) => s + normalizeMoney(o.tax_total || 0), 0);
  const tip_total = orders.reduce((s, o) => s + normalizeMoney(o.tip_total || 0), 0);
  const returns_total = orders.reduce((s, o) => s + (Number(o.total || 0) < 0 ? Math.abs(Number(o.total || 0)) : 0), 0);
  const folio_revenue = orders.reduce(
    (sum, order) => sum + ((order.payment_method || '') === 'folio' ? Number(order.total || 0) : 0),
    0
  );
  const direct_revenue = total_revenue - folio_revenue;
  const total_orders = orders.length;
  const avg_order = total_orders > 0 ? total_revenue / total_orders : 0;

  // Breakdown by payment method
  const by_payment = {};
  for (const o of orders) {
    for (const payment of getOrderPaymentRows(o)) {
      by_payment[payment.method] = normalizeMoney((by_payment[payment.method] || 0) + Number(payment.amount || 0));
    }
  }

  const by_cashier = {};
  for (const o of orders) {
    const key = o.cashier_name || o.cashier_id || 'Unassigned';
    by_cashier[key] = normalizeMoney((by_cashier[key] || 0) + Number(o.total || 0));
  }

  // Top items aggregated across all line items
  const itemMap = {};
  for (const o of orders) {
    for (const li of o.pos_order_items || []) {
      const menuItem = menuItemMap.get(li.menu_item_id);
      const depletionQty = Number(
        menuItem?.template_pack_size ||
        menuItem?.depletion_qty ||
        1
      );
      const quantity = Number(li.quantity || 0);
      // Prefer live menu item name over the stored item_name snapshot, which
      // can be stale or incorrect (e.g. bar orders saving wrong item_name).
      // Prefer live menu item name over the stored item_name snapshot, which
      // can be stale or incorrect (e.g. bar orders saving wrong item_name).
      const menuItemName = menuItem?.name || li.item_name;
      const itemName = menuItem?.inventory_item_id ?
      inventoryNameMap.get(menuItem.inventory_item_id) || menuItemName :
      menuItemName;

      if (!itemMap[itemName]) itemMap[itemName] = { name: itemName, qty: 0, revenue: 0 };
      itemMap[itemName].qty += quantity * depletionQty;
      itemMap[itemName].revenue += Number(li.subtotal || 0);
      const inventoryId = li.inventory_item_id || menuItem?.inventory_item_id || null;
      if (inventoryId) {
        const inventoryCost = Number((readCache('inventory-items') || []).find((item) => item.id === inventoryId)?.latest_unit_cost || 0);
        itemMap[itemName].cost = Number(itemMap[itemName].cost || 0) + Math.max(0, quantity) * depletionQty * inventoryCost;
        itemMap[itemName].margin = Number(itemMap[itemName].revenue || 0) - Number(itemMap[itemName].cost || 0);
      }
    }
  }
  const top_items = Object.values(itemMap).sort((a, b) => b.revenue - a.revenue).slice(0, 15);

  // Daily totals
  const dailyMap = {};
  for (const o of orders) {
    const date = (o.created_at || '').split('T')[0];
    if (date) dailyMap[date] = (dailyMap[date] || 0) + Number(o.total || 0);
  }
  const daily = Object.entries(dailyMap).
  map(([date, total]) => ({ date, total })).
  sort((a, b) => a.date.localeCompare(b.date));

  return {
    total_revenue,
    gross_revenue,
    discount_total,
    returns_total,
    tax_total,
    tip_total,
    net_revenue: total_revenue,
    folio_revenue,
    direct_revenue,
    total_orders,
    avg_order,
    by_payment,
    by_cashier,
    top_items,
    daily,
    source: 'local',
    as_of_range: { start: startDate, end: endDate },
    outlet_selector: outletId || 'all'
  };
}
