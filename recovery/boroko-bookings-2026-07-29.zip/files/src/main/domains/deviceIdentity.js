import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { isDeviceId } from '../../shared/operationEnvelope.js';

export const DEVICE_IDENTITY_SCHEMA_VERSION = 1;
export const DEFAULT_DEVICE_IDENTITY_FILE = 'device-identity.json';

const TRUSTED_REGISTRATION_FIELDS = Object.freeze([
  'device_id',
  'lodge_id',
  'status',
  'registered_at',
  'last_verified_at',
  'expires_at',
  'offline_entitled',
  'verification_method',
  'credential_fingerprint',
  'capabilities'
]);

function storagePathFrom(input) {
  if (typeof input === 'string' && input.trim()) return input;
  if (!input || typeof input !== 'object') throw new TypeError('A device identity storage path is required.');
  const candidate = input.storagePath || input.storage_path;
  if (typeof candidate === 'string' && candidate.trim()) return candidate;
  const root = input.cacheDir || input.cacheRootDir || input.userDataPath;
  if (typeof root === 'string' && root.trim()) {
    return path.join(root, input.fileName || DEFAULT_DEVICE_IDENTITY_FILE);
  }
  throw new TypeError('A device identity storage path is required.');
}

function nowIso(now = new Date()) {
  const value = typeof now === 'function' ? now() : now;
  const date = value instanceof Date ? value : new Date(value);
  if (!Number.isFinite(date.getTime())) throw new TypeError('Invalid timestamp supplied for device identity.');
  return date.toISOString();
}

function readJson(storagePath, fsModule) {
  try {
    const parsed = JSON.parse(fsModule.readFileSync(storagePath, 'utf8'));
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

function normalizeRegistration(registration, deviceId) {
  if (!registration || typeof registration !== 'object' || Array.isArray(registration)) return null;
  const normalized = {};
  for (const key of TRUSTED_REGISTRATION_FIELDS) {
    if (Object.prototype.hasOwnProperty.call(registration, key)) normalized[key] = registration[key];
  }
  normalized.device_id = deviceId;
  if (normalized.lodge_id !== undefined && normalized.lodge_id !== null) {
    normalized.lodge_id = String(normalized.lodge_id).trim().toLowerCase();
  }
  if (normalized.status !== undefined && normalized.status !== null) {
    normalized.status = String(normalized.status).trim().toLowerCase();
  }
  for (const field of ['registered_at', 'last_verified_at', 'expires_at']) {
    if (normalized[field] !== undefined && normalized[field] !== null) {
      try {
        normalized[field] = nowIso(normalized[field]);
      } catch {
        delete normalized[field];
      }
    }
  }
  normalized.offline_entitled = normalized.offline_entitled === true;
  if (normalized.capabilities && (typeof normalized.capabilities !== 'object' || Array.isArray(normalized.capabilities))) {
    normalized.capabilities = {};
  }
  return normalized;
}

function normalizeIdentity(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const deviceId = value.device_id || value.deviceId;
  if (!isDeviceId(deviceId)) return null;
  return {
    schema_version: DEVICE_IDENTITY_SCHEMA_VERSION,
    device_id: String(deviceId).trim(),
    created_at: value.created_at ? nowIso(value.created_at) : null,
    trusted_registration: normalizeRegistration(value.trusted_registration || value.trustedRegistration, String(deviceId).trim())
  };
}

/** Resolve the local identity file without importing Electron at module load. */
export function resolveDeviceIdentityPath(options = {}) {
  return storagePathFrom(options);
}

export function readDeviceIdentity(input, options = {}) {
  const fsModule = options.fsModule || fs;
  const storagePath = storagePathFrom(input);
  try {
    return normalizeIdentity(readJson(storagePath, fsModule));
  } catch {
    return null;
  }
}

/**
 * Write an identity with an fsync + same-directory rename.  A crash can leave a
 * temporary file, but never a half-written identity at the canonical path.
 */
export function writeDeviceIdentity(input, identity, options = {}) {
  const fsModule = options.fsModule || fs;
  const storagePath = storagePathFrom(input);
  const normalized = normalizeIdentity(identity);
  if (!normalized) throw new TypeError('Cannot persist an invalid device identity.');

  const directory = path.dirname(storagePath);
  fsModule.mkdirSync(directory, { recursive: true });
  // Keep the injected ID source reserved for identity generation in tests and
  // callers that need deterministic IDs; the temporary filename is unrelated.
  const tempPath = `${storagePath}.${process.pid}.${(options.tempRandomUUID || randomUUID)()}.tmp`;
  const serialized = `${JSON.stringify(normalized, null, 2)}\n`;
  let descriptor = null;
  try {
    descriptor = fsModule.openSync(tempPath, 'wx', 0o600);
    fsModule.writeFileSync(descriptor, serialized, 'utf8');
    if (typeof fsModule.fsyncSync === 'function') fsModule.fsyncSync(descriptor);
    fsModule.closeSync(descriptor);
    descriptor = null;
    fsModule.renameSync(tempPath, storagePath);
    try { fsModule.chmodSync(storagePath, 0o600); } catch { /* Windows may not support chmod semantics. */ }
  } finally {
    if (descriptor !== null) {
      try { fsModule.closeSync(descriptor); } catch { /* best effort */ }
    }
    try {
      if (fsModule.existsSync(tempPath)) fsModule.unlinkSync(tempPath);
    } catch { /* do not mask the original persistence error */ }
  }
  return normalized;
}

export function loadOrCreateDeviceIdentity(input, options = {}) {
  const storagePath = storagePathFrom(input);
  const fsModule = options.fsModule || fs;
  const existing = readDeviceIdentity(storagePath, { fsModule });
  if (existing) return existing;

  const generated = {
    schema_version: DEVICE_IDENTITY_SCHEMA_VERSION,
    device_id: String((options.randomUUID || randomUUID)()).trim(),
    created_at: nowIso(options.now || new Date()),
    trusted_registration: null
  };
  return writeDeviceIdentity(storagePath, generated, {
    fsModule,
    randomUUID: options.randomUUID
  });
}

export function getStableDeviceId(input, options = {}) {
  return loadOrCreateDeviceIdentity(input, options).device_id;
}

export function readTrustedDeviceRegistration(input, options = {}) {
  return readDeviceIdentity(input, options)?.trusted_registration || null;
}

/** Persist only non-secret registration metadata returned by the server. */
export function saveTrustedDeviceRegistration(input, registration, options = {}) {
  const storagePath = storagePathFrom(input);
  const identity = loadOrCreateDeviceIdentity(storagePath, options);
  const normalizedRegistration = normalizeRegistration(registration, identity.device_id);
  if (!normalizedRegistration?.lodge_id) throw new TypeError('A trusted registration must include lodge_id.');
  const next = { ...identity, trusted_registration: normalizedRegistration };
  writeDeviceIdentity(storagePath, next, options);
  return normalizedRegistration;
}

export function clearTrustedDeviceRegistration(input, options = {}) {
  const storagePath = storagePathFrom(input);
  const identity = readDeviceIdentity(storagePath, options);
  if (!identity) return null;
  const next = { ...identity, trusted_registration: null };
  writeDeviceIdentity(storagePath, next, options);
  return next;
}

export function isTrustedDeviceRegistrationValid(registration, options = {}) {
  if (!registration || typeof registration !== 'object') return false;
  if (registration.status !== 'active' && registration.status !== 'trusted') return false;
  if (registration.offline_entitled !== true) return false;
  if (options.deviceId && registration.device_id !== options.deviceId) return false;
  if (options.lodgeId && String(registration.lodge_id || '').toLowerCase() !== String(options.lodgeId).toLowerCase()) return false;
  if (registration.expires_at) {
    const now = new Date(options.now || Date.now()).getTime();
    const expiry = new Date(registration.expires_at).getTime();
    if (!Number.isFinite(expiry) || expiry <= now) return false;
  }
  return true;
}

export function getDeviceRegistrationState(input, options = {}) {
  const identity = readDeviceIdentity(input, options);
  const registration = identity?.trusted_registration || null;
  return {
    device_id: identity?.device_id || null,
    registered: !!registration,
    trusted: isTrustedDeviceRegistrationValid(registration, {
      ...options,
      deviceId: identity?.device_id || options.deviceId
    }),
    status: registration?.status || 'unregistered',
    lodge_id: registration?.lodge_id || null,
    offline_entitled: registration?.offline_entitled === true,
    last_verified_at: registration?.last_verified_at || null,
    expires_at: registration?.expires_at || null
  };
}

export { TRUSTED_REGISTRATION_FIELDS };
