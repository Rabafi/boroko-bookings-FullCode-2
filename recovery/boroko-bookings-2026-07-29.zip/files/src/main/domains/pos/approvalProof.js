import fs from 'node:fs';
import path from 'node:path';
import { createHash, randomBytes } from 'node:crypto';
import bcrypt from 'bcryptjs';

/**
 * Offline approval support for POS returns and voids.
 *
 * The PIN is deliberately accepted only at the boundary where it is checked
 * against a trusted cached hash.  It is never part of the returned proof,
 * operation envelope, cache row, or queue payload.  The proof is an
 * assertion over the business fields and a device credential fingerprint;
 * the server remains responsible for checking that the device and approver
 * are still registered and entitled to approve the operation.
 */

export const APPROVAL_PROOF_VERSION = 1;
export const APPROVAL_CREDENTIAL_FILE = 'approval-device-credential.json';
export const APPROVAL_LOCKOUT_FILE = 'approval-lockout.json';
const MAX_FAILURES = 5;
const LOCKOUT_MS = 5 * 60 * 1000;

function storageRoot(input = {}) {
  if (typeof input === 'string' && input.trim()) return input;
  const root = input.cacheDir || input.cacheRootDir || input.userDataPath;
  if (!root || typeof root !== 'string') throw new TypeError('A durable approval storage path is required.');
  return root;
}

function readJson(filePath, fsModule = fs) {
  try {
    const value = JSON.parse(fsModule.readFileSync(filePath, 'utf8'));
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  } catch {
    return {};
  }
}

function writeJsonAtomic(filePath, value, fsModule = fs) {
  const directory = path.dirname(filePath);
  fsModule.mkdirSync(directory, { recursive: true });
  const tempPath = `${filePath}.${process.pid}.${randomBytes(8).toString('hex')}.tmp`;
  const descriptor = fsModule.openSync(tempPath, 'wx', 0o600);
  try {
    fsModule.writeFileSync(descriptor, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
    if (typeof fsModule.fsyncSync === 'function') fsModule.fsyncSync(descriptor);
    fsModule.closeSync(descriptor);
    fsModule.renameSync(tempPath, filePath);
    try { fsModule.chmodSync(filePath, 0o600); } catch { /* best effort on Windows */ }
  } catch (error) {
    try { fsModule.closeSync(descriptor); } catch { /* best effort */ }
    throw error;
  } finally {
    try { if (fsModule.existsSync(tempPath)) fsModule.unlinkSync(tempPath); } catch { /* best effort */ }
  }
}

function normalizeString(value) {
  return value == null ? null : String(value).trim() || null;
}

/** Stable JSON representation used for signing and server verification. */
export function canonicalize(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalize).join(',')}]`;
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalize(value[key])}`).join(',')}}`;
}

function digestAssertion(assertion, credential) {
  const core = Object.fromEntries(Object.entries(assertion).filter(([key]) =>
    !['signature', 'approval_signature', 'credential_fingerprint', 'signature_algorithm', 'proof_version', 'signed'].includes(key)
  ));
  return createHash('sha256')
    .update(`${canonicalize(core)}:${credential}`, 'utf8')
    .digest('hex');
}

export function getApprovalCredential(input = {}, options = {}) {
  const fsModule = options.fsModule || fs;
  const root = storageRoot(input);
  const filePath = path.join(root, options.fileName || APPROVAL_CREDENTIAL_FILE);
  const existing = readJson(filePath, fsModule);
  if (existing.credential_fingerprint && existing.schema_version === APPROVAL_PROOF_VERSION) return existing;
  const credential = {
    schema_version: APPROVAL_PROOF_VERSION,
    credential_fingerprint: createHash('sha256').update(randomBytes(32)).digest('hex'),
    created_at: new Date().toISOString()
  };
  writeJsonAtomic(filePath, credential, fsModule);
  return credential;
}

export function buildApprovalAssertion(input = {}) {
  const assertion = {
    version: APPROVAL_PROOF_VERSION,
    operation_id: normalizeString(input.operation_id || input.operationId),
    entity_id: normalizeString(input.entity_id || input.entityId),
    approver_id: normalizeString(input.approver_id || input.approverId),
    outlet_id: normalizeString(input.outlet_id || input.outletId),
    reason: normalizeString(input.reason),
    device_id: normalizeString(input.device_id || input.deviceId),
    asserted_at: normalizeString(input.asserted_at || input.assertedAt) || new Date().toISOString()
  };
  if (!assertion.operation_id || !assertion.entity_id || !assertion.approver_id || !assertion.device_id || !assertion.reason) {
    throw new TypeError('Approval assertion requires operation, entity, approver, device, and reason.');
  }
  return assertion;
}

export function signApprovalAssertion(assertion, options = {}) {
  const credential = normalizeString(options.credential_fingerprint || options.credentialFingerprint);
  if (!credential) {
    const error = new Error('No trusted registered device credential is available for offline approval.');
    error.code = 'APPROVAL_CREDENTIAL_UNAVAILABLE';
    throw error;
  }
  const unsigned = {
    ...assertion,
    credential_fingerprint: credential,
    signature_algorithm: 'sha256-device-credential',
    proof_version: APPROVAL_PROOF_VERSION,
    signed: true
  };
  return { ...unsigned, signature: digestAssertion(unsigned, credential) };
}

export function createApprovalProof(input = {}, options = {}) {
  const assertion = buildApprovalAssertion(input);
  const signed = signApprovalAssertion(assertion, options);
  return {
    proof_version: APPROVAL_PROOF_VERSION,
    signed: true,
    approval_assertion: signed
  };
}

export function approvalProofHasPlaintextSecret(value) {
  if (!value || typeof value !== 'object') return false;
  const forbidden = new Set(['pin', 'approval_pin', 'password', 'secret', 'passcode']);
  const visit = (node) => {
    if (!node || typeof node !== 'object') return false;
    for (const [key, child] of Object.entries(node)) {
      if (forbidden.has(String(key).toLowerCase())) return true;
      if (child && typeof child === 'object' && visit(child)) return true;
    }
    return false;
  };
  return visit(value);
}

function lockoutPath(input, options = {}) {
  return path.join(storageRoot(input), options.fileName || APPROVAL_LOCKOUT_FILE);
}

export function readApprovalLockout(input = {}, options = {}) {
  const row = readJson(lockoutPath(input, options), options.fsModule || fs);
  return {
    failures: Number.isInteger(row.failures) && row.failures >= 0 ? row.failures : 0,
    locked_until: Number.isFinite(Date.parse(row.locked_until || '')) ? row.locked_until : null
  };
}

export function approvalAttemptAllowed(input = {}, options = {}) {
  const row = readApprovalLockout(input, options);
  const until = row.locked_until ? Date.parse(row.locked_until) : 0;
  if (until > Date.now()) return { allowed: false, retry_after_ms: until - Date.now(), ...row };
  if (until) clearApprovalLockout(input, options);
  return { allowed: true, ...row };
}

export function recordApprovalFailure(input = {}, options = {}) {
  const fsModule = options.fsModule || fs;
  const current = readApprovalLockout(input, options);
  const failures = current.failures + 1;
  const lockedUntil = failures >= MAX_FAILURES ? new Date(Date.now() + LOCKOUT_MS).toISOString() : null;
  const row = { failures, locked_until: lockedUntil, updated_at: new Date().toISOString() };
  writeJsonAtomic(lockoutPath(input, options), row, fsModule);
  return row;
}

export function clearApprovalLockout(input = {}, options = {}) {
  const fsModule = options.fsModule || fs;
  writeJsonAtomic(lockoutPath(input, options), { failures: 0, locked_until: null, updated_at: new Date().toISOString() }, fsModule);
}

export function verifyApprovalPin(pin, pinHash, input = {}, options = {}) {
  const allowed = approvalAttemptAllowed(input, options);
  if (!allowed.allowed) return { success: false, locked: true, retry_after_ms: allowed.retry_after_ms };
  const valid = !!pinHash && bcrypt.compareSync(String(pin || '').trim(), String(pinHash));
  if (!valid) {
    const failure = recordApprovalFailure(input, options);
    return { success: false, locked: failure.failures >= MAX_FAILURES, retry_after_ms: failure.locked_until ? LOCKOUT_MS : 0 };
  }
  clearApprovalLockout(input, options);
  return { success: true };
}
