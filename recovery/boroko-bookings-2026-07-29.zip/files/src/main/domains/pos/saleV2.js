import { isUuid } from '../../../shared/operationEnvelope.js';

export const POS_SALE_V2_RPC = 'create_pos_order_v2';
export const POS_SALE_V2_CONTRACT_VERSION = 2;

const MONEY_SCALE = 100;

export function roundMoney(value) {
  const numeric = Number(value);
  return Number.isFinite(numeric) ? Math.round(numeric * MONEY_SCALE) / MONEY_SCALE : 0;
}

export function normalizeSaleQuantity(value) {
  const numeric = Number(value);
  return Number.isFinite(numeric) && numeric > 0 ? numeric : 0;
}

export function normalizeSaleModifiers(modifiers = []) {
  if (!Array.isArray(modifiers)) return [];
  return modifiers
    .map((modifier) => ({
      id: modifier?.id || modifier?.modifier_id || null,
      quantity: normalizeSaleQuantity(modifier?.quantity || 1) || 1,
      // The server resolves modifier prices from its immutable definition. A
      // client supplied delta is retained only as a display/provisional hint.
      provisional_price_delta: roundMoney(modifier?.price_delta ?? modifier?.provisional_price_delta ?? 0)
    }))
    .filter((modifier) => modifier.id || modifier.provisional_price_delta !== 0);
}

/**
 * Return the trusted catalog snapshot for an item.  An online caller may pass
 * a tampered unit_price, but the adapter never uses it when a menu cache row is
 * available.  Offline replay carries the immutable reference and provisional
 * display price so the server can validate the historical version.
 */
export function resolveTrustedCatalogItem(item = {}, menuRows = []) {
  const menuItemId = String(item.menu_item_id || '').trim() || null;
  const menu = menuItemId ? (menuRows || []).find((row) => row?.id === menuItemId) : null;
  const trustedPrice = menu ? roundMoney(menu.price) : roundMoney(item.unit_price);
  const priceHistoryId = item.price_history_id || item.price_history_ref || menu?.price_history_id || menu?.price_history_ref || null;
  const catalogVersion = item.catalog_version || item.catalog_version_id || menu?.catalog_version || menu?.catalog_version_id || null;
  return {
    menu,
    menu_item_id: menuItemId,
    inventory_item_id: item.inventory_item_id || menu?.inventory_item_id || null,
    depletion_qty: Number(item.depletion_qty ?? menu?.depletion_qty ?? 1) > 0 ? Number(item.depletion_qty ?? menu?.depletion_qty ?? 1) : 1,
    item_name: String(item.item_name || menu?.name || '').trim() || 'POS item',
    category: item.category || menu?.category || null,
    price_history_id: priceHistoryId,
    catalog_version: catalogVersion,
    provisional_unit_price: trustedPrice,
    modifiers: normalizeSaleModifiers(item.modifiers),
    item_notes: item.item_notes || null,
    quantity: normalizeSaleQuantity(item.quantity)
  };
}

export function normalizeSaleItems(items = [], menuRows = [], { requireCatalogReference = false } = {}) {
  if (!Array.isArray(items) || items.length === 0) {
    throw new Error('A POS sale must contain at least one item.');
  }
  const normalized = items.map((item) => {
    const line = resolveTrustedCatalogItem(item, menuRows);
    if (!(line.quantity > 0)) {
      const error = new Error('POS sale quantities must be greater than zero.');
      error.code = 'POS_SALE_QUANTITY_INVALID';
      throw error;
    }
    if (requireCatalogReference && !line.price_history_id && !line.catalog_version) {
      const error = new Error(`No trusted price history is available for ${line.item_name}. Refresh the POS catalog before retrying.`);
      error.code = 'POS_PRICE_VERSION_UNAVAILABLE';
      throw error;
    }
    return line;
  });
  return normalized;
}

export function buildSemanticDiscount(data = {}, grossTotal = 0) {
  const requested = data.discount && typeof data.discount === 'object' ? data.discount : {};
  const amount = Math.min(
    Math.max(0, roundMoney(data.discount_total ?? requested.amount ?? 0)),
    Math.max(0, roundMoney(grossTotal))
  );
  return {
    amount,
    reason: String(data.discount_reason || requested.reason || '').trim() || null,
    promotion_id: data.promotion_id || requested.promotion_id || null,
    mode: requested.mode === 'percent' ? 'percent' : 'amount'
  };
}

export function buildPosSaleV2Payload({ data = {}, items = [], totals = {}, paymentBreakdown = [], orderId }) {
  const discount = buildSemanticDiscount(data, totals.gross_total || 0);
  const payloadItems = items.map((item) => ({
    menu_item_id: item.menu_item_id,
    inventory_item_id: item.inventory_item_id || null,
    depletion_qty: item.depletion_qty,
    item_name: item.item_name,
    category: item.category,
    quantity: item.quantity,
    // This is explicitly a provisional display value. The v2 function must
    // resolve the authoritative price from price_history_id/catalog_version.
    provisional_unit_price: item.provisional_unit_price,
    price_history_id: item.price_history_id || null,
    catalog_version: item.catalog_version || null,
    modifiers: item.modifiers,
    item_notes: item.item_notes
  }));

  return {
    id: orderId,
    room_id: data.room_id || null,
    booking_id: data.booking_id || null,
    walk_in_name: data.walk_in_name || null,
    service_mode: data.service_mode || (data.table_name ? 'table' : data.room_id ? 'room' : 'takeaway'),
    table_name: data.table_name || null,
    tab_name: data.tab_name || null,
    notes: data.notes || null,
    items: payloadItems,
    discount,
    // Keep a semantic tender object. Totals here are provisional hints only;
    // the server derives/validates all financial values.
    tenders: paymentBreakdown,
    payment_method: data.payment_method || null,
    tax_profile_id: data.tax_profile_id || null,
    tax_rate_hint: Number.isFinite(Number(data.tax_rate)) ? Number(data.tax_rate) : null,
    tip_hint: Math.max(0, roundMoney(data.tip_total || 0)),
    provisional_totals: {
      gross_total: roundMoney(totals.gross_total),
      discount_total: discount.amount,
      tax_total: roundMoney(totals.tax_total),
      tip_total: roundMoney(totals.tip_total),
      total: roundMoney(totals.total)
    },
    device_reference: data.device_reference || null
  };
}

export function buildSaleQueueMetadata({ operationId, orderId, dependsOn = null } = {}) {
  return {
    _queue_id: `pos-sale-${operationId}`,
    _contract_version: POS_SALE_V2_CONTRACT_VERSION,
    _operation_id: operationId,
    _entity_type: 'pos_sale',
    _entity_id: orderId,
    _state: 'pending',
    ...(dependsOn ? { _depends_on: dependsOn } : {})
  };
}

export function isRetryablePosSaleError(errorOrResult) {
  if (!errorOrResult) return false;
  if (errorOrResult.retryable === true || errorOrResult.details?.retryable === true) return true;
  const code = String(errorOrResult.code || errorOrResult.details?.code || '').toUpperCase();
  if (/^(408|409|425|429|500|502|503|504)$/.test(code)) return true;
  if (/NETWORK|TIMEOUT|FETCH|OFFLINE|ECONN|ETIMEDOUT|PGRST202|CONTRACT_UNAVAILABLE|SERVER_CONTRACT_UNAVAILABLE/.test(code)) return true;
  const message = String(errorOrResult.message || errorOrResult.error || '').toLowerCase();
  return /network|timeout|timed out|failed to fetch|connection|offline|could not find the function|schema cache|temporarily unavailable|server contract unavailable/.test(message);
}

export function isUuidOperationId(value) {
  return isUuid(String(value || '').trim());
}

