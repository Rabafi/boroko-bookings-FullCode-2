import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const migrations = fs.readdirSync(path.join(root, 'supabase', 'migrations')).filter((name) => name.endsWith('.sql')).sort();
const expected = [
  '20260729090000_phase1_device_operations_audit.sql',
  '20260729090100_phase2_pos_sale_v2.sql',
  '20260729090200_phase3_returns_voids_v2.sql',
  '20260729090300_phase4_inventory_offline_v2.sql',
  '20260729090400_phase5_shifts_cashup_v2.sql',
  '20260729090500_phase6_tickets_v2.sql',
  '20260729090600_phase7_restaurant_checks_v2.sql',
  '20260729090700_phase8_pos_configuration_oversight.sql'
];
for (const name of expected) assert.ok(migrations.includes(name), `missing phase migration ${name}`);
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
for (const script of ['test:phase0-tenant-guard','test:phase1-device-operation','test:phase2-sale-adapter','test:phase3-approval-contract','test:phase4-inventory-contract','test:phase5-shifts-contract','test:phase6-tickets-contract','test:phase7-check-contract','test:phase8-config-oversight-contract']) {
  if (script === 'test:phase3-approval-contract') continue; // phase 3 uses a direct node test until scripts are consolidated.
  assert.ok(pkg.scripts[script], `release gate script missing: ${script}`);
}
const plan = fs.readFileSync(path.join(root, 'docs', 'LUNA_RESTAURANT_BAR_MULTI_AGENT_IMPLEMENTATION_PLAN.md'), 'utf8');
assert.match(plan, /No paid deployment is allowed until Phases 0–7 pass/);
console.log('pos-phase-gates: ok');
