import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { buildSemanticDiscount, getSaleSyncPresentation, isTenderTotalBalanced, mergeAuthoritativeSaleResult } from '../src/renderer/src/components/pos/salePresentation.js'

const rendererSource = await readFile(new URL('../src/renderer/src/components/POS.jsx', import.meta.url), 'utf8')

// The renderer must submit semantic discount data, never a negative pseudo-line.
assert.doesNotMatch(rendererSource, /buildDiscountLine/)
assert.doesNotMatch(rendererSource, /unit_price:\s*-\s*Math\./)
assert.match(rendererSource, /discount:\s*semanticDiscount/)
assert.match(rendererSource, /disabled=\{!salePresentation\.authoritative\}/)
assert.match(rendererSource, /Never print a provisional offline receipt/)

const discount = buildSemanticDiscount({
  allowed: true,
  subtotal: 100,
  mode: 'percent',
  value: 10,
  reason: 'Loyalty'
})
assert.deepEqual(discount, {
  type: 'manual',
  mode: 'percent',
  value: 10,
  amount: 10,
  reason: 'Loyalty'
})

// An offline sale remains visible as provisional and must not be treated as an
// authoritative receipt until replay returns the server receipt number.
const provisional = mergeAuthoritativeSaleResult({
  success: true,
  id: 'offline-order',
  operation_id: 'op-offline',
  offline: true,
  total: 90
}, { id: 'offline-order', total: 90 })
assert.equal(getSaleSyncPresentation(provisional).state, 'pending')
assert.equal(provisional._is_authoritative, false)

const conflict = mergeAuthoritativeSaleResult({
  success: true,
  id: 'conflict-order',
  operation_id: 'op-conflict',
  review_required: true,
  error: 'Trusted price version is unavailable.'
}, { id: 'conflict-order', total: 90 })
assert.equal(getSaleSyncPresentation(conflict).state, 'review')
assert.equal(conflict._is_authoritative, false)

// Split tenders are balanced in cents before they are submitted; an unbalanced
// split must remain blocked in the UI.
assert.equal(isTenderTotalBalanced([
  { method: 'cash', amount: 40 },
  { method: 'card', amount: 50, reference: 'AUTH-1' }
], 90), true)
assert.equal(isTenderTotalBalanced([{ method: 'cash', amount: 89.99 }], 90), false)

const reconciled = mergeAuthoritativeSaleResult({
  success: true,
  id: 'server-order',
  operation_id: 'op-server',
  total: 91.25,
  receipt_number: 'R-00042',
  accepted_at: '2026-07-29T13:00:01.000Z'
}, { id: 'server-order', total: 90, _provisional_total: 90 })
assert.equal(getSaleSyncPresentation(reconciled).state, 'reconciled')
assert.equal(reconciled.receipt_number, 'R-00042')
assert.equal(reconciled.total, 91.25)
assert.equal(reconciled._is_authoritative, true)

console.log('pos-renderer-v2-contract: ok')
