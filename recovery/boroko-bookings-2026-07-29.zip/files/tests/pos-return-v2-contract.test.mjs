import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import {
  buildApprovalMutationRequest,
  buildReturnItems,
  containsPlaintextApprovalSecret,
  getReturnSyncPresentation,
  getReturnableLines,
  getVoidSyncPresentation
} from '../src/renderer/src/components/pos/returnPresentation.js'

const rendererSource = await readFile(new URL('../src/renderer/src/components/POS.jsx', import.meta.url), 'utf8')

// Returns use the dedicated positive-quantity intent; the server performs the
// financial reversal and no negative sale pseudo-line is built in the UI.
assert.match(rendererSource, /buildReturnItems\(returnTarget, returnLines\)/)
assert.doesNotMatch(rendererSource, /negative POS order/)
assert.doesNotMatch(rendererSource, /pin:\s*(void|return)ApprovalInput/)
assert.match(rendererSource, /approvalAssertion/)
assert.match(rendererSource, /getReturnSyncPresentation/)
assert.match(rendererSource, /pending_external_refund/)
assert.match(rendererSource, /disabled={!receiptAuthoritative}/)

const order = {
  id: 'order-1',
  pos_order_items: [
    { id: 'line-a', item_name: 'Lager', quantity: 3, returned_quantity: 1, unit_price: 25 },
    { id: 'line-b', item_name: 'Burger', quantity: 2, returned_quantity: 2, unit_price: 40 }
  ]
}
const returnable = getReturnableLines(order)
assert.equal(returnable.length, 1)
assert.equal(returnable[0].remaining_quantity, 2)
assert.deepEqual(buildReturnItems(order, { 'line-a': 50, 'line-b': 1 }), [{ line_id: 'line-a', quantity: 2 }])

const request = buildApprovalMutationRequest({
  operation: 'return',
  operationId: 'op-1',
  orderId: 'order-1',
  outletId: 'bar-1',
  reason: 'Guest returned one drink',
  approvalAssertion: { approver_id: 'manager-1', signature: 'device-signature' },
  items: [{ line_id: 'line-a', quantity: 1 }],
  paymentMethod: 'card'
})
assert.equal(request.contract_version, 2)
assert.equal(request.approval_assertion.signature, 'device-signature')
assert.equal(Object.prototype.hasOwnProperty.call(request, 'pin'), false)
assert.equal(containsPlaintextApprovalSecret(request), false)
assert.equal(containsPlaintextApprovalSecret({ approval_assertion: { pin: '1234' } }), true)

const pendingRefund = getReturnSyncPresentation({ status: 'pending_external_refund', return_receipt_number: 'RET-1' })
assert.equal(pendingRefund.state, 'pending_external_refund')
assert.equal(pendingRefund.authoritative, true)
assert.equal(pendingRefund.releaseExternalCash, false)

const pendingOffline = getReturnSyncPresentation({ offline: true })
assert.equal(pendingOffline.state, 'pending')
assert.equal(pendingOffline.authoritative, false)
assert.equal(pendingOffline.releaseExternalCash, false)

const voidReview = getVoidSyncPresentation({ review_required: true })
assert.equal(voidReview.state, 'review')
assert.equal(voidReview.releaseExternalCash, false)

console.log('pos-return-v2-contract: ok')

