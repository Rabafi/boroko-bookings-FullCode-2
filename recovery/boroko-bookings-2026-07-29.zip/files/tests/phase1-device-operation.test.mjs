import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {
  clearTrustedDeviceRegistration,
  getDeviceRegistrationState,
  getStableDeviceId,
  isTrustedDeviceRegistrationValid,
  loadOrCreateDeviceIdentity,
  readDeviceIdentity,
  readTrustedDeviceRegistration,
  saveTrustedDeviceRegistration,
  writeDeviceIdentity
} from '../src/main/domains/deviceIdentity.js';
import {
  OperationEnvelopeError,
  assertValidOperationEnvelope,
  createOperationEnvelope,
  isOperationEnvelope,
  reuseOperationEnvelope,
  validateOperationEnvelope
} from '../src/shared/operationEnvelope.js';

const UUID_A = '11111111-1111-4111-8111-111111111111';
const UUID_B = '22222222-2222-4222-8222-222222222222';
const UUID_C = '33333333-3333-4333-8333-333333333333';

function tempIdentityPath() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'boroko-device-test-'));
  return { root, file: path.join(root, 'device-identity.json') };
}

function run() {
  const { root, file } = tempIdentityPath();
  try {
    // The first generated ID is persisted; subsequent launches reuse it even if
    // the random source would return a different value.
    let randomCalls = 0;
    const randomUUID = () => {
      randomCalls += 1;
      return randomCalls === 1 ? UUID_A : UUID_B;
    };
    const first = loadOrCreateDeviceIdentity(file, {
      randomUUID,
      now: '2026-07-29T13:00:00.000Z'
    });
    const second = loadOrCreateDeviceIdentity(file, {
      randomUUID,
      now: '2026-07-29T14:00:00.000Z'
    });
    assert.equal(first.device_id, UUID_A);
    assert.equal(second.device_id, UUID_A);
    assert.equal(randomCalls, 1, 'stable device ID must not regenerate on each launch');
    assert.equal(getStableDeviceId(file), UUID_A);

    const registration = saveTrustedDeviceRegistration(file, {
      lodge_id: UUID_B,
      status: 'active',
      offline_entitled: true,
      registered_at: '2026-07-29T13:01:00.000Z',
      last_verified_at: '2026-07-29T13:01:00.000Z',
      expires_at: '2099-01-01T00:00:00.000Z',
      verification_method: 'session',
      credential_fingerprint: 'sha256:test',
      pin: 'must-not-persist',
      private_key: 'must-not-persist',
      session_token: 'must-not-persist'
    }, { now: '2026-07-29T13:02:00.000Z' });
    assert.equal(registration.device_id, UUID_A);
    const persisted = JSON.parse(fs.readFileSync(file, 'utf8'));
    assert.equal(persisted.trusted_registration.pin, undefined);
    assert.equal(persisted.trusted_registration.private_key, undefined);
    assert.equal(persisted.trusted_registration.session_token, undefined);
    assert.equal(readTrustedDeviceRegistration(file).lodge_id, UUID_B);
    assert.equal(isTrustedDeviceRegistrationValid(registration, {
      deviceId: UUID_A,
      lodgeId: UUID_B,
      now: '2026-07-29T13:03:00.000Z'
    }), true);
    assert.equal(getDeviceRegistrationState(file, {
      lodgeId: UUID_B,
      now: '2026-07-29T13:03:00.000Z'
    }).trusted, true);
    clearTrustedDeviceRegistration(file);
    assert.equal(readTrustedDeviceRegistration(file), null);

    // An interrupted atomic write leaves the previous canonical file usable.
    const original = readDeviceIdentity(file);
    const crashFs = {
      ...fs,
      mkdirSync: fs.mkdirSync.bind(fs),
      openSync: fs.openSync.bind(fs),
      writeFileSync: fs.writeFileSync.bind(fs),
      fsyncSync: fs.fsyncSync.bind(fs),
      closeSync: fs.closeSync.bind(fs),
      existsSync: fs.existsSync.bind(fs),
      unlinkSync: fs.unlinkSync.bind(fs),
      chmodSync: fs.chmodSync.bind(fs),
      renameSync() { throw new Error('simulated crash before rename'); }
    };
    assert.throws(() => writeDeviceIdentity(file, {
      device_id: UUID_C,
      created_at: '2026-07-29T15:00:00.000Z',
      trusted_registration: null
    }, { fsModule: crashFs }), /simulated crash/);
    assert.equal(readDeviceIdentity(file).device_id, original.device_id);
    assert.equal(fs.readdirSync(root).filter((name) => name.includes('.tmp')).length, 0);

    const envelope = createOperationEnvelope({
      device_id: 'device-test-001',
      lodge_id: UUID_A,
      outlet_id: UUID_B,
      payload: { order_id: UUID_C, amount: 15 }
    }, {
      generateOperationId: () => UUID_C,
      now: () => '2026-07-29T13:00:00+02:00'
    });
    assert.equal(envelope.operation_id, UUID_C);
    assert.equal(envelope.device_event_at, '2026-07-29T11:00:00.000Z');
    assert.equal(isOperationEnvelope(envelope), true);
    assert.deepEqual(reuseOperationEnvelope(envelope), envelope);
    assert.equal(validateOperationEnvelope(envelope).valid, true);
    assert.equal(assertValidOperationEnvelope(envelope), envelope);

    assert.throws(() => createOperationEnvelope({
      device_id: 'device-test-001',
      lodge_id: UUID_A,
      payload: { cashier_id: UUID_B }
    }, { generateOperationId: () => UUID_C }), (error) =>
      error instanceof OperationEnvelopeError && error.code === 'CALLER_AUTHORITY_FIELD_FORBIDDEN');
    assert.throws(() => reuseOperationEnvelope(envelope, { payload: { changed: true } }), (error) =>
      error instanceof OperationEnvelopeError && error.code === 'OPERATION_REUSE_IMMUTABLE');
    assert.equal(validateOperationEnvelope({ ...envelope, operation_id: 'not-a-uuid' }).valid, false);

    console.log('phase1-device-operation: ok');
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
}

run();

