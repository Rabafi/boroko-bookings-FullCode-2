import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import {
  POS_SALE_V2_RPC,
  buildPosSaleV2Payload,
  buildSaleQueueMetadata,
  isRetryablePosSaleError,
  normalizeSaleItems
} from '../src/main/domains/pos/saleV2.js';

const menu = [{
  id: 'menu-coffee',
  name: 'Coffee',
  category: 'Drinks',
  price: 15,
  inventory_item_id: 'inventory-coffee',
  depletion_qty: 1,
  price_history_id: 'price-history-coffee',
  catalog_version: 'catalog-2026-07-29'
}];

const trusted = normalizeSaleItems([{
  menu_item_id: 'menu-coffee',
  item_name: 'Tampered name',
  quantity: 1,
  unit_price: 0.01,
  price_history_id: 'price-history-coffee'
}], menu);

assert.equal(trusted[0].provisional_unit_price, 15, 'local sales must use trusted cached catalog price');
assert.equal(trusted[0].item_name, 'Tampered name', 'item name is a display snapshot and may be retained');
assert.throws(() => normalizeSaleItems([{ menu_item_id: 'menu-coffee', quantity: 0 }], menu), /quantities must be greater than zero/);
assert.throws(() => normalizeSaleItems([{ menu_item_id: 'menu-coffee', quantity: -1 }], menu), /quantities must be greater than zero/);

const payload = buildPosSaleV2Payload({
  data: { payment_method: 'cash', discount_total: 2, discount_reason: 'Manager promotion' },
  items: trusted,
  totals: { gross_total: 15, discount_total: 2, tax_total: 0, tip_total: 0, total: 13 },
  paymentBreakdown: [{ method: 'cash', amount: 13 }],
  orderId: 'order-coffee'
});
assert.equal(payload.discount.amount, 2);
assert.equal(payload.items.some((line) => Number(line.quantity) < 0), false, 'v2 sale must never carry a negative line');
assert.equal(payload.items[0].provisional_unit_price, 15);
assert.equal(payload.items[0].price_history_id, 'price-history-coffee');
assert.equal(payload.items[0].catalog_version, 'catalog-2026-07-29');

const queueMeta = buildSaleQueueMetadata({ operationId: 'operation-coffee', orderId: 'order-coffee' });
assert.equal(POS_SALE_V2_RPC, 'create_pos_order_v2');
assert.equal(queueMeta._queue_id, 'pos-sale-operation-coffee');
assert.equal(queueMeta._contract_version, 2);
assert.equal(queueMeta._operation_id, 'operation-coffee');
assert.equal(isRetryablePosSaleError({ code: 'PGRST202' }), true);
assert.equal(isRetryablePosSaleError({ code: 'PRICE_VERSION_UNKNOWN' }), false);

const posSource = await readFile(new URL('../src/main/domains/pos.js', import.meta.url), 'utf8');
assert.match(posSource, /createOperationEnvelope\(/);
assert.match(posSource, /queueOperation\('rpc', POS_SALE_V2_RPC/);
assert.doesNotMatch(posSource, /rpc\('create_pos_order',/);
assert.match(posSource, /reconcilePosSaleReplay/);

console.log('phase2-sale-adapter: ok');
