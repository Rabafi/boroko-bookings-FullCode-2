import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  approvalProofHasPlaintextSecret,
  buildApprovalAssertion,
  canonicalize,
  createApprovalProof
} from '../src/main/domains/pos/approvalProof.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const posSource = fs.readFileSync(path.join(root, 'src/main/domains/pos.js'), 'utf8');
const helperSource = fs.readFileSync(path.join(root, 'src/main/domains/pos/approvalProof.js'), 'utf8');

assert.match(posSource, /void_pos_order_v2/);
assert.match(posSource, /return_pos_order_v2/);
assert.match(posSource, /createApprovalProof/);
assert.doesNotMatch(posSource, /queueOperation\([^;]*pin\s*:/s, 'PIN must not be present in any queued operation');
assert.doesNotMatch(posSource, /rpc\(['"]approve_pos_void_with_pin['"]/);
assert.doesNotMatch(posSource, /items:\s*returnLines/);
assert.doesNotMatch(posSource, /quantity:\s*-returnQty/);
assert.doesNotMatch(helperSource, /approval_assertion[^\n]*pin/i);

const assertion = buildApprovalAssertion({
  operation_id: '11111111-1111-4111-8111-111111111111',
  entity_id: '22222222-2222-4222-8222-222222222222',
  approver_id: '33333333-3333-4333-8333-333333333333',
  outlet_id: '44444444-4444-4444-8444-444444444444',
  reason: 'Customer returned item',
  device_id: 'device-phase3-test',
  asserted_at: '2026-07-29T10:00:00.000Z'
});
assert.equal(canonicalize({ b: 2, a: 1 }), '{"a":1,"b":2}');
const proof = createApprovalProof(assertion, { cacheDir: path.join(os.tmpdir(), `boroko-phase3-proof-${process.pid}`), credential_fingerprint: 'trusted-device-fingerprint' });
assert.equal(proof.signed, true);
assert.equal(typeof proof.approval_assertion.signature, 'string');
assert.equal(proof.approval_assertion.signature.length, 64);
assert.equal(approvalProofHasPlaintextSecret(proof), false);
assert.equal(approvalProofHasPlaintextSecret({ approval_assertion: { signature: 'abc', pin: '1234' } }), true);

console.log('Phase 3 approval contract tests passed');
