import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const migrationPath = path.resolve(here, '../../supabase/migrations/20260729090200_phase3_returns_voids_v2.sql');
const sql = fs.readFileSync(migrationPath, 'utf8');

const required = [
  'create table if not exists public.pos_returns',
  'create table if not exists public.pos_return_items',
  'create table if not exists public.pos_return_tenders',
  'create table if not exists public.pos_voids',
  'create or replace function public.return_pos_order_v2(payload jsonb)',
  'create or replace function public.return_pos_order_items_v2(payload jsonb)',
  'create or replace function public.void_pos_order_v2(payload jsonb)',
  'security definer',
  'app_reject_pwa_financial_mutation',
  'app_claim_operation_receipt',
  'app_record_operation_receipt',
  'app_verify_pos_approval',
  'for update',
  'v_requested > v_available',
  'pending_external_refund',
  'pos_return',
  'pos_void',
  'pos_return_items_original_idx',
  'pos_voids_order_accepted_uidx'
];

for (const fragment of required) assert.match(sql, new RegExp(fragment.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i'), `missing SQL contract: ${fragment}`);

assert.doesNotMatch(sql, /(?:p_pin|approval_pin|pin\s+text|payload->>['"]pin['"])/i, 'plaintext PIN must never enter the RPC contract');
assert.match(sql, /quantity\s+integer\s+not\s+null\s+check\s*\(quantity\s*>\s*0\)/i);
assert.match(sql, /v_requested\s*<=\s*0\s+or\s+v_requested\s*<>\s*trunc\(v_requested\)/i);
assert.match(sql, /original_order_item_id\s+uuid\s+not\s+null\s+references\s+public\.pos_order_items/i);
assert.match(sql, /approval_assertion\s+jsonb\s+not\s+null/i);
assert.match(sql, /v_signature\s+<>\s+v_expected/i);
assert.match(sql, /booking_charges\([^)]*amount[^)]*\)[\s\S]*-v_net_total/i);
assert.match(sql, /_restore_pos_order_stock\(v_order_id,\s*v_lodge_id\)/i);

console.log('Phase 3 returns/voids SQL contract checks passed.');
