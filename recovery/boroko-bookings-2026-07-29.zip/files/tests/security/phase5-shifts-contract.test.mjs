import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..', '..');
const migrationPath = path.join(root, 'supabase', 'migrations', '20260729090400_phase5_shifts_cashup_v2.sql');
const sql = fs.readFileSync(migrationPath, 'utf8').toLowerCase();

test('phase 5 defines server-authoritative, idempotent shift/cash-up RPCs', () => {
  for (const required of [
    'create or replace function public.open_pos_shift_v2(payload jsonb)',
    'create or replace function public.close_pos_shift_and_cashup_v2(payload jsonb)',
    'app_reject_pwa_financial_mutation()',
    "app_claim_operation_receipt(v_operation_id",
    "app_record_operation_receipt(v_operation_id",
    "app_append_audit_event(v_lodge_id",
    "for update",
    "status = 'sealed'",
    'expected_by_method',
    'variance_by_method',
  ]) assert.match(sql, new RegExp(required.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
});

test('cash-up never trusts client expected totals and strips unknown counted buckets', () => {
  assert.match(sql, /v_counted_clean\s*:=\s*jsonb_build_object\('cash'/);
  assert.match(sql, /_pos_shift_authoritative_totals_v2\(v_shift\.id, v_boundary\)/);
  assert.doesNotMatch(sql, /nullif\(v_body->>'expected_by_method'/);
  assert.doesNotMatch(sql, /expected_by_method\s*=\s*excluded/);
});

test('sealed shifts and cash-ups have immutable guards and no table write grants', () => {
  assert.match(sql, /pos_shifts_sealed_guard_v2/);
  assert.match(sql, /pos_cashup_sessions_sealed_guard_v2/);
  assert.match(sql, /revoke all on public\.pos_shifts, public\.pos_cashup_sessions from anon, authenticated/);
  assert.match(sql, /grant select on public\.pos_shifts, public\.pos_cashup_sessions/);
});

