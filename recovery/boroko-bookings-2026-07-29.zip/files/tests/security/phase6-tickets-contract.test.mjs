import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const migrationPath = path.join(root, 'supabase/migrations/20260729090500_phase6_tickets_v2.sql');
const sql = fs.readFileSync(migrationPath, 'utf8').toLowerCase();

const required = [
  'create table if not exists public.pos_kds_station_mappings',
  'create table if not exists public.pos_kds_tickets',
  'create table if not exists public.pos_kds_ticket_events',
  'create or replace function public.create_pos_tickets_v2(payload jsonb)',
  'create or replace function public.status_pos_ticket_v2(payload jsonb)',
  'public.app_claim_operation_receipt',
  'public.app_record_operation_receipt',
  'public.app_append_audit_event',
  'session_type = \'pwa\'',
  'pos_kds_ticket_id',
  "unique (ticket_id, operation_id)",
  "status in ('new', 'preparing', 'ready', 'served', 'cancelled')",
  "station in ('kitchen', 'bar')",
  'snapshot_hash',
  'item_snapshot',
  'expected_version',
  'for update'
];

for (const fragment of required) assert.ok(sql.includes(fragment), `Phase 6 migration missing: ${fragment}`);

assert.ok(sql.includes("v_target = 'preparing' and v_ticket.status <> 'new'"));
assert.ok(sql.includes("v_target = 'ready' and v_ticket.status <> 'preparing'"));
assert.ok(sql.includes("v_target = 'served' and v_ticket.status <> 'ready'"));
assert.ok(sql.includes("v_target = 'cancelled'"));
assert.ok(!/category\s*(=|like|~)/i.test(sql), 'station routing must not use category-name regex');

console.log('Phase 6 ticket contract checks passed.');
