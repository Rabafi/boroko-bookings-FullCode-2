import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const migrationPath = path.join(ROOT, 'supabase', 'migrations', '20260729090100_phase2_pos_sale_v2.sql');
const sql = fs.readFileSync(migrationPath, 'utf8').toLowerCase();
const body = sql.match(/create or replace function public\.create_pos_order_v2\(payload jsonb\)[\s\S]*?\$\$;\s*$/i)?.[0] || sql;

for (const required of [
  'create table if not exists public.pos_menu_price_history',
  'create or replace function public.create_pos_order_v2(payload jsonb)',
  'app_reject_pwa_financial_mutation',
  "app_require_capability(v_lodge_id, 'pos.sale'",
  'app_claim_operation_receipt',
  'app_record_operation_receipt',
  'app_append_audit_event',
  'for update',
  'pos_receipt_sequences',
  'tender total does not match'
]) {
  assert.match(sql, new RegExp(required.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')), `Phase 2 migration must contain ${required}`);
}

assert.match(body, /v_qty\s*<=\s*0|quantities must be positive/, 'normal sale must reject non-positive quantities');
assert.match(body, /v_price\s*:=\s*v_history\.unit_price/, 'server must price from immutable history');
assert.doesNotMatch(body, /v_price\s*:=\s*nullif\(v_item->>['"]unit_price/, 'server must not trust caller unit_price');
assert.match(body, /operation_id/, 'sale must carry an idempotent operation identifier');
assert.match(body, /app_record_operation_receipt/, 'sale must persist an idempotent operation receipt');
assert.match(body, /v_tax_amount/, 'tax amount must not collide with tax profile row variable');
assert.doesNotMatch(body, /v_tax\s+public\.pos_tax_profiles%rowtype[\s\S]{0,500}v_tax\s*:=\s*round/i,
  'tax profile row and numeric tax amount must remain distinct variables');

console.log('phase2-sale-v2-contract: ok');
