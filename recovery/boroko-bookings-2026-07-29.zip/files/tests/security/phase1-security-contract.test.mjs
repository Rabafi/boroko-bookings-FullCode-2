import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import test from 'node:test'
import { createClient } from '@supabase/supabase-js'
import {
  assertDisposableTarget,
  loadTestEnv,
  redactSecrets
} from '../integration/test-tenant-guard.mjs'

/**
 * Phase 1 security contract checks.
 *
 * The SQL checks intentionally inspect only active migrations. They are
 * deterministic and do not create a Supabase client or mutate a database.
 * The optional integration checks are fail-closed: they run only when the
 * caller has explicitly selected a disposable tenant and supplied a short
 * lived app-session token. No service-role key is accepted for these checks,
 * because service-role requests bypass the access controls under test.
 */

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..')
const MIGRATIONS_DIR = path.join(ROOT, 'supabase', 'migrations')
const CONTRACT_PATH = path.join(ROOT, 'docs', 'pos', 'POS_CONTRACT_V2.md')

function readActiveSql() {
  if (!fs.existsSync(MIGRATIONS_DIR)) return ''
  return fs.readdirSync(MIGRATIONS_DIR)
    .filter((name) => name.endsWith('.sql'))
    .sort()
    .map((name) => fs.readFileSync(path.join(MIGRATIONS_DIR, name), 'utf8'))
    .join('\n\n')
    .toLowerCase()
}

function readContract() {
  return fs.readFileSync(CONTRACT_PATH, 'utf8').toLowerCase()
}

function functionBody(sql, functionName) {
  const escaped = functionName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  const match = sql.match(new RegExp(`(?:create|create or replace)\\s+function\\s+public\\.${escaped}\\b[\\s\\S]*?\\$\\$([\\s\\S]*?)\\$\\$;`, 'i'))
  return match?.[1]?.toLowerCase() || ''
}

function requirePattern(value, pattern, message) {
  assert.match(value, pattern, message)
}

function integrationTarget() {
  const env = loadTestEnv({ cwd: ROOT, env: process.env })
  try {
    const target = assertDisposableTarget(env)
    const anonKey = env.SUPABASE_ANON_KEY || env.VITE_SUPABASE_KEY || env.VITE_SUPABASE_ANON_KEY || ''
    const sessionToken = env.BOROKO_TEST_SECURITY_SESSION_TOKEN || ''
    if (!anonKey || !sessionToken) {
      return { skip: 'set BOROKO_TEST_SECURITY_SESSION_TOKEN and an anon key to run disposable security RPC checks' }
    }
    return { env, target, anonKey, sessionToken }
  } catch (error) {
    return { skip: redactSecrets(error?.message || 'disposable target not configured') }
  }
}

test('POS v2 contract freezes server-derived identity and idempotent receipt fields', () => {
  const contract = readContract()
  for (const field of [
    'contract_version',
    'operation_id',
    'device_id',
    'device_event_at',
    'lodge_id',
    'outlet_id',
    'payload',
    'accepted_at',
    'idempotent'
  ]) {
    assert.ok(contract.includes(`"${field}"`), `contract must name ${field}`)
  }
  requirePattern(contract, /actor identity, role, and approval identity are server-derived/i,
    'actor identity must be server-derived rather than caller-authored')
  requirePattern(contract, /lodge_id[\s`*]+and[\s`*]+outlet_id[\s`*]+are checked against the\s+authenticated session/i,
    'lodge and outlet scope must be checked against the authenticated session')
  requirePattern(contract, /unique operation id|unique constraint/i,
    'the contract must require a uniqueness guard for operation replay')
})

test('Phase 1 migration defines registered-device and operation-receipt isolation', () => {
  const sql = readActiveSql()
  requirePattern(sql, /create table(?: if not exists)? public\.app_registered_devices\b/,
    'app_registered_devices table is missing')
  for (const column of ['device_id', 'lodge_id', 'status', 'revoked_at']) {
    requirePattern(sql, new RegExp(`\\b${column}\\b`), `registered device table must include ${column}`)
  }
  requirePattern(sql, /unique\s*\(\s*lodge_id\s*,\s*device_id\s*\)/,
    'registered device identity must be unique per lodge')

  requirePattern(sql, /create table(?: if not exists)? public\.app_operation_receipts\b/,
    'app_operation_receipts table is missing')
  requirePattern(sql, /operation_id[^;]{0,180}(?:primary key|unique)/,
    'operation_id must have a database uniqueness constraint')
  requirePattern(sql, /request_hash/, 'operation receipts must retain a request hash')
  requirePattern(sql, /canonical_response|response_json|response_payload/,
    'operation receipts must retain the canonical first response')
  requirePattern(sql, /accepted_(?:server_)?at|server_accepted_at|accepted_at/,
    'operation receipts must retain server acceptance time')
})

test('capability validation derives session actor and enforces lodge/outlet scope', () => {
  const sql = readActiveSql()
  const body = functionBody(sql, 'app_require_capability')
  assert.ok(body, 'app_require_capability function is missing')
  requirePattern(body, /app_current_session_row\s*\(/,
    'capability checks must load the current authenticated session')
  requirePattern(body, /p_lodge_id|lodge_id/, 'capability checks must evaluate lodge scope')
  requirePattern(body, /p_outlet_id|outlet_id/, 'capability checks must evaluate outlet scope')
  requirePattern(body, /role|capability|feature/, 'capability checks must evaluate role/feature policy')
  requirePattern(body, /42501|insufficient|access denied|not allowed/,
    'capability denial must use a stable access-denied path')
  requirePattern(body, /pwa|session_type/,
    'desktop-only capabilities must reject a PWA session')
  assert.doesNotMatch(body, /payload\s*->>\s*['"](?:actor|actor_id|role|user_id)['"]/i,
    'capability helper must not derive authority from caller payload fields')
})

test('device validation rejects revoked or suspended devices before replay', () => {
  const sql = readActiveSql()
  const deviceBodies = [
    functionBody(sql, 'app_require_capability'),
    functionBody(sql, 'app_require_registered_device'),
    functionBody(sql, 'app_validate_device_operation'),
    sql
  ].join('\n')
  requirePattern(deviceBodies, /app_registered_devices/, 'device validation must consult registered devices')
  requirePattern(deviceBodies, /revoked_at\s+is\s+null|status\s*(?:=|in)[^;]{0,80}(?:active|trusted)/,
    'replay must reject revoked/suspended device rows')
})

test('operation receipt replay returns the original response and does not apply twice', () => {
  const sql = readActiveSql()
  const receiptBody = [
    functionBody(sql, 'app_operation_receipt_begin'),
    functionBody(sql, 'app_operation_receipt_complete'),
    functionBody(sql, 'app_record_operation_receipt'),
    functionBody(sql, 'app_get_or_create_operation_receipt'),
    functionBody(sql, 'app_claim_operation_receipt'),
    sql
  ].join('\n')
  requirePattern(receiptBody, /app_operation_receipts/, 'receipt helper must use app_operation_receipts')
  requirePattern(receiptBody, /operation_id/, 'receipt helper must key by operation_id')
  requirePattern(receiptBody, /on conflict|already|idempotent|replay|existing/,
    'duplicate operation IDs must follow an explicit replay/idempotent path')
  requirePattern(receiptBody, /canonical_response|response_json|response_payload/,
    'duplicate operation IDs must return the stored canonical response')
})

test('audit helper is security-definer and derives actor/device from the session', () => {
  const sql = readActiveSql()
  requirePattern(sql, /create table(?: if not exists)? public\.app_audit_events\b/,
    'append-only app_audit_events table is missing')
  const body = functionBody(sql, 'app_append_audit_event')
  assert.ok(body, 'app_append_audit_event function is missing')
  const declaration = sql.match(/(?:create|create or replace)\s+function\s+public\.app_append_audit_event\b[\s\S]*?\$\$[\s\S]*?\$\$;/i)?.[0] || ''
  requirePattern(declaration, /security definer/, 'audit helper must be security definer')
  requirePattern(body, /app_current_session_row\s*\(/,
    'audit actor must come from the current authenticated session')
  requirePattern(body, /app_current_device_id\s*\(/,
    'audit device must come from verified device context')
  requirePattern(body, /now\s*\(\)|current_timestamp/, 'audit timestamp must use server time')
  assert.doesNotMatch(body, /payload\s*->>\s*['"](?:actor|actor_id|device_id|created_at)['"]/i,
    'audit actor/device/time cannot be caller-authored')
})

test('disposable-session denial checks reject actor spoofing and cross-tenant/outlet IDs', async (t) => {
  const config = integrationTarget()
  if (config.skip) {
    t.skip(config.skip)
    return
  }

  const client = createClient(config.target.url, config.anonKey, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      headers: {
        'x-boroko-session': config.sessionToken
      }
    }
  })

  const foreignLodge = process.env.BOROKO_TEST_FOREIGN_LODGE_ID || '22222222-2222-4222-8222-222222222222'
  const foreignOutlet = process.env.BOROKO_TEST_FOREIGN_OUTLET_ID || '00000000-0000-4000-8000-000000000202'
  async function assertDenied(payload, label) {
    const { data, error } = await client.rpc('app_require_capability', payload)
    assert.ok(error || data?.success === false, `${label} unexpectedly succeeded`)
    if (error?.message) {
      assert.doesNotMatch(error.message, /service_role|supabase_key|password|token=/i)
    }
  }

  await assertDenied({
    p_lodge_id: foreignLodge,
    p_capability: 'pos.sale',
    p_outlet_id: null
  }, 'cross-lodge actor spoof')

  await assertDenied({
    p_lodge_id: config.target.lodgeId,
    p_capability: 'pos.sale',
    p_outlet_id: foreignOutlet
  }, 'cross-outlet actor spoof')
})
