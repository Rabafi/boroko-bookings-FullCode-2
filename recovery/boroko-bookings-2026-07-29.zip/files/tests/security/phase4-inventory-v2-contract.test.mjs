import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const migration = fs.readFileSync(path.join(root, 'supabase', 'migrations', '20260729090300_phase4_inventory_offline_v2.sql'), 'utf8').toLowerCase();
const inventory = fs.readFileSync(path.join(root, 'src', 'main', 'domains', 'inventory.js'), 'utf8');

for (const rpc of ['record_inventory_purchase_v2', 'adjust_inventory_stock_v2', 'set_pos_menu_item_availability_v2', 'create_inventory_stocktake_v2', 'save_inventory_stocktake_count_v2', 'post_inventory_stocktake_v2']) {
  assert.match(migration, new RegExp(`create or replace function public\\.${rpc}`));
  assert.match(migration, new RegExp(`${rpc.replaceAll('_', '[ _]')}`));
}
assert.match(migration, /app_claim_operation_receipt/);
assert.match(migration, /app_record_operation_receipt/);
assert.match(migration, /for update/);
assert.match(migration, /stock cannot become negative/);
assert.match(inventory, /record_inventory_purchase_v2/);
assert.match(inventory, /adjust_inventory_stock_v2/);
assert.match(inventory, /createOperationEnvelope/);
assert.doesNotMatch(inventory, /queueOperation\('rpc',\s*'add_inventory_purchase'/);
assert.doesNotMatch(inventory, /queueOperation\('rpc',\s*'adjust_inventory_stock'/);
console.log('phase4-inventory-v2-contract: ok');
